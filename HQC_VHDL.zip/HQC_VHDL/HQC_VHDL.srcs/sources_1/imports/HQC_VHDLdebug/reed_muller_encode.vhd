--/*Main conversions:

--Parameter calculations: Helper functions calculate N1_BYTES, K_BYTES, and LOG_N1_BYTES (clog2) based on parameter_set
--Component instantiation:

--rm_encoder: Encodes each byte using Reed-Muller (1,8) code ? 128-bit codeword
--mem_single: Stores N1_BYTES codewords (one per input byte)


--Data flow:

--Input RS codeword (N1 bits) is loaded into cdw_in
--Each byte rotates through, gets RM-encoded
--128-bit RM codewords stored in memory
--External access via cdw_out_en and cdw_out_addr


--Rotation logic:
--Circular right shift by 8 bits (1 byte)

--Key implementation details:

--State machine: s_wait_start ? s_encode (N1_BYTES times) ? s_done
--Memory addressing: Multiplexed between write counter and external read address
--Encoding pipeline: One byte encoded per clock cycle
--Done signal: Pulses when all bytes are encoded

--Algorithm purpose:
--This module performs concatenated code encoding for HQC:

--Takes a Reed-Solomon codeword (N1 bits = 46/56/90 bytes)
--Encodes each byte with Reed-Muller (128,8) code
--Stores 128-bit RM codewords in memory
--Total output: N1_BYTES � 128 bits
--*/


library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity reed_muller_encode is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk          : in  std_logic;
        rst          : in  std_logic;
        start        : in  std_logic;
        rs_cdw_in    : in  std_logic_vector; --(N1-1 downto 0);  -- length depends on parameter_set
        cdw_out_en   : in  std_logic;
        cdw_out_addr : in  std_logic_vector; --(LOG_N1_BYTES-1 downto 0);  -- width = ceil(log2(N1_BYTES))
        cdw_out      : out std_logic_vector(127 downto 0);
        done         : out std_logic
    );
end entity reed_muller_encode;

architecture rtl of reed_muller_encode is

constant HQC_PARAMS : hqc_params_t := get_hqc_params(PARAM_SET);

constant N1_BYTES     : natural := HQC_PARAMS.n1;
constant N1           : natural := 8*N1_BYTES;
constant LOG_N1_BYTES : natural := clog2(N1_BYTES);

    -- Ensure input/output widths match generics
subtype rs_cdw_t is std_logic_vector(N1-1 downto 0); 
subtype addr_t   is std_logic_vector(LOG_N1_BYTES-1 downto 0);

    -- Internal signals
signal rs_cdw_reg   : rs_cdw_t;
signal encoder_out  : std_logic_vector(127 downto 0);
signal mem_addr     : addr_t;
signal mem_wr_en    : std_logic;
signal count_bytes  : unsigned(LOG_N1_BYTES-1 downto 0);

    -- State machine
type state_t is (S_WAIT_START, S_ENCODE, S_DONE);
signal state : state_t;

    -- Control signals
signal init_reg   : std_logic;
signal shift_cdw  : std_logic;

begin

    -- Assert correct port sizes at elaboration
    assert rs_cdw_in'length = N1
        report "rs_cdw_in must be N1 bits wide for selected parameter_set" severity failure;
    assert cdw_out_addr'length = LOG_N1_BYTES
        report "cdw_out_addr width mismatch" severity failure;

-- ===================================================================
-- Reed-Muller Encoder Instance (RM(1,7) -> 8 bits -> 128 bits) / Binary Code [128,8,64]
-- ===================================================================
RM_ENC : rm_encoder
     port map (
         clk      => clk,
         rst      => rst,
         start    => '0',                   -- not used in original
         byte_in  => rs_cdw_reg(7 downto 0),
         cdw_out  => encoder_out,
         done     => open
     );

    -- ===================================================================
    -- Single-Port RAM to store encoded blocks
    -- Depth: N1_BYTES, Width: 128 bits
    -- ===================================================================
    MEM : mem_single
        generic map (
            WIDTH  => 128,
            DEPTH  => N1_BYTES
        )
        port map (
            clk      => clk,
            data_in     => encoder_out,
            address  => mem_addr,
            wr_en    => mem_wr_en,
            data_out        => cdw_out
        );

-- ===================================================================
-- Input Register and Byte Shifting
-- ===================================================================
process(clk)
begin
  if rising_edge(clk) then
     if rst = '1' then
        rs_cdw_reg <= (others => '0');
     elsif init_reg = '1' then
        rs_cdw_reg <= rs_cdw_in;
     elsif shift_cdw = '1' then
        rs_cdw_reg <= rs_cdw_reg(7 downto 0) & rs_cdw_reg(N1-1 downto 8);
     end if;
  end if;
end process;

-- ===================================================================
-- Memory Address Mux
-- ===================================================================
mem_addr <= cdw_out_addr when cdw_out_en = '1' else std_logic_vector(count_bytes);

-- ===================================================================
-- State Machine and Counter
-- ===================================================================
process(clk)
begin
  if rising_edge(clk) then
     if rst = '1' then
        state         <= S_WAIT_START;
        count_bytes   <= (others => '0');
        done          <= '0';
     else
        case state is
           when S_WAIT_START =>
                done <= '0';
                if start = '1' then
                   state       <= S_ENCODE;
                   count_bytes <= (others => '0');
                end if;

           when S_ENCODE =>
                done <= '0';
                if count_bytes = to_unsigned(N1_BYTES - 1, count_bytes'length) then
                   state <= S_DONE;
                else
                   count_bytes <= count_bytes + 1;
                end if;

           when S_DONE =>
                state <= S_WAIT_START;
                done  <= '1';
                count_bytes <= (others => '0');

           when others =>
                state <= S_WAIT_START;
        end case;
     end if;
  end if;
end process;

-- ===================================================================
-- Control Signal Generation
-- ===================================================================
process(state, start)
begin --declare all signals in each case
init_reg   <= '0';
shift_cdw  <= '0';
mem_wr_en  <= '0';

  case state is
       when S_WAIT_START =>
            if start = '1' then
               init_reg <= '1';
            end if;

       when S_ENCODE =>
            mem_wr_en <= '1';
            shift_cdw <= '1';

       when S_DONE =>
            null; -- all zero by default

       when others =>
            null;
   end case;
end process;

end rtl;



--/*library IEEE;
--use IEEE.STD_LOGIC_1164.ALL;
--use IEEE.NUMERIC_STD.ALL;

--entity reed_muller_encode is
--    generic (
--        parameter_set : string := "hqc128"
--    );
--    port (
--        clk          : in  std_logic;
--        rst          : in  std_logic;
--        start        : in  std_logic;
--        rs_cdw_in    : in  std_logic_vector(N1-1 downto 0);
--        cdw_out_en   : in  std_logic;
--        cdw_out_addr : in  std_logic_vector(LOG_N1_BYTES-1 downto 0);
--        cdw_out      : out std_logic_vector(127 downto 0);
--        done         : out std_logic
--    );
--end reed_muller_encode;

--architecture rtl of reed_muller_encode is

--    -- Helper functions for parameter calculations
--    function get_N1_BYTES(param_set : string) return integer is
--    begin
--        if param_set = "hqc128" then
--            return 46;
--        elsif param_set = "hqc192" then
--            return 56;
--        elsif param_set = "hqc256" then
--            return 90;
--        else
--            return 46;
--        end if;
--    end function;
    
--    function get_K_BYTES(param_set : string) return integer is
--    begin
--        if param_set = "hqc128" then
--            return 16;
--        elsif param_set = "hqc192" then
--            return 24;
--        elsif param_set = "hqc256" then
--            return 32;
--        else
--            return 16;
--        end if;
--    end function;
    
--    -- Function to calculate ceiling of log2
--    function clog2(n : integer) return integer is
--        variable temp : integer := n - 1;
--        variable result : integer := 0;
--    begin
--        while temp > 0 loop
--            temp := temp / 2;
--            result := result + 1;
--        end loop;
--        return result;
--    end function;
    
--    -- Parameter calculations
--    constant N1_BYTES     : integer := get_N1_BYTES(parameter_set);
--    constant K_BYTES      : integer := get_K_BYTES(parameter_set);
--    constant LOG_N1_BYTES : integer := clog2(N1_BYTES);
--    constant N1           : integer := 8 * N1_BYTES;
--    constant K            : integer := 8 * K_BYTES;
    
--    -- Internal signals
--    signal cdw_in          : std_logic_vector(N1-1 downto 0);
--    signal encoder_out     : std_logic_vector(127 downto 0);
--    signal addr            : std_logic_vector(LOG_N1_BYTES-1 downto 0);
--    signal init            : std_logic;
--    signal shift_cdw       : std_logic;
--    signal wr_en           : std_logic;
--    signal count_cdw_bytes : unsigned(LOG_N1_BYTES-1 downto 0);
--    signal done_int        : std_logic;
    
--    -- State machine
--    type state_type is (s_wait_start, s_encode, s_done);
--    signal state : state_type := s_wait_start;
    
--    -- Component declarations
--    component rm_encoder is
--        generic (
--            ENCODING_MATRIX_0 : std_logic_vector(127 downto 0) := x"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
--            ENCODING_MATRIX_1 : std_logic_vector(127 downto 0) := x"cccccccccccccccccccccccccccccccc";
--            ENCODING_MATRIX_2 : std_logic_vector(127 downto 0) := x"f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0";
--            ENCODING_MATRIX_3 : std_logic_vector(127 downto 0) := x"ff00ff00ff00ff00ff00ff00ff00ff00";
--            ENCODING_MATRIX_4 : std_logic_vector(127 downto 0) := x"ffff0000ffff0000ffff0000ffff0000";
--            ENCODING_MATRIX_5 : std_logic_vector(127 downto 0) := x"00000000ffffffff00000000ffffffff";
--            ENCODING_MATRIX_6 : std_logic_vector(127 downto 0) := x"0000000000000000ffffffffffffffff";
--            ENCODING_MATRIX_7 : std_logic_vector(127 downto 0) := x"ffffffffffffffffffffffffffffffff"
--        );
--        port (
--            clk      : in  std_logic;
--            rst      : in  std_logic;
--            start    : in  std_logic;
--            byte_in  : in  std_logic_vector(7 downto 0);
--            cdw_out  : out std_logic_vector(127 downto 0);
--            done     : out std_logic
--        );
--    end component;
    
--    component mem_single is
--        generic (
--            WIDTH : integer := 128;
--            DEPTH : integer := 46
--        );
--        port (
--            clock   : in  std_logic;
--            data    : in  std_logic_vector(WIDTH-1 downto 0);
--            address : in  std_logic_vector(clog2(DEPTH)-1 downto 0);
--            wr_en   : in  std_logic;
--            q       : out std_logic_vector(WIDTH-1 downto 0)
--        );
--    end component;

--begin

--    -- Input register with rotation
--    process(clk)
--    begin
--        if rising_edge(clk) then
--            if init = '1' then
--                cdw_in <= rs_cdw_in;
--            elsif shift_cdw = '1' then
--                cdw_in <= cdw_in(7 downto 0) & cdw_in(N1-1 downto 8);
--            end if;
--        end if;
--    end process;
    
--    -- Reed-Muller Encoder instance
--    ENCODER : rm_encoder
--        port map (
--            clk      => clk,
--            rst      => rst,
--            start    => '0',
--            byte_in  => cdw_in(7 downto 0),
--            cdw_out  => encoder_out,
--            done     => open
--        );
    
--    -- Address multiplexer
--    addr <= cdw_out_addr when cdw_out_en = '1' else std_logic_vector(count_cdw_bytes);
    
--    -- Codeword memory
--    CODEWORD : mem_single
--        generic map (
--            WIDTH => 128,
--            DEPTH => N1_BYTES
--        )
--        port map (
--            clock   => clk,
--            data    => encoder_out,
--            address => addr,
--            wr_en   => wr_en,
--            q       => cdw_out
--        );
    
--    -- State machine
--    process(clk)
--    begin
--        if rising_edge(clk) then
--            if rst = '1' then
--                state <= s_wait_start;
--                count_cdw_bytes <= (others => '0');
--                done_int <= '0';
--            else
--                case state is
--                    when s_wait_start =>
--                        done_int <= '0';
--                        if start = '1' then
--                            state <= s_encode;
--                            count_cdw_bytes <= (others => '0');
--                        end if;
                    
--                    when s_encode =>
--                        done_int <= '0';
--                        if count_cdw_bytes = N1_BYTES then
--                            state <= s_done;
--                        else
--                            state <= s_encode;
--                            count_cdw_bytes <= count_cdw_bytes + 1;
--                        end if;
                    
--                    when s_done =>
--                        state <= s_wait_start;
--                        done_int <= '1';
--                        count_cdw_bytes <= (others => '0');
                    
--                    when others =>
--                        state <= s_wait_start;
--                end case;
--            end if;
--        end if;
--    end process;
    
--    -- Output assignment
--    done <= done_int;
    
--    -- Control signal generation
--    process(state, start)
--    begin
--        -- Default values
--        init      <= '0';
--        shift_cdw <= '0';
--        wr_en     <= '0';
        
--        case state is
--            when s_wait_start =>
--                if start = '1' then
--                    init <= '1';
--                end if;
            
--            when s_encode =>
--                wr_en     <= '1';
--                shift_cdw <= '1';
            
--            when s_done =>
--                null;
            
--            when others =>
--                null;
--        end case;
--    end process;

--end rtl;*/