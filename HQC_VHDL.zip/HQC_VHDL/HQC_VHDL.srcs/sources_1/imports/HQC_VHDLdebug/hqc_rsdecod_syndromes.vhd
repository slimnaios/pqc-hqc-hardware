--/*Main conversions:

--Parameter calculations: Helper functions calculate all Reed-Solomon parameters (PARAM_DELTA, PARAM_G, PARAM_K, PARAM_N1, ALPHA_AW) based on PARAM_SECURITY
--Message accumulation: Shifts in input bytes to build the K-byte message buffer
--Syndrome computation:

--XORs GF multiplication results into syndrome buffer
--Rotates syndrome buffer after each operation


--Alpha ROM: Large lookup table storing precomputed Galois Field powers

--GF multiplier component: Instantiated to perform Galois Field multiplication between codeword byte and alpha power

--Key implementation details:

--Purpose: Computes Reed-Solomon syndromes for error detection/correction
--Message buffer: Stores last K bytes (the message portion of the codeword)
--Syndrome calculation: For each input byte, performs GF multiplication with powers of alpha and accumulates results
--Counter logic: Tracks input position and iteration count (2*PARAM_DELTA iterations per input byte)
--Alpha ROM: Provides precomputed ?^(i*j) values for syndrome calculation where i is the syndrome index and j is the codeword position

--Architecture Overview
--Input ? [Message Buffer] ? [GF Multiplier] ? [Syndrome Accumulator] ? Output
--  ?           ?                    ?                    
--[Counter] ? [Alpha ROM] ? [Alpha Buffer]    

--The syndrome values are used in the Berlekamp-Massey or Euclidean algorithm to find error locations and values for Reed-Solomon decoding 
--in the HQC cryptosystem.

--Each ROM entry stores precomputed Galois Field powers ?^(i�j) where:
--i = syndrome index (0 to 2�DELTA-1)
--j = codeword position (din_cnt)

--This precomputation significantly speeds up syndrome calculation by avoiding runtime GF exponentiations.
-------------------------------------------------------
--### Detailed Timeline for One Input Byte:
--```
--Cycle 0: New byte arrives (din_valid_i = '1')
--  - din_cnt increments (position j)
--  - msg_buf shifts in new byte
--  - alpha_buf loads ROM[din_cnt] (all ?^(i�j) for this position)
--  - cnt resets to 0

--Cycle 1: First syndrome (i=0)
--  - alpha_buf rotates, exposes ?^(0�j)
--  - GF multiplier: r_j � ?^(0�j)
--  - cnt = 0

--Cycle 2: 
--  - Result from Cycle 1 ready
--  - XOR into S_0: S_0 = S_0 ? (r_j � ?^(0�j))
--  - GF multiplier starts: r_j � ?^(1�j)
--  - cnt = 1

--Cycle 3:
--  - XOR into S_1: S_1 = S_1 ? (r_j � ?^(1�j))
--  - GF multiplier starts: r_j � ?^(2�j)
--  - cnt = 2

--...continues for 2�DELTA iterations...

--Cycle 2�DELTA+1: last_cnt = '1', cnt_en clears
--  - Ready for next input byte
------------------------------------------------------------------------
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity hqc_rsdecod_syndromes is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i        : in  std_logic;
        rst_ni       : in  std_logic;
        start_i      : in  std_logic;
        din_i        : in  std_logic_vector;--(DIN_W-1 downto 0);
        din_valid_i  : in  std_logic;
        din_done_i   : in  std_logic;
        dout_o       : out std_logic_vector;--(DOUT_W-1 downto 0);
        dout_valid_o : out std_logic;
        msg_o        : out std_logic_vector--(MSG_W-1 downto 0)
    );
end hqc_rsdecod_syndromes;

architecture rtl of hqc_rsdecod_syndromes is
    
    -- Parameter calculations
constant HQC_PARAMS  : hqc_params_t := get_hqc_params(PARAM_SET);
constant PARAM_DELTA : integer := HQC_PARAMS.delta;
constant PARAM_G     : integer := HQC_PARAMS.G;
constant PARAM_K     : integer := HQC_PARAMS.k1;
constant PARAM_N1    : integer := HQC_PARAMS.n1;
constant ALPHA_DW    : integer := 8 * 2 * PARAM_DELTA;
constant ALPHA_AW    : integer := get_ALPHA_AW(PARAM_SET);
constant DIN_W       : integer := 8;
constant DOUT_W      : integer := 8 * 2 * PARAM_DELTA;
constant MSG_W       : integer := 8 * PARAM_K;

-- Internal signals
signal synd_buf      : std_logic_vector(DOUT_W-1 downto 0);
signal msg_buf       : std_logic_vector(MSG_W-1 downto 0);
signal din_valid_d   : std_logic;
signal gf_en         : std_logic;
signal synd_en       : std_logic;
signal cdw_in        : std_logic_vector(7 downto 0);
signal alpha_ij_pow  : std_logic_vector(7 downto 0);
signal gf_mul_out    : std_logic_vector(7 downto 0);
signal alpha_rom     : std_logic_vector(ALPHA_DW-1 downto 0);
signal alpha_buf     : std_logic_vector(ALPHA_DW-1 downto 0);
signal din_cnt       : unsigned(ALPHA_AW-1 downto 0);
signal cnt           : unsigned(5 downto 0);
signal cnt_en        : std_logic;
signal last_cnt      : std_logic;
signal input_done    : std_logic;
signal dout_valid    : std_logic;

-- Component declaration
component gf_mul is
    generic (
        REG_IN  : integer := 0;
        REG_OUT : integer := 1
    );
    port (
        clk    : in  std_logic;
        start  : in  std_logic;
        in_1   : in  std_logic_vector(7 downto 0);
        in_2   : in  std_logic_vector(7 downto 0);
        output : out std_logic_vector(7 downto 0);
        done   : out std_logic
    );
end component;

begin

-- Accumulate K bytes messages (last K bytes of input)
-- msg = {m[K-1],m[K-2],...,m[1],m[0]} with m[i] in byte
process(clk_i)
begin
    if rising_edge(clk_i) then
        if din_valid_i = '1' then
            msg_buf <= din_i & msg_buf(MSG_W-1 downto DIN_W);
        end if;
    end if;
end process;

msg_o  <= msg_buf;
cdw_in <= msg_buf(MSG_W-1 downto MSG_W-8);

-- Syndrome buffer
-- Accumulates syndrome values using XOR (GF addition)
-- Operation: Circular shift register with feedback
-- Size: `8 � 2 � DELTA` bits (stores all syndromes)
process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or start_i = '1' then
            synd_buf <= (others => '0');
        elsif synd_en = '1' then
            synd_buf(DOUT_W-1 downto DOUT_W-8) <= gf_mul_out xor synd_buf(7 downto 0);
            synd_buf(DOUT_W-1-8 downto 0) <= synd_buf(DOUT_W-1 downto 8);
        end if;
    end if;
end process;

dout_o <= synd_buf;

-- Alpha buffer
-- Circular buffer providing one ? power per clock cycle
-- Loads entire ROM entry, then rotates to expose each byte
-- Provides 2�DELTA values sequentially (one per syndrome)
process(clk_i)
begin
    if rising_edge(clk_i) then
        if din_valid_d = '1' then
            alpha_buf <= alpha_rom;
        elsif gf_en = '1' then
            alpha_buf <= alpha_buf(ALPHA_DW-1-8 downto 0) & alpha_buf(ALPHA_DW-1 downto ALPHA_DW-8);
        end if;
    end if;
end process;

alpha_ij_pow <= alpha_buf(ALPHA_DW-1 downto ALPHA_DW-8);

-- GF multiplication
GFMUL_SYND : gf_mul
    generic map (
        REG_IN  => 0,
        REG_OUT => 1
    )
    port map (
        clk    => clk_i,
        start  => gf_en,
        in_1   => cdw_in,       -- Current codeword byte
        in_2   => alpha_ij_pow, -- Current ?^(i�j)
        output => gf_mul_out,   -- r_j � ?^(i�j)
        done   => synd_en
    );

------------------------------------------------------------------------------
-- Controller
------------------------------------------------------------------------------

-- Input Counter
-- Tracks input position (0 to n-1)
-- Increments on each valid input byte
-- Used as ROM address
process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or start_i = '1' then
            din_cnt <= (others => '0');
        elsif din_valid_i = '1' then
            din_cnt <= din_cnt + 1;
        end if;
    end if;
end process;

-- Main counter
-- Iteration counter (0 to 2�DELTA-1)
-- Counts syndrome calculations per input byte
-- Resets on new input or completion
process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or din_valid_i = '1' or last_cnt = '1' then
            cnt <= (others => '0');
        elsif cnt_en = '1' then
            cnt <= cnt + 1;
        end if;
    end if;
end process;

last_cnt <= '1' when cnt = (2*PARAM_DELTA-1) else '0'; -- Signals completion of all syndrome iterations for current byte

process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or last_cnt = '1' then
            cnt_en <= '0';
        elsif din_valid_i = '1' then
            cnt_en <= '1';
        end if;
    end if;
end process;

process(clk_i)
begin
    if rising_edge(clk_i) then
        gf_en       <= cnt_en;
        din_valid_d <= din_valid_i; ---- Delayed valid (for ROM loading)
    end if;
end process;

process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or start_i = '1' then
            input_done <= '0';
        elsif din_done_i = '1' then
            input_done <= '1';
        end if;
    end if;
end process;

process(clk_i)
    variable not_gf_en : std_logic;
begin
    if rising_edge(clk_i) then
        not_gf_en := not gf_en;
        dout_valid <= not_gf_en and synd_en and input_done;
    end if;
end process;

dout_valid_o <= dout_valid;

--/*
--Outputs valid **only when**:
--- All inputs processed (`input_done`)
--- Last syndrome computed (`synd_en` but not `gf_en`)
--- Ensures complete syndrome set ready

--## Example Calculation (Simplified)

--Assume 128-bit security (DELTA=15, so 30 syndromes):
--```
--Receive codeword: [r_0, r_1, r_2, ..., r_45]

--For each byte r_j:
--  Load alpha_rom[j] = [?^(0�j), ?^(1�j), ..., ?^(29�j)]
  
--  For i = 0 to 29:
--    S_i = S_i ? (r_j � ?^(i�j))
    
--After all 46 bytes:
--  S = [S_0, S_1, ..., S_29]  ? Output syndromes
--*/
   
------------------------------------------------------------------------------
-- Alpha power ROM
------------------------------------------------------------------------------

 -- - 128-bit security: 46 entries � 240 bits (30 bytes) = ALPHA_DW = 240 bits
 -- - 192-bit security: 56 entries � 256 bits (32 bytes) = ALPHA_DW = 256 bits  
 -- - 256-bit security: 90 entries � 464 bits (58 bytes) = ALPHA_DW = 464 bits
 -- Each entry contains precomputed ?^(i*j) for i=0 to 2*DELTA-1 (syndrome indices)
 -- where j is the codeword position (din_cnt)

gen_alpha_128: if PARAM_SET = HQC_128 generate
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            case to_integer(din_cnt) is
                when 0  => alpha_rom <= x"010101010101010101010101010101010101010101010101010101010101";
                when 1  => alpha_rom <= x"020408102040801D3A74E8CD8713264C982D5AB475EAC98F03060C183060";
                when 2  => alpha_rom <= x"0410401D74CD134C2DB4EA8F0618609D4E25946AB5EE9F460514505D69B9";
                when 3  => alpha_rom <= x"08403ACD262D758F0C60272535B5C1460A50BAB9A1612F650F78E76B7FDF";
                when 4  => alpha_rom <= x"101DCD4CB48F189D256AEE46145DB95F99651EFD6BFE5BD9110DD081F83B";
                when 5  => alpha_rom <= x"207426B403609C6AC105A0B9BE5E0FFDD6DFE2111A677C3B332EA9844D55";
                when 6  => alpha_rom <= x"40CD2D8F6025B54650B96165786BDFD944D03E3B66B821A855E4BFFCF196";
                when 7  => alpha_rom <= x"801375189CB58C5DA15E3C6BA3431A8193666D842939D1FCFF6257C8E059";
                when 8  => alpha_rom <= x"1D4C8F9D6A465D5F65FDFED90D813B854FA849E6FCE395821C51C312F72C";
                when 9  => alpha_rom <= x"3A2D0C25C150A165E7DF86D0ED66A9A892BFB3965707A6C324FB7DAD4026";
                when 10 => alpha_rom <= x"74B4606A05B95EFDDF11673B2E8455E6D796AE1C59ACF42C6C2026039CC1";
                when 11 => alpha_rom <= x"E8EA27EEA0613CFE866776B8543991E3DC07A2ACF5B0473AB4C0B5285F0F";
                when 12 => alpha_rom <= x"CD8F2546B9656BD9D03BB8A8E4FC9682DDC33D2CAD3A7527C1BA2FE7B61A";
                when 13 => alpha_rom <= x"87063514BE78A30DED2E54E4E562645145FB83202DC0EEBA5EBBD9BDECA9";
                when 14 => alpha_rom <= x"1318B55D5E6B4381668439FC62C859120BADE8033528C2E7E2BDC59EAA91";
                when 15 => alpha_rom <= x"2660C1B90FDF1A3BA95591966459242C012660C1B90FDF1A3BA955919664";
                when 16 => alpha_rom <= x"4C9D465FFDD98185A8E6E38251122C0298278CBEE7AF1F174DD1DB19A224";
                when 17 => alpha_rom <= x"984E0A99D644934F92D7DCDD450B01984E0A99D644934F92D7DCDD450B01";
                when 18 => alpha_rom <= x"2D255065DFD066A8BF9607C3FBAD26270A2F7F1AC51573DB64F2F536CD60";
                when 19 => alpha_rom <= x"5A94BA1EE23E6D49B3AEA23D83E8608C997F3433A8636238AC1608EAD4B9";
                when 20 => alpha_rom <= x"B46AB9FD113B84E6961CAC2C2003C1BED61A334D9137A724E97460055EDF";
                when 21 => alpha_rom <= x"75B5A16B1A6629FC5759F5AD2D35B9E744C5A8916EA63D362625BA78863B";
                when 22 => alpha_rom <= x"EAEE61FE67B839E307ACB03AC0280FAF93156337A67AD82D6ADE6B348555";
                when 23 => alpha_rom <= x"C99F2F5B7C21D195A6F44775EEC2DF1F4F7362A73DD85AB5BEFECEDAD596";
                when 24 => alpha_rom <= x"8F4665D93BA8FC82C32C3A27BAE71A1792DB3824362DB561DF3E21BF6E59";
                when 25 => alpha_rom <= x"03050F113355FF1C246CB4C15EE23B4DD764ACE9266ABEDF7C8491AEEF2C";
                when 26 => alpha_rom <= x"0614780D2EE46251FB20C0BABBBDA9D1DCF2167425DEFE3E843F822BFA26";
                when 27 => alpha_rom <= x"0C50E7D0A9BF57C37D26B52FD9C555DBDDF50860BA6BCE21918256CF2DC1";
                when 28 => alpha_rom <= x"185D6B8184FCC812AD0328E7BD9E91194536EA057834DABFAE2BCF5A230F";
                when 29 => alpha_rom <= x"30697FF84DF1E0F7409C5FB6ECAA96A20BCDD45E8685D56EEFFA2D231E1A";
                when 30 => alpha_rom <= x"60B9DF3B5596592C26C10F1AA99164240160B9DF3B5596592C26C10F1AA9";
                when 31 => alpha_rom <= x"C0DEB697726E9B1B8FA0B1ED524B59589846F067157BE0FB74D46588DA91";
                when 32 => alpha_rom <= x"9D5FD985E682120227BEAF17D11924044E61432EBF3248089CC2865C6364";
                when 33 => alpha_rom <= x"276186B89107F53AB50FD015F1A62C2D0A6BED55C4C3360CB9B666738224";
                when 34 => alpha_rom <= x"4E99444FD7DD0B980AD69392DC45014E99444FD7DD0B980AD69392DC4501";
                when 35 => alpha_rom <= x"9C5E1A84FF59E903B9E22E911CEB2605D63B72AE24206A0F674D96EF6C60";
                when 36 => alpha_rom <= x"2565D0A896C3AD272F1A15DBF23660614421F159CF0CA186A9B3A67D8FB9";
                when 37 => alpha_rom <= x"4A89CE52378A10D4787C4957481DC1D393E419F4CD8CB1C5E68DFB4C28DF";
                when 38 => alpha_rom <= x"941E3E49AE3DE88C7F33633816EAB9434FF1796C27BCBD29370940EED33B";
                when 39 => alpha_rom <= x"3578EDE464FB2DBAD9A9F1F2AD250F3E9282F52650B6B8B359362765CE55";
                when 40 => alpha_rom <= x"6AFD3BE61C2C03BE1A4D37247405DF2ED7596C9C0F7C7264EBB4B9118496";
                when 41 => alpha_rom <= x"D4D3C5C6A7CF9DCA3E72C88BC95F1A9ADC3D13A0D99EAB56209F7F85E559";
                when 42 => alpha_rom <= x"B56B66FC59AD35E7C591A63625783BBFDDCF270FED73387D60653EE4072C";
                when 43 => alpha_rom <= x"77B1177BEF089FE1B8FF2B408C5BA9AB453A14E2213112CDA04315959026";
                when 44 => alpha_rom <= x"EEFEB8E3AC3A28AF15377A2DDE3455320B0CBC7C73E08325FD97FC7902C1";
                when 45 => alpha_rom <= x"C1DFA9962426B91A55642C600F3B915901C1DFA9962426B91A55642C600F";
                when others => alpha_rom <= x"010101010101010101010101010101010101010101010101010101010101";
            end case;
        end if;
    end process;
end generate;
    
gen_alpha_192: if PARAM_SET = HQC_192 generate
     process(clk_i)
     begin
         if rising_edge(clk_i) then
             case to_integer(din_cnt) is
                 when 0  => alpha_rom <= x"0101010101010101010101010101010101010101010101010101010101010101";
                 when 1  => alpha_rom <= x"020408102040801D3A74E8CD8713264C982D5AB475EAC98F03060C183060C09D";
                 when 2  => alpha_rom <= x"0410401D74CD134C2DB4EA8F0618609D4E25946AB5EE9F460514505D69B9DE5F";
                 when 3  => alpha_rom <= x"08403ACD262D758F0C60272535B5C1460A50BAB9A1612F650F78E76B7FDFB6D9";
                 when 4  => alpha_rom <= x"101DCD4CB48F189D256AEE46145DB95F99651EFD6BFE5BD9110DD081F83B9785";
                 when 5  => alpha_rom <= x"207426B403609C6AC105A0B9BE5E0FFDD6DFE2111A677C3B332EA9844D5572E6";
                 when 6  => alpha_rom <= x"40CD2D8F6025B54650B96165786BDFD944D03E3B66B821A855E4BFFCF1966E82";
                 when 7  => alpha_rom <= x"801375189CB58C5DA15E3C6BA3431A8193666D842939D1FCFF6257C8E0599B12";
                 when 8  => alpha_rom <= x"1D4C8F9D6A465D5F65FDFED90D813B854FA849E6FCE395821C51C312F72C1B02";
                 when 9  => alpha_rom <= x"3A2D0C25C150A165E7DF86D0ED66A9A892BFB3965707A6C324FB7DAD40268F27";
                 when 10 => alpha_rom <= x"74B4606A05B95EFDDF11673B2E8455E6D796AE1C59ACF42C6C2026039CC1A0BE";
                 when 11 => alpha_rom <= x"E8EA27EEA0613CFE866776B8543991E3DC07A2ACF5B0473AB4C0B5285F0FB1AF";
                 when 12 => alpha_rom <= x"CD8F2546B9656BD9D03BB8A8E4FC9682DDC33D2CAD3A7527C1BA2FE7B61AED17";
                 when 13 => alpha_rom <= x"87063514BE78A30DED2E54E4E562645145FB83202DC0EEBA5EBBD9BDECA952D1";
                 when 14 => alpha_rom <= x"1318B55D5E6B4381668439FC62C859120BADE8033528C2E7E2BDC59EAA914B19";
                 when 15 => alpha_rom <= x"2660C1B90FDF1A3BA95591966459242C012660C1B90FDF1A3BA9559196645924";
                 when 16 => alpha_rom <= x"4C9D465FFDD98185A8E6E38251122C0298278CBEE7AF1F174DD1DB19A2245804";
                 when 17 => alpha_rom <= x"984E0A99D644934F92D7DCDD450B01984E0A99D644934F92D7DCDD450B01984E";
                 when 18 => alpha_rom <= x"2D255065DFD066A8BF9607C3FBAD26270A2F7F1AC51573DB64F2F536CD604661";
                 when 19 => alpha_rom <= x"5A94BA1EE23E6D49B3AEA23D83E8608C997F3433A8636238AC1608EAD4B9F043";
                 when 20 => alpha_rom <= x"B46AB9FD113B84E6961CAC2C2003C1BED61A334D9137A724E97460055EDF672E";
                 when 21 => alpha_rom <= x"75B5A16B1A6629FC5759F5AD2D35B9E744C5A8916EA63D362625BA78863B15BF";
                 when 22 => alpha_rom <= x"EAEE61FE67B839E307ACB03AC0280FAF93156337A67AD82D6ADE6B3485557B32";
                 when 23 => alpha_rom <= x"C99F2F5B7C21D195A6F44775EEC2DF1F4F7362A73DD85AB5BEFECEDAD596E048";
                 when 24 => alpha_rom <= x"8F4665D93BA8FC82C32C3A27BAE71A1792DB3824362DB561DF3E21BF6E59FB08";
                 when 25 => alpha_rom <= x"03050F113355FF1C246CB4C15EE23B4DD764ACE9266ABEDF7C8491AEEF2C749C";
                 when 26 => alpha_rom <= x"0614780D2EE46251FB20C0BABBBDA9D1DCF2167425DEFE3E843F822BFA26D4C2";
                 when 27 => alpha_rom <= x"0C50E7D0A9BF57C37D26B52FD9C555DBDDF50860BA6BCE21918256CF2DC16586";
                 when 28 => alpha_rom <= x"185D6B8184FCC812AD0328E7BD9E91194536EA057834DABFAE2BCF5A230F885C";
                 when 29 => alpha_rom <= x"30697FF84DF1E0F7409C5FB6ECAA96A20BCDD45E8685D56EEFFA2D231E1ADA63";
                 when 30 => alpha_rom <= x"60B9DF3B5596592C26C10F1AA99164240160B9DF3B5596592C26C10F1AA99164";
                 when 31 => alpha_rom <= x"C0DEB697726E9B1B8FA0B1ED524B59589846F067157BE0FB74D46588DA91C890";
                 when 32 => alpha_rom <= x"9D5FD985E682120227BEAF17D11924044E61432EBF3248089CC2865C63649010";
                 when 33 => alpha_rom <= x"276186B89107F53AB50FD015F1A62C2D0A6BED55C4C3360CB9B6667382240825";
                 when 34 => alpha_rom <= x"4E99444FD7DD0B980AD69392DC45014E99444FD7DD0B980AD69392DC45014E99";
                 when 35 => alpha_rom <= x"9C5E1A84FF59E903B9E22E911CEB2605D63B72AE24206A0F674D96EF6C60BE11";
                 when 36 => alpha_rom <= x"2565D0A896C3AD272F1A15DBF23660614421F159CF0CA186A9B3A67D8FB9D9B8";
                 when 37 => alpha_rom <= x"4A89CE52378A10D4787C4957481DC1D393E419F4CD8CB1C5E68DFB4C28DFCCC6";
                 when 38 => alpha_rom <= x"941E3E49AE3DE88C7F33633816EAB9434FF1796C27BCBD29370940EED33BB7C8";
                 when 39 => alpha_rom <= x"3578EDE464FB2DBAD9A9F1F2AD250F3E9282F52650B6B8B359362765CE55573D";
                 when 40 => alpha_rom <= x"6AFD3BE61C2C03BE1A4D37247405DF2ED7596C9C0F7C7264EBB4B9118496AC20";
                 when 41 => alpha_rom <= x"D4D3C5C6A7CF9DCA3E72C88BC95F1A9ADC3D13A0D99EAB56209F7F85E559D84A";
                 when 42 => alpha_rom <= x"B56B66FC59AD35E7C591A63625783BBFDDCF270FED73387D60653EE4072C0C2F";
                 when 43 => alpha_rom <= x"77B1177BEF089FE1B8FF2B408C5BA9AB453A14E2213112CDA043159590266922";
                 when 44 => alpha_rom <= x"EEFEB8E3AC3A28AF15377A2DDE3455320B0CBC7C73E08325FD97FC7902C1E16D";
                 when 45 => alpha_rom <= x"C1DFA9962426B91A55642C600F3B915901C1DFA9962426B91A55642C600F3B91";
                 when 46 => alpha_rom <= x"9F5B2195F475C21F73A7D8B5FEDA964898A1BD723883946B2EE38A87D21AAA8D";
                 when 47 => alpha_rom <= x"237115A5EB0C8976FCEF8050225264B04EE785FF8A136FD0727036D4FEA9627A";
                 when 48 => alpha_rom <= x"46D9A8822C27E717DB242D613EBF59080A8629647D256BB8963D752FED91F240";
                 when 49 => alpha_rom <= x"8C4329C8E935FE9E6EEB3078CCE3245A99ED3FEF3A6968E4A78E46AF9A64FA94";
                 when 50 => alpha_rom <= x"0511551C6CC1E24D64E96ADF84AE2C9CD6A937EB60FD2E96F4030F33FF24B45E";
                 when 51 => alpha_rom <= x"0A4492DD010A4492DD010A4492DD010A4492DD010A4492DD010A4492DD010A44";
                 when 52 => alpha_rom <= x"140DE45120BABDD1F274DE3E3F2B26C293B309B46597E33D033C1731F360D3DA";
                 when 53 => alpha_rom <= x"2834737974A1F8E58AB4CA664BF760BB4F57B06AB69A0EAD0588E4A280B91F3F";
                 when 54 => alpha_rom <= x"50D0BFC3262FC5DBF5606B2182CFC18692A640B93EFC8A750F17C48B25DFA807";
                 when 55 => alpha_rom <= x"A06791ACB40F2E372C6AE255A720B97CD72403FDA9AEE9C111725974BE3BFFF4";
                 when others => alpha_rom <= x"0101010101010101010101010101010101010101010101010101010101010101";
             end case;
         end if;
     end process;
end generate;
 
gen_alpha_256: if PARAM_SET = HQC_256 generate
     process(clk_i)
     begin
         if rising_edge(clk_i) then
             case to_integer(din_cnt) is
                 when 0  => alpha_rom <= x"01010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101";
                 when 1  => alpha_rom <= x"020408102040801D3A74E8CD8713264C982D5AB475EAC98F03060C183060C09D274E9C254A94356AD4B577EEC19F23468C050A142850A05DBA69";
                 when 2  => alpha_rom <= x"0410401D74CD134C2DB4EA8F0618609D4E25946AB5EE9F460514505D69B9DE5F61995E65891E78FDD36BB1FEDF5B71D94311440D34D067813EF8";
                 when 3  => alpha_rom <= x"08403ACD262D758F0C60272535B5C1460A50BAB9A1612F650F78E76B7FDFB6D986441AD0CE3EED3BC56617B8A92115A8295592E473BF91FCB3F1";
                 when 4  => alpha_rom <= x"101DCD4CB48F189D256AEE46145DB95F99651EFD6BFE5BD9110DD081F83B9785B84F84A85249E4E6C6FC7BE39695A582C81CDD5179C3AC123DF7";
                 when 5  => alpha_rom <= x"207426B403609C6AC105A0B9BE5E0FFDD6DFE2111A677C3B332EA9844D5572E691D7FF9637AE641CA759EFAC24F4EB2CE96C01207426B403609C";
                 when 6  => alpha_rom <= x"40CD2D8F6025B54650B96165786BDFD944D03E3B66B821A855E4BFFCF1966E8207DD59C38A3DFB2CCFAD083A26750C2735C10ABAA12F0FE77FB6";
                 when 7  => alpha_rom <= x"801375189CB58C5DA15E3C6BA3431A8193666D842939D1FCFF6257C8E0599B12F50BE9AD10E82D039D359F28B9C289E7FEE244BDF8C52E9EA8AA";
                 when 8  => alpha_rom <= x"1D4C8F9D6A465D5F65FDFED90D813B854FA849E6FCE395821C51C312F72C1B023A980327D48CBABECAE7E1AF1A1F76179E4D92D1E5DB371938A2";
                 when 9  => alpha_rom <= x"3A2D0C25C150A165E7DF86D0ED66A9A892BFB3965707A6C324FB7DAD40268F27B50AB92F787FD91A3EC5B8155573FCDB6E64DDF28AF52C3608CD";
                 when 10 => alpha_rom <= x"74B4606A05B95EFDDF11673B2E8455E6D796AE1C59ACF42C6C2026039CC1A0BE0FD6E21A7C33A94D7291FF3764A7EF24EBE90174B4606A05B95E";
                 when 11 => alpha_rom <= x"E8EA27EEA0613CFE866776B8543991E3DC07A2ACF5B0473AB4C0B5285F0FB1AFD0932E154963F137C8A62B7A2CD8802D306A0ADECA6BE234ED85";
                 when 12 => alpha_rom <= x"CD8F2546B9656BD9D03BB8A8E4FC9682DDC33D2CAD3A7527C1BA2FE7B61AED17159291DB5738F2248B36402D60B5506178DF443E662155BFF16E";
                 when 13 => alpha_rom <= x"87063514BE78A30DED2E54E4E562645145FB83202DC0EEBA5EBBD9BDECA952D1F1DC1CF24816AD74C9258CDE0FFE223ECC84923F4B82A72BF5FA";
                 when 14 => alpha_rom <= x"1318B55D5E6B4381668439FC62C859120BADE8033528C2E7E2BDC59EAA914B19A645EB361DEA25055F785B343BDA52BFE3AEDD2BF7CF205A2723";
                 when 15 => alpha_rom <= x"2660C1B90FDF1A3BA95591966459242C012660C1B90FDF1A3BA95591966459242C012660C1B90FDF1A3BA95591966459242C012660C1B90FDF1A";
                 when 16 => alpha_rom <= x"4C9D465FFDD98185A8E6E38251122C0298278CBEE7AF1F174DD1DB19A22458042D4E0561D3433E2E9ABFAB325948B0085A9C0AC2BB867C5C2963";
                 when 17 => alpha_rom <= x"984E0A99D644934F92D7DCDD450B01984E0A99D644934F92D7DCDD450B01984E0A99D644934F92D7DCDD450B01984E0A99D644934F92D7DCDD45";
                 when 18 => alpha_rom <= x"2D255065DFD066A8BF9607C3FBAD26270A2F7F1AC51573DB64F2F536CD6046616B443B21E4F182593DCF3A0CC1A1E786EDA992B357A6247D408F";
                 when 19 => alpha_rom <= x"5A94BA1EE23E6D49B3AEA23D83E8608C997F3433A8636238AC1608EAD4B9F043ED4F72F11979F56C132714BCDFBD85293F37DD09B04003EEA1D3";
                 when 20 => alpha_rom <= x"B46AB9FD113B84E6961CAC2C2003C1BED61A334D9137A724E97460055EDF672E55D7AE59F46C269CA00FE27CA972FF64EFEB01B46AB9FD113B84";
                 when 21 => alpha_rom <= x"75B5A16B1A6629FC5759F5AD2D35B9E744C5A8916EA63D362625BA78863B15BFC4DD24CFCD27500FD9ED217396388A7D3A600A65B63EA9E4DB07";
                 when 22 => alpha_rom <= x"EAEE61FE67B839E307ACB03AC0280FAF93156337A67AD82D6ADE6B3485557B32C30B200C8CBCB67C9E7331E02483132569FD44979AFCAE79FB02";
                 when 23 => alpha_rom <= x"C99F2F5B7C21D195A6F44775EEC2DF1F4F7362A73DD85AB5BEFECEDAD596E04836986AA1B1BDB872AB38128326946F6B682E92E30E8AE98725D2";
                 when 24 => alpha_rom <= x"8F4665D93BA8FC82C32C3A27BAE71A1792DB3824362DB561DF3E21BF6E59FB080C0A0F86C529B364567DCD25B96BD0B8E496DD3DAD75C12FB6ED";
                 when 25 => alpha_rom <= x"03050F113355FF1C246CB4C15EE23B4DD764ACE9266ABEDF7C8491AEEF2C749CB9D667A9E63759EB2060A0FD1A2E7296A7F40103050F113355FF";
                 when 26 => alpha_rom <= x"0614780D2EE46251FB20C0BABBBDA9D1DCF2167425DEFE3E843F822BFA26D4C2B6934DB38D0936B49F65439755E3703D8E030A3C88177231A6F3";
                 when 27 => alpha_rom <= x"0C50E7D0A9BF57C37D26B52FD9C555DBDDF50860BA6BCE21918256CF2DC16586669296A6FB4027B97F3E15FC648A3675460F4417E4C4598B3A25";
                 when 28 => alpha_rom <= x"185D6B8184FCC812AD0328E7BD9E91194536EA057834DABFAE2BCF5A230F885C73DCEF7D4CEE651185E495792C87D42FAF339231A28B74946171";
                 when 29 => alpha_rom <= x"30697FF84DF1E0F7409C5FB6ECAA96A20BCDD45E8685D56EEFFA2D231E1ADA6382456C8F28D3CE84E507900260D2FEED9AFFDDF38025BE71C549";
                 when 30 => alpha_rom <= x"60B9DF3B5596592C26C10F1AA99164240160B9DF3B5596592C26C10F1AA99164240160B9DF3B5596592C26C10F1AA99164240160B9DF3B559659";
                 when 31 => alpha_rom <= x"C0DEB697726E9B1B8FA0B1ED524B59589846F067157BE0FB74D46588DA91C890084EBED9CCB757ACD80C69E13BAA62F2FAB40AD31FA8FF538B87";
                 when 32 => alpha_rom <= x"9D5FD985E682120227BEAF17D11924044E61432EBF3248089CC2865C63649010259911B8C6C83D204A2F226D918D7A40945E44DA3F07F48035BC";
                 when 33 => alpha_rom <= x"276186B89107F53AB50FD015F1A62C2D0A6BED55C4C3360CB9B66673822408252F44A9FC38FBCDC178CEA8DB597D75507F3B926E56AD60A1D917";
                 when 34 => alpha_rom <= x"4E99444FD7DD0B980AD69392DC45014E99444FD7DD0B980AD69392DC45014E99444FD7DD0B980AD69392DC45014E99444FD7DD0B980AD69392DC";
                 when 35 => alpha_rom <= x"9C5E1A84FF59E903B9E22E911CEB2605D63B72AE24206A0F674D96EF6C60BE11A9D7A72CB4A0DF33E664F474C1FD7C5537AC019C5E1A84FF59E9";
                 when 36 => alpha_rom <= x"2565D0A896C3AD272F1A15DBF23660614421F159CF0CA186A9B3A67D8FB9D9B8FCDD2C75BAB61791388B2D50DF66BF07FB260A7FC57364F5CD46";
                 when 37 => alpha_rom <= x"4A89CE52378A10D4787C4957481DC1D393E419F4CD8CB1C5E68DFB4C28DFCCC6380BB4BA715CFCA7B08F6F43A97BA2CF18BE4442E3F26C9D2F34";
                 when 38 => alpha_rom <= x"941E3E49AE3DE88C7F33633816EAB9434FF1796C27BCBD29370940EED33BB7C8FB98A0B65CE5A6E918610D2A962B02353C7C92417ACD05FE66C6";
                 when 39 => alpha_rom <= x"3578EDE464FB2DBAD9A9F1F2AD250F3E9282F52650B6B8B359362765CE55573DCD0ADF17FCA6CF602FD0296E243A467F6691DD7D0C611AA8C48A";
                 when 40 => alpha_rom <= x"6AFD3BE61C2C03BE1A4D37247405DF2ED7596C9C0F7C7264EBB4B9118496AC20C1D63391A7E9605E6755AEF426A0E2A9FFEF016AFD3BE61C2C03";
                 when 41 => alpha_rom <= x"D4D3C5C6A7CF9DCA3E72C88BC95F1A9ADC3D13A0D99EAB56209F7F85E559D84A7893E638B0182F67AA82F35AB9222AC412740A5B6DF1EF02B5BB";
                 when 42 => alpha_rom <= x"B56B66FC59AD35E7C591A63625783BBFDDCF270FED73387D60653EE4072C0C2FCE92648B8F61D05582FB75A11A2957F52DB944A86E3D26BA8615";
                 when 43 => alpha_rom <= x"77B1177BEF089FE1B8FF2B408C5BA9AB453A14E2213112CDA043159590266922A8DCF42D6F0D29AEF3755F685519CB8FC26792C8160C5E1FE40E";
                 when 44 => alpha_rom <= x"EEFEB8E3AC3A28AF15377A2DDE3455320B0CBC7C73E08325FD97FC7902C1E16DDB457450432A6EF45AA168AA64161865F8E6DD1B4AE733E5F204";
                 when 45 => alpha_rom <= x"C1DFA9962426B91A55642C600F3B915901C1DFA9962426B91A55642C600F3B915901C1DFA9962426B91A55642C600F3B915901C1DFA9962426B9";
                 when 46 => alpha_rom <= x"9F5B2195F475C21F73A7D8B5FEDA964898A1BD723883946B2EE38A87D21AAA8D7D4EFD667B2B3AA022291916601EECFCF9200AAF5457EB0665C7";
                 when 47 => alpha_rom <= x"237115A5EB0C8976FCEF8050225264B04EE785FF8A136FD0727036D4FEA9627A75997CBFA20246E22A57CB180FECE5C31DA044A4C87D9CD317E3";
                 when 48 => alpha_rom <= x"46D9A8822C27E717DB242D613EBF59080A8629647D256BB8963D752FED91F24050445507CF357FA9C4F58F653BFCC33ABA1A923836B5DF216EFB";
                 when 49 => alpha_rom <= x"8C4329C8E935FE9E6EEB3078CCE3245A99ED3FEF3A6968E4A78E46AF9A64FA947F4F37FB183C66FF122DC2F891F91DBA3472DD4723D94D327D4A";
                 when 50 => alpha_rom <= x"0511551C6CC1E24D64E96ADF84AE2C9CD6A937EB60FD2E96F4030F33FF24B45E3BD7AC26BE7C91EF74B967E65920A01A72A7010511551C6CC1E2";
                 when 51 => alpha_rom <= x"0A4492DD010A4492DD010A4492DD010A4492DD010A4492DD010A4492DD010A4492DD010A4492DD010A4492DD010A4492DD010A4492DD010A4492";
                 when 52 => alpha_rom <= x"140DE45120BABDD1F274DE3E3F2B26C293B309B46597E33D033C1731F360D3DA6E0B9C7F42417D6A5BA8C81BC1AFA438470544395308A06873B2";
                 when 53 => alpha_rom <= x"2834737974A1F8E58AB4CA664BF760BB4F57B06AB69A0EAD0588E4A280B91F3F56985EC5E37A0CFD6D6E164ADF54C8362311925310BA6763C313";
                 when 54 => alpha_rom <= x"50D0BFC3262FC5DBF5606B2182CFC18692A640B93EFC8A750F17C48B25DFA807AD0A1A73F2CD613BF13D0CE7A9577DB5D955DD08BACE91562D65";
                 when 55 => alpha_rom <= x"A06791ACB40F2E372C6AE255A720B97CD72403FDA9AEE9C111725974BE3BFFF460D684646C051AE6EF265E3396EB9CDF4D1C01A06791ACB40F2E";
                 when 56 => alpha_rom <= x"5D81FC1203E79E19360534BF2B5A0F5CDC7DEE11E479872F33318B9471555380A193FFF59DFEA81C02BA1FE52406D321326C0A686356B41EB8A5";
                 when 57 => alpha_rom <= x"BA3EB33D607FA83808B9EDF1F527DF29DD40A13BDBFB25B655A63A61C5968B35D99259CD2F66C42CB586E4F22665176E7DC14473C32D0FB857CF";
                 when 58 => alpha_rom <= x"69F8F1F79CB6AAA2CD5E856EFA231A63458FD3840702D2EDFFF32571495987BC17DCE94634C68A03BB150E04B9C7E3FB4AE292B213652EA5CF8C";
                 when 59 => alpha_rom <= x"D2C7DBCB6A86B79B75FD4207046F3B4B0BB522E656C9D3151C10A1EC312CEE88BF45036B547040BE97C4B09F1AC6090CB14DDD1DC26637FA4668";
                 when 60 => alpha_rom <= x"B93B962CC11A912460DF5559260FA96401B93B962CC11A912460DF5559260FA96401B93B962CC11A912460DF5559260FA96401B93B962CC11A91";
                 when 61 => alpha_rom <= x"6FECC4FA05CE7BF33511D18A18E155B29878421C40C285576C5DEDAB16C1347E3D4EE2E49BC96B4D53CDCADA6402DEC595E90A81F6FB6A22BF09";
                 when 62 => alpha_rom <= x"DE976E1BA0ED4B5846677BFBD48891904ED9B7AC0CE1AAF2B4D3A853870F9E0E40992E828E6FC5378350F8AB2C23BDB3F36A44C64827E2D55606";
                 when 63 => alpha_rom <= x"A16657ADB9C56E36BA3BC4CF50ED967D0A3EDB2C46CEF18BC1D0B3FBB51AFCF53544913D2586BF2427D9738A60B6E4560CDF92C38F7F55F2756B";
                 when 64 => alpha_rom <= x"5F858202BE171904612E3208C25C641099B8C8202F6D8D405EDA0780BCA90E1D654F1C3ACA9E3874892170E80F42E0CD1E84DD873C15A713782A";
                 when 65 => alpha_rom <= x"BE2E64205EA91C740F84A726FD4D59B4D655EF03DF72AC60E2E6249C1191F46A1AD7EBC167FF2C057C96E9A03B376CB933AE01BE2E64205EA91C";
                 when 66 => alpha_rom <= x"61B8073A0F15A62D6B55C30CB673242544FCFBC1CEDB7D503B6EADA11764406521DD26E729F28FDFE48A278691F5B5D0F12C0AEDC436B9668208";
                 when 67 => alpha_rom <= x"C2DA3887FD29F906B6E6903534F62C14936E47BEB80EE8784D798FA3B7244A0DB30B05ED95D8A12E8D3A1E5459EAE1E4099C44E5CB467C62366F";
                 when 68 => alpha_rom <= x"994FDD98D692454E44D70B0A93DC01994FDD98D692454E44D70B0A93DC01994FDD98D692454E44D70B0A93DC01994FDD98D692454E44D70B0A93";
                 when 69 => alpha_rom <= x"2F21A675DF733DB5CE9636A1B838266B928A251AF17DBA66643A7829C36086FC8B0A3B57086515598FB6BFF5C13EC4AD61A9DD2D7FE42435D0DB";
                 when 70 => alpha_rom <= x"5E845903E291EB053BAE200F4DEF6011D72CA0336474FD55AC9C1AFFE9B92E1C26D672246A67966CBEA9A7B4DFE6F4C17C37015E845903E291EB";
                 when 71 => alpha_rom <= x"BC2AF23011B3B069171C4C7FB77AC1F8DC08894DC39D88F1E96FB8E05ADFD1F74693AE403C52569C34DB1B5FA953EAB6C6EB0AEC193AFDAA8A94";
                 when 72 => alpha_rom <= x"65A8C3271ADB366121590C86B37DB9B8DD75B6918B506607267F73F5463B823AE79224B53E6E080F295625D096AD2F15F26044F1CFA1A9A68FD9";
                 when 73 => alpha_rom <= x"CA9A564A67C4028929AC94CE95040F5245358137081EA48A6A1F6E103C5509D43EDC2078AA12B57CA540F0492477F85780FD9248EEEDAE1DE739";
                 when 74 => alpha_rom <= x"89528AD47C571DD3E4F48CC58D4CDFC60BBA5CA78F437BCFBE42F29D34968ECA29456A3EA580E7727A46ECC826E1638B5D2EDDC9AFB3E95F2179";
                 when 75 => alpha_rom <= x"0F5524C13B6426DF912CB9A959601A96010F5524C13B6426DF912CB9A959601A96010F5524C13B6426DF912CB9A959601A96010F5524C13B6426";
                 when 76 => alpha_rom <= x"1E493D8C3338EA43F16CBC2909EE3BC898B6E5E9612A2B357C41CDFEC62C6F9EF24E676E80BB73EB5DB851301A31047839F40ACCE08F11E3ADCA";
                 when 77 => alpha_rom <= x"3C39F5282EA63034C420D373CB69A9794ECEA5747FC658A1849B35F819265BE5CF994D8AEE7607B4AFF1D8CA55908C66E003444B027872F7505C";
                 when 78 => alpha_rom <= x"78E4FBBAA9F2253E8226B6B33665553D0A17A660D06E3A7F917D61A88AC1C5388F449608E7738BB921C335ED642DD9F1AD0F92F550B85927CE57";
                 when 79 => alpha_rom <= x"F0B78B6F845677EC38030DC480B191FA9929480517519DCEAE13B67BD80F39F3BA4FEF35C78D75114B08D3D12C5F548A9F33DD18686E74E1FC83";
                 when 80 => alpha_rom <= x"FDE62CBE4D24052E599C7C64B4119620D691E95E55F4A0A9EF6A3B1C031A3774DFD76C0F72EBB984ACC133A76067AE26E2FF01FDE62CBE4D2405";
                 when 81 => alpha_rom <= x"E7BF7D2F55F5BA2156C166A6273E647544C43ADFB3AD78732C61293D50A9C3B5C5DD60CE822D8696407FFC360FE48BA1A8240AB8F2353B380CD0";
                 when 82 => alpha_rom <= x"D3C6CFCA728B5F9A3DA09E569F85594A93381867825A22C4745BF102BB918389E40BBE297A5D21AC2317B2943B7030CE19B44495E8B6FF046B3F";
                 when 83 => alpha_rom <= x"BB3F363CE67DBC398BBE52F5D22A24284F56232EF2D497A69CC738308164C934579811C4E871DB20FEB38ED3911B1E73B05E92CB5F29F4691512";
                 when 84 => alpha_rom <= x"6BFCADE7913678BFCF0F737D65E42C2F928B6155FBA129F5B9A83DBA152450218A0AA95646B8C3C117F2B5665935C5A6253BDD27ED38603E070C";
                 when 85 => alpha_rom <= x"D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6D701D6";
                 when 86 => alpha_rom <= x"B17B08E1FF405BAB3AE231CD43952622DC2D0DAE7568198F67C80C1F0E60F8702793A725EC513533B2B585F9C15C9B46DAAC0A9E09508448BA54";
                 when 87 => alpha_rom <= x"7FF140B696CD866E2D1A828FCE0760EDDD25C559B517C346A98A50153DB929FB61922C6573CF7891AD6BB308DFDB3AD9C426445775D0640C3E38";
                 when 88 => alpha_rom <= x"FEE33AAF372D34320C7CE0259779C16D45502AF4A1AA1665E61BE7E504DFABE886DCB4D0C830EDA79466F923A9095DA8F7BE925889BF6CBBB310";
                 when 89 => alpha_rom <= x"E1ABCD22AE8F1F702533F9469E48B9A40B65D16C6BF680D9375AD08DC03BA277B845A0A8F3C2E4E9F0FC04A396138882067CDD94CCC305423DDE";
                 when others => alpha_rom <= x"01010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101010101";
             end case;
         end if;
     end process;
end generate;
 
end rtl;