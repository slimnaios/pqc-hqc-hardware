--/*Main conversions:

--Parameter calculations: Helper functions calculate all dependent parameters (MULTIPLICITY, IN_AW, OUT_AW, EAS_W, HAD_W) based on PARAM_SECURITY
--Component declarations: All four submodules are declared as components with their respective interfaces
--Module instantiation: Each Verilog module instance is converted to a VHDL component instance with generic map and port map
--Signal interconnections: Internal signals connect the pipeline stages:

--Control ? Expand/Sum ? Hadamard ? Find Peaks ? Control



--Architecture overview:
--This top-level module implements the complete Reed-Muller decoder pipeline for HQC:

--hqc_rmdecod_ctrl: Controls data flow, reads from input RAM, writes to output RAM
--hqc_rmdecod_expnsum: Expands and sums the received samples (soft decisions)
--hqc_rmdecod_hadamard: Performs Fast Hadamard Transform (7 layers)
--hqc_rmdecod_findpeaks: Finds the maximum correlation peaks to decode bits

--Data flow:

--Input RAM ? [CTRL] ? [EXPAND/SUM] ? [HADAMARD] ? [FIND_PEAKS] ? [CTRL] ? Output RAM
--              ?                                                      ?
--              ????????????????? orchestration ??????????????????????
--The control module orchestrates the entire decoding process with handshaking signals

--This is the complete soft-decision Reed-Muller decoder used in the HQC (Hamming Quasi-Cyclic) post-quantum cryptosystem for error correction.
--It corrects errors in received codewords by finding the most likely transmitted message using correlation-based decoding.
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity hqc_rmdecod_top is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i          : in  std_logic;
        rst_ni         : in  std_logic;
        start_i        : in  std_logic;
        busy_o         : out std_logic;
        done_o         : out std_logic;
        -- Input RAM
        ram_din_i      : in  std_logic_vector(127 downto 0);
        ram_din_rd_o   : out std_logic;
        ram_din_addr_o : out std_logic_vector;--(IN_AW-1 downto 0);
        -- Output RAM
        ram_dout_wr_o  : out std_logic;
        ram_dout_o     : out std_logic_vector(7 downto 0);
        ram_dout_addr_o: out std_logic_vector--(OUT_AW-1 downto 0)
    );
end hqc_rmdecod_top;

architecture rtl of hqc_rmdecod_top is

-- Parameter calculations
constant MULTIPLICITY : integer := get_MULTIPLICITY(PARAM_SET);
constant IN_AW        : integer := get_IN_AW(PARAM_SET);
constant OUT_AW       : integer := get_OUT_AW(PARAM_SET);
constant EAS_W        : integer := get_EAS_W(PARAM_SET);
constant HAD_W        : integer := 1 + EAS_W + 7;

-- Internal signals
signal eas_start       : std_logic;
signal eas_start_ready : std_logic;
signal eas_din         : std_logic_vector(127 downto 0);
signal eas_din_valid   : std_logic;
signal eas_din_ready   : std_logic;
signal eas_dout0       : std_logic_vector(EAS_W-1 downto 0);
signal eas_dout1       : std_logic_vector(EAS_W-1 downto 0);
signal eas_dout_valid  : std_logic;
signal had_start       : std_logic;
signal had_dout0       : std_logic_vector(HAD_W-1 downto 0);
signal had_dout1       : std_logic_vector(HAD_W-1 downto 0);
signal had_dout_valid  : std_logic;
signal peak_start      : std_logic;
signal peak_valid      : std_logic;
signal peak_dout       : std_logic_vector(7 downto 0);

begin
 -- Expand and Sum module
EXPANSE_AND_SUM : hqc_rmdecod_expnsum
    generic map (
        PARAM_SET => PARAM_SET
    )
    port map (
        clk_i          => clk_i,
        rst_ni         => rst_ni,
        start_i        => eas_start,
        start_ready_o  => eas_start_ready,
        din_i          => eas_din,
        din_valid_i    => eas_din_valid,
        din_ready_o    => eas_din_ready,
        dout_start_o   => had_start,
        dout0_o        => eas_dout0,
        dout1_o        => eas_dout1,
        dout_valid_o   => eas_dout_valid,
        dout_ready_i   => '1'
    );

-- Hadamard Transform module
HADAMARD : hqc_rmdecod_hadamard
    generic map (
        PARAM_SET => PARAM_SET
    )
    port map (
        clk_i         => clk_i,
        rst_ni        => rst_ni,
        start_i       => had_start,
        din0_i        => eas_dout0,
        din1_i        => eas_dout1,
        din_valid_i   => eas_dout_valid,
        dout_start_o  => peak_start,
        dout0_o       => had_dout0,
        dout1_o       => had_dout1,
        dout_valid_o  => had_dout_valid
    );

-- Find Peaks module
FIND_PEAKS : hqc_rmdecod_findpeaks
    generic map (
        PARAM_SET => PARAM_SET
    )
    port map (
        clk_i         => clk_i,
        rst_ni        => rst_ni,
        start_i       => peak_start,
        din0_i        => had_dout0,
        din1_i        => had_dout1,
        din_valid_i   => had_dout_valid,
        dout_o        => peak_dout,
        dout_valid_o  => peak_valid
    );

-- Control module
RM_DECOD_CTRL : hqc_rmdecod_ctrl
    generic map (
        PARAM_SET => PARAM_SET
    )
    port map (
        clk_i              => clk_i,
        rst_ni             => rst_ni,
        start_i            => start_i,
        busy_o             => busy_o,
        done_o             => done_o,
        ram_din_i          => ram_din_i,
        ram_din_rd_o       => ram_din_rd_o,
        ram_din_addr_o     => ram_din_addr_o,
        eas_din_o          => eas_din,
        eas_start_ready_i  => eas_start_ready,
        eas_start_o        => eas_start,
        eas_din_valid_o    => eas_din_valid,
        eas_din_ready_i    => eas_din_ready,
        peak_valid_i       => peak_valid,
        peak_dout_i        => peak_dout,
        ram_dout_wr_o      => ram_dout_wr_o,
        ram_dout_o         => ram_dout_o,
        ram_dout_addr_o    => ram_dout_addr_o
    );
end rtl;
