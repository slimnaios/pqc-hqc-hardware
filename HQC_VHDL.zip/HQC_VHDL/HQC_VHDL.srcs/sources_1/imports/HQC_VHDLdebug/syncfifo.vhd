--/*Main conversions:

--1. **Memory array**: Created `fifo_mem_t` type for the FIFO storage array

--2. **Address arithmetic**: Changed to `unsigned` type for proper arithmetic operations

--3. **Valid signals**: `wr_v` and `rd_v` determine when actual write/read occurs based on full/empty conditions

--4. **Full/Empty logic**: 
--   - **Full**: Set when next write address would equal read address
--   - **Empty**: Set when next read address would equal write address

--5. **Bypass path**: `wr_rd` signal enables direct write-to-read bypass when writing to an empty FIFO

--**Key features:**

--- **Synchronous**: All operations occur on clock edge
--- **Simultaneous read/write**: Can read and write in same cycle
--- **Zero-cycle latency bypass**: When writing to empty FIFO, data appears immediately on output
--- **Pointer-based**: Uses read/write address pointers that wrap around

--**Algorithm:**
--```
--Write: if (not full OR reading): write data, increment wr_addr
--Read:  if (not empty OR writing): read data, increment rd_addr
--Full:  when next_wr_addr == rd_addr
--Empty: when next_rd_addr == wr_addr

--This is a standard circular buffer FIFO implementation used throughout the Hadamard transform layers for buffering intermediate results.
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity syncfifo is
    generic (
        DW    : integer := 2*12;
        AW    : integer := 7;
        DEPTH : integer := 128  -- 2^AW
    );
    port (
        clk_i   : in  std_logic;
        rst_ni  : in  std_logic;
        wr_i    : in  std_logic;
        rd_i    : in  std_logic;
        din_i   : in  std_logic_vector(DW-1 downto 0);
        empty_o : out std_logic;
        full_o  : out std_logic;
        dout_o  : out std_logic_vector(DW-1 downto 0)
    );
end syncfifo;

architecture rtl of syncfifo is

    -- FIFO memory
    type fifo_mem_t is array (0 to DEPTH-1) of std_logic_vector(DW-1 downto 0);
    signal fifo : fifo_mem_t;
    
    -- Internal signals
    signal rd_data          : std_logic_vector(DW-1 downto 0);
    signal wr_data          : std_logic_vector(DW-1 downto 0);
    signal wr_addr          : unsigned(AW-1 downto 0) := (others => '0');
    signal next_wr_addr     : unsigned(AW-1 downto 0) := to_unsigned(1, AW);
    signal rd_addr          : unsigned(AW-1 downto 0) := (others => '0');
    signal next_rd_addr     : unsigned(AW-1 downto 0) := to_unsigned(1, AW);
    signal full             : std_logic := '0';
    signal empty            : std_logic := '1';
    signal wr_rd            : std_logic := '0';
    signal wr_v             : std_logic;
    signal rd_v             : std_logic;
    signal wr_addr_plus_one : unsigned(AW-1 downto 0);
    signal wr_addr_plus_two : unsigned(AW-1 downto 0);

begin

    -- Valid write and read signals
    wr_v <= wr_i and (not full or rd_i);
    rd_v <= rd_i and (not empty or wr_i);
    
    -- Address increment calculations
    wr_addr_plus_one <= wr_addr + 1;
    wr_addr_plus_two <= wr_addr + 2;
    
    ------------------------------------------------------------------------------
    -- Full logic
    ------------------------------------------------------------------------------
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                full <= '0';
            elsif rd_i = '1' then
                full <= full and wr_i;
            elsif wr_v = '1' then
                if next_wr_addr = rd_addr then
                    full <= '1';
                end if;
            end if;
        end if;
    end process;
    
    full_o <= full;
    
    ------------------------------------------------------------------------------
    -- Write address
    ------------------------------------------------------------------------------
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                wr_addr      <= (others => '0');
                next_wr_addr <= to_unsigned(1, AW);
            elsif wr_v = '1' then
                wr_addr      <= wr_addr_plus_one;
                next_wr_addr <= wr_addr_plus_two;
            end if;
        end if;
    end process;
    
    ------------------------------------------------------------------------------
    -- FIFO write
    ------------------------------------------------------------------------------
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if wr_v = '1' then
                fifo(to_integer(wr_addr)) <= din_i;
            end if;
        end if;
    end process;
    
    ------------------------------------------------------------------------------
    -- Empty logic
    ------------------------------------------------------------------------------
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                empty <= '1';
            elsif wr_i = '1' then
                if rd_i = '1' then
                    empty <= empty;
                else
                    empty <= '0';
                end if;
            elsif rd_v = '1' then
                if next_rd_addr = wr_addr then
                    empty <= '1';
                end if;
            end if;
        end if;
    end process;
    
    empty_o <= empty;
    
    ------------------------------------------------------------------------------
    -- Read address
    ------------------------------------------------------------------------------
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                rd_addr      <= (others => '0');
                next_rd_addr <= to_unsigned(1, AW);
            elsif rd_v = '1' then
                rd_addr      <= rd_addr + 1;
                next_rd_addr <= rd_addr + 2;
            end if;
        end if;
    end process;
    
    ------------------------------------------------------------------------------
    -- Data read
    ------------------------------------------------------------------------------
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rd_v = '1' then
                rd_data <= fifo(to_integer(rd_addr));
            end if;
        end if;
    end process;
    
    ------------------------------------------------------------------------------
    -- Write when empty or write and read before empty
    ------------------------------------------------------------------------------
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                wr_rd <= '0';
            elsif wr_i = '1' and (empty = '1' or (rd_v = '1' and rd_addr = wr_addr)) then
                wr_rd   <= '1';
                wr_data <= din_i;
            elsif rd_i = '1' then
                wr_rd <= '0';
            end if;
        end if;
    end process;
    
    -- Output multiplexer
    dout_o <= wr_data when wr_rd = '1' else rd_data;

end rtl;
