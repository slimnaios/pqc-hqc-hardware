library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity enc_dec is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk          : in  std_logic;
        rst          : in  std_logic;
        start        : in  std_logic;  -- 1 pulse start signal
        msg_in       : in  std_logic_vector((get_hqc_params(PARAM_SET).k1*8)-1 downto 0); --(K-1 downto 0);
        cdw_out_en   : in  std_logic;
        cdw_out_addr : in  std_logic_vector(clog2(get_hqc_params(PARAM_SET).n1)-1 downto 0); --(LOG_N1_BYTES-1 downto 0);
        dout_o       : out std_logic_vector((get_hqc_params(PARAM_SET).k1*8)-1 downto 0);--(DOUT_W-1 downto 0);  -- msg = {m[K-1],m[K-2],...,m[1],m[0]} with m[i] in byte
        dout_valid_o : out std_logic  -- output valid
    );
end enc_dec;

architecture rtl of enc_dec is

    -- Parameter calculations
    constant HQC_PARAMS   : hqc_params_t := get_hqc_params(PARAM_SET);
--    constant MULTIPLICITY : integer := get_MULTIPLICITY(PARAM_SET);
--    constant IN_AW        : integer := get_IN_AW(PARAM_SET);
    constant PARAM_K      : integer := HQC_PARAMS.k1;
--    constant DIN_W        : integer := 128;
--    constant DOUT_W       : integer := 8 * PARAM_K;
--    
--    -- Internal signals
      signal enc_done       : std_logic;      
      signal cdw	    : std_logic_vector(127 downto 0);
--    signal rm_busy        : std_logic;
--    signal rm_dout_done   : std_logic;
--    signal rm_dout_valid  : std_logic;
--    signal rm_dout        : std_logic_vector(7 downto 0);
--    signal rm_dout_addr   : std_logic_vector(7 downto 0);
--    signal rs_busy        : std_logic;
--    signal rs_done        : std_logic;
--    signal rs_dout        : std_logic_vector(DOUT_W-1 downto 0);
--    signal last_busy      : std_logic;
    
    -- Component declarations
component concat_code is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk           : in  std_logic;
        rst           : in  std_logic;
        start         : in  std_logic;
        msg_in        : in  std_logic_vector((get_hqc_params(PARAM_SET).k1*8)-1 downto 0); --(K-1 downto 0);
        cdw_out_en    : in  std_logic;
        cdw_out_addr  : in  std_logic_vector(clog2(get_hqc_params(PARAM_SET).n1)-1 downto 0); --(LOG_N1_BYTES-1 downto 0);
        cdw_out       : out std_logic_vector(127 downto 0);
        done          : out std_logic
    );
end component concat_code;

component hqc_decod_top is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i           : in  std_logic;
        rst_ni          : in  std_logic;
        start_i         : in  std_logic;  -- 1 pulse start signal
        busy_o          : out std_logic;  -- decoding is busy signal
        -- Input RAM, read
        ram_din_i       : in  std_logic_vector(127 downto 0);
        ram_din_rd_o    : out std_logic;
        ram_din_addr_o  : out std_logic_vector(get_IN_AW(PARAM_SET)-1 downto 0);
        -- Output data
        dout_o          : out std_logic_vector((get_hqc_params(PARAM_SET).k1*8)-1 downto 0);--(DOUT_W-1 downto 0);  -- msg = {m[K-1],m[K-2],...,m[1],m[0]} with m[i] in byte
        dout_valid_o    : out std_logic  -- output valid
    );
end component hqc_decod_top;

begin

    -- Encode
    ENC : concat_code
        generic map (
            PARAM_SET => PARAM_SET
        )
        port map (
            clk          => clk,
            rst          => rst,
            start        => start,
            msg_in       => msg_in,
            cdw_out_en   => '1',
            cdw_out_addr => (others =>'0'),
            cdw_out      => cdw,
            done  	 => enc_done
        );

    -- Decode
    DEC : hqc_decod_top
        generic map (
            PARAM_SET => PARAM_SET
        )
        port map (
            clk_i          => clk,
            rst_ni         => rst,
            start_i        => enc_done,
            busy_o         => open,
            ram_din_i      => cdw,
            ram_din_rd_o   => open,
            ram_din_addr_o => open,
            dout_o  	   => dout_o,
	    dout_valid_o   => dout_valid_o
        );

end rtl;
