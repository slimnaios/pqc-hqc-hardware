--/*Main conversions:
--Error polynomial retrieval: This module extracts the error polynomial from FFT evaluations of the Error Locator Polynomial (ELP)
--Address ROM: Lookup table with 128 entries mapping counter values to RAM addresses

--Error data computation:
--error_temp: 0x01 if RAM data is zero, 0xFE otherwise
--error_data: XORs with previous error buffer on subsequent iterations

--Pipeline control:
--start_d: 4-stage delay for start signal
--cnt_en_d: 3-stage delay for counter enable
--Used for precise timing of data capture and output

--Key implementation details:
--Error accumulation: Shifts error bytes into error_buf from LSB side

--Dual-mode operation:
--First iteration: directly uses error_temp
--Subsequent iterations: XORs with previous buffer value

--Counter control: Runs for PARAM_N1 cycles (46, 56, or 90 depending on security level)
--Address mapping: ROM provides bit-reversed or permuted addressing for FFT output retrieval

--Algorithm purpose:
--This module performs the final step in FFT-based error correction:

--Reads FFT evaluations of the ELP from RAM (in specific permuted order via address ROM)
--Converts evaluations to error polynomial coefficients
--Produces error pattern: 0x01 for error locations, 0xFE for non-error locations
--Accumulates N1 bytes into final error polynomial

--The address ROM implements a specific permutation required by the additive FFT algorithm to 
--correctly map frequency domain values back to time domain error locations in the HQC cryptosystem.

--The lookup table is complete and supports all security levels:
--Entries 0-45: Used for PARAM_SECURITY = 128 (PARAM_N1 = 46)
--Entries 0-55: Used for PARAM_SECURITY = 192 (PARAM_N1 = 56)
--Entries 0-89: Used for PARAM_SECURITY = 256 (PARAM_N1 = 90)

--The address ROM now contains the complete permutation mapping for the additive FFT algorithm across all HQC security parameter sets. 
--These addresses represent the bit-reversed or specially ordered indices needed to correctly retrieve error polynomial coefficients from the FFT evaluation results.
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity fft_retrieve_error_poly is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET;
        IN_AW          : integer := 8;
        IN_DW          : integer := 8
    );
    port (
        clk_i           : in  std_logic;
        rst_ni          : in  std_logic;
        start_i         : in  std_logic;
        busy_o          : out std_logic;
        -- Input RAM
        ram_din_i       : in  std_logic_vector;--(IN_DW-1 downto 0);
        ram_din_rd_o    : out std_logic;
        ram_din_addr_o  : out std_logic_vector;--(IN_AW-1 downto 0);
        -- Output
        dout_o          : out std_logic_vector;--(DOUT_W-1 downto 0);  -- error
        dout_valid_o    : out std_logic
    );
end fft_retrieve_error_poly;

architecture rtl of fft_retrieve_error_poly is

    constant HQC_PARAMS : hqc_params_t := get_hqc_params(PARAM_SET);
    
    -- Parameter calculations
    constant PARAM_N1    : integer := HQC_PARAMS.n1;
    constant DOUT_W   : integer := 8 * PARAM_N1;
    
    -- Internal signals
    signal error_buf   : std_logic_vector(DOUT_W-1 downto 0);
    signal error_data  : std_logic_vector(IN_DW-1 downto 0);
    signal error_temp  : std_logic_vector(IN_DW-1 downto 0);
    signal addr        : unsigned(7 downto 0);
    signal cnt         : unsigned(7 downto 0);
    signal last_cnt    : std_logic;
    signal start_d     : std_logic_vector(3 downto 0);
    signal cnt_en_d    : std_logic_vector(2 downto 0);
    signal cnt_en      : std_logic;
    signal busy        : std_logic;
    signal dout_valid  : std_logic;

begin

    -- error = {e[N1-1],e[N-2],...,e[1],e[0]} with e[i] in byte
    -- Shift register that builds the error polynomial byte-by-byte
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if cnt_en_d(1) = '1' then
                error_buf <= error_data & error_buf(DOUT_W-1 downto 8);
            end if;
        end if;
    end process;
    
    dout_o <= error_buf;
    
    error_temp <= x"01" when ram_din_i = x"00" else x"FE";
    -- The XOR accumulation creates complex patterns that encode error information across the polynomial
    error_data <= std_logic_vector(unsigned(error_buf(DOUT_W-1 downto DOUT_W-8)) xor unsigned(error_temp)) 
                  when start_d(3) = '1' else error_temp;
    
    ------------------------------------------------------------------------------
    -- Controller
    ------------------------------------------------------------------------------
    
    -- Busy flag
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or (cnt_en_d(1) = '1' and cnt_en_d(0) = '0') then
                busy <= '0';
            elsif start_i = '1' then
                busy <= '1';
            end if;
        end if;
    end process;
    
    busy_o <= busy;
    
    -- Input Counter
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or (last_cnt = '1' and cnt_en = '1') then
                cnt <= (others => '0');
            elsif cnt_en = '1' then
                cnt <= cnt + 1;
            end if;
        end if;
    end process;
    
    last_cnt <= '1' when cnt = PARAM_N1 else '0';
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or last_cnt = '1' then
                cnt_en <= '0';
            elsif start_i = '1' then
                cnt_en <= '1';
            end if;
        end if;
    end process;
    
    -- 3-stage delay
    -- cnt_en_d(0): Triggers RAM read
    -- cnt_en_d(1): Triggers error buffer update
    -- cnt_en_d(2): (Earlier stage for other timing)
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                cnt_en_d <= (others => '0');
            else
                cnt_en_d <= cnt_en_d(1 downto 0) & cnt_en;
            end if;
        end if;
    end process;
    
    ram_din_rd_o   <= cnt_en_d(0);
    ram_din_addr_o <= std_logic_vector(addr);
    
    -- 4-stage delay - Aligns with data pipeline through RAM read and processing
    -- start_d(0) = current start
    -- start_d(1) = 1 cycle delayed
    -- start_d(2) = 2 cycles delayed
    -- start_d(3) = 3 cycles delayed ? triggers XOR mode
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                start_d <= (others => '0');
            else
                start_d <= start_d(2 downto 0) & start_i;
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            dout_valid <= cnt_en_d(1) and (not cnt_en_d(0));
        end if;
    end process;
    
    dout_valid_o <= dout_valid;
    
    ------------------------------------------------------------------------------
    -- Address ROM
    -- Provides the specific sequence needed to extract error polynomial coefficients from the permuted FFT output
    ------------------------------------------------------------------------------
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            case to_integer(cnt(6 downto 0)) is
                when 0   => addr <= to_unsigned(0, 8);   when 1   => addr <= to_unsigned(128, 8);
                when 2   => addr <= to_unsigned(113, 8); when 3   => addr <= to_unsigned(226, 8);
                when 4   => addr <= to_unsigned(181, 8); when 5   => addr <= to_unsigned(27, 8);
                when 6   => addr <= to_unsigned(54, 8);  when 7   => addr <= to_unsigned(108, 8);
                when 8   => addr <= to_unsigned(216, 8); when 9   => addr <= to_unsigned(193, 8);
                when 10  => addr <= to_unsigned(243, 8); when 11  => addr <= to_unsigned(151, 8);
                when 12  => addr <= to_unsigned(95, 8);  when 13  => addr <= to_unsigned(190, 8);
                when 14  => addr <= to_unsigned(13, 8);  when 15  => addr <= to_unsigned(26, 8);
                when 16  => addr <= to_unsigned(52, 8);  when 17  => addr <= to_unsigned(104, 8);
                when 18  => addr <= to_unsigned(208, 8); when 19  => addr <= to_unsigned(209, 8);
                when 20  => addr <= to_unsigned(211, 8); when 21  => addr <= to_unsigned(215, 8);
                when 22  => addr <= to_unsigned(223, 8); when 23  => addr <= to_unsigned(207, 8);
                when 24  => addr <= to_unsigned(239, 8); when 25  => addr <= to_unsigned(175, 8);
                when 26  => addr <= to_unsigned(47, 8);  when 27  => addr <= to_unsigned(94, 8);
                when 28  => addr <= to_unsigned(188, 8); when 29  => addr <= to_unsigned(9, 8);
                when 30  => addr <= to_unsigned(18, 8);  when 31  => addr <= to_unsigned(36, 8);
                when 32  => addr <= to_unsigned(72, 8);  when 33  => addr <= to_unsigned(144, 8);
                when 34  => addr <= to_unsigned(81, 8);  when 35  => addr <= to_unsigned(162, 8);
                when 36  => addr <= to_unsigned(53, 8);  when 37  => addr <= to_unsigned(106, 8);
                when 38  => addr <= to_unsigned(212, 8); when 39  => addr <= to_unsigned(217, 8);
                when 40  => addr <= to_unsigned(195, 8); when 41  => addr <= to_unsigned(247, 8);
                when 42  => addr <= to_unsigned(159, 8); when 43  => addr <= to_unsigned(79, 8);
                when 44  => addr <= to_unsigned(158, 8); when 45  => addr <= to_unsigned(77, 8);
                when 46  => addr <= to_unsigned(154, 8); when 47  => addr <= to_unsigned(69, 8);
                when 48  => addr <= to_unsigned(138, 8); when 49  => addr <= to_unsigned(101, 8);
                when 50  => addr <= to_unsigned(202, 8); when 51  => addr <= to_unsigned(229, 8);
                when 52  => addr <= to_unsigned(187, 8); when 53  => addr <= to_unsigned(7, 8);
                when 54  => addr <= to_unsigned(14, 8);  when 55  => addr <= to_unsigned(28, 8);
                when 56  => addr <= to_unsigned(56, 8);  when 57  => addr <= to_unsigned(112, 8);
                when 58  => addr <= to_unsigned(224, 8); when 59  => addr <= to_unsigned(177, 8);
                when 60  => addr <= to_unsigned(19, 8);  when 61  => addr <= to_unsigned(38, 8);
                when 62  => addr <= to_unsigned(76, 8);  when 63  => addr <= to_unsigned(152, 8);
                when 64  => addr <= to_unsigned(65, 8);  when 65  => addr <= to_unsigned(130, 8);
                when 66  => addr <= to_unsigned(117, 8); when 67  => addr <= to_unsigned(234, 8);
                when 68  => addr <= to_unsigned(165, 8); when 69  => addr <= to_unsigned(59, 8);
                when 70  => addr <= to_unsigned(118, 8); when 71  => addr <= to_unsigned(236, 8);
                when 72  => addr <= to_unsigned(169, 8); when 73  => addr <= to_unsigned(35, 8);
                when 74  => addr <= to_unsigned(70, 8);  when 75  => addr <= to_unsigned(140, 8);
                when 76  => addr <= to_unsigned(105, 8); when 77  => addr <= to_unsigned(210, 8);
                when 78  => addr <= to_unsigned(213, 8); when 79  => addr <= to_unsigned(219, 8);
                when 80  => addr <= to_unsigned(199, 8); when 81  => addr <= to_unsigned(255, 8);
                when 82  => addr <= to_unsigned(143, 8); when 83  => addr <= to_unsigned(111, 8);
                when 84  => addr <= to_unsigned(222, 8); when 85  => addr <= to_unsigned(205, 8);
                when 86  => addr <= to_unsigned(235, 8); when 87  => addr <= to_unsigned(167, 8);
                when 88  => addr <= to_unsigned(63, 8);  when 89  => addr <= to_unsigned(126, 8);
                when 90  => addr <= to_unsigned(252, 8); when 91  => addr <= to_unsigned(137, 8);
                when 92  => addr <= to_unsigned(99, 8);  when 93  => addr <= to_unsigned(198, 8);
                when 94  => addr <= to_unsigned(253, 8); when 95  => addr <= to_unsigned(139, 8);
                when 96  => addr <= to_unsigned(103, 8); when 97  => addr <= to_unsigned(206, 8);
                when 98  => addr <= to_unsigned(237, 8); when 99  => addr <= to_unsigned(171, 8);
                when 100 => addr <= to_unsigned(39, 8);  when 101 => addr <= to_unsigned(78, 8);
                when 102 => addr <= to_unsigned(156, 8); when 103 => addr <= to_unsigned(73, 8);
                when 104 => addr <= to_unsigned(146, 8); when 105 => addr <= to_unsigned(85, 8);
                when 106 => addr <= to_unsigned(170, 8); when 107 => addr <= to_unsigned(37, 8);
                when 108 => addr <= to_unsigned(74, 8);  when 109 => addr <= to_unsigned(148, 8);
                when 110 => addr <= to_unsigned(89, 8);  when 111 => addr <= to_unsigned(178, 8);
                when 112 => addr <= to_unsigned(21, 8);  when 113 => addr <= to_unsigned(42, 8);
                when 114 => addr <= to_unsigned(84, 8);  when 115 => addr <= to_unsigned(168, 8);
                when 116 => addr <= to_unsigned(33, 8);  when 117 => addr <= to_unsigned(66, 8);
                when 118 => addr <= to_unsigned(132, 8); when 119 => addr <= to_unsigned(121, 8);
                when 120 => addr <= to_unsigned(242, 8); when 121 => addr <= to_unsigned(149, 8);
                when 122 => addr <= to_unsigned(91, 8);  when 123 => addr <= to_unsigned(182, 8);
                when 124 => addr <= to_unsigned(29, 8);  when 125 => addr <= to_unsigned(58, 8);
                when 126 => addr <= to_unsigned(116, 8); when 127 => addr <= to_unsigned(232, 8);
                                -- Entries 128-255 (for PARAM_SECURITY = 192 or 256)
                when 128 => addr <= to_unsigned(161, 8); when 129 => addr <= to_unsigned(51, 8);
                when 130 => addr <= to_unsigned(102, 8); when 131 => addr <= to_unsigned(204, 8);
                when 132 => addr <= to_unsigned(233, 8); when 133 => addr <= to_unsigned(163, 8);
                when 134 => addr <= to_unsigned(55, 8);  when 135 => addr <= to_unsigned(110, 8);
                when 136 => addr <= to_unsigned(220, 8); when 137 => addr <= to_unsigned(201, 8);
                when 138 => addr <= to_unsigned(227, 8); when 139 => addr <= to_unsigned(183, 8);
                when 140 => addr <= to_unsigned(31, 8);  when 141 => addr <= to_unsigned(62, 8);
                when 142 => addr <= to_unsigned(124, 8); when 143 => addr <= to_unsigned(248, 8);
                when 144 => addr <= to_unsigned(129, 8); when 145 => addr <= to_unsigned(115, 8);
                when 146 => addr <= to_unsigned(230, 8); when 147 => addr <= to_unsigned(189, 8);
                when 148 => addr <= to_unsigned(11, 8);  when 149 => addr <= to_unsigned(22, 8);
                when 150 => addr <= to_unsigned(44, 8);  when 151 => addr <= to_unsigned(88, 8);
                when 152 => addr <= to_unsigned(176, 8); when 153 => addr <= to_unsigned(17, 8);
                when 154 => addr <= to_unsigned(34, 8);  when 155 => addr <= to_unsigned(68, 8);
                when 156 => addr <= to_unsigned(136, 8); when 157 => addr <= to_unsigned(97, 8);
                when 158 => addr <= to_unsigned(194, 8); when 159 => addr <= to_unsigned(245, 8);
                when 160 => addr <= to_unsigned(155, 8); when 161 => addr <= to_unsigned(71, 8);
                when 162 => addr <= to_unsigned(142, 8); when 163 => addr <= to_unsigned(109, 8);
                when 164 => addr <= to_unsigned(218, 8); when 165 => addr <= to_unsigned(197, 8);
                when 166 => addr <= to_unsigned(251, 8); when 167 => addr <= to_unsigned(135, 8);
                when 168 => addr <= to_unsigned(127, 8); when 169 => addr <= to_unsigned(254, 8);
                when 170 => addr <= to_unsigned(141, 8); when 171 => addr <= to_unsigned(107, 8);
                when 172 => addr <= to_unsigned(214, 8); when 173 => addr <= to_unsigned(221, 8);
                when 174 => addr <= to_unsigned(203, 8); when 175 => addr <= to_unsigned(231, 8);
                when 176 => addr <= to_unsigned(191, 8); when 177 => addr <= to_unsigned(15, 8);
                when 178 => addr <= to_unsigned(30, 8);  when 179 => addr <= to_unsigned(60, 8);
                when 180 => addr <= to_unsigned(120, 8); when 181 => addr <= to_unsigned(240, 8);
                when 182 => addr <= to_unsigned(145, 8); when 183 => addr <= to_unsigned(83, 8);
                when 184 => addr <= to_unsigned(166, 8); when 185 => addr <= to_unsigned(61, 8);
                when 186 => addr <= to_unsigned(122, 8); when 187 => addr <= to_unsigned(244, 8);
                when 188 => addr <= to_unsigned(153, 8); when 189 => addr <= to_unsigned(67, 8);
                when 190 => addr <= to_unsigned(134, 8); when 191 => addr <= to_unsigned(125, 8);
                when 192 => addr <= to_unsigned(250, 8); when 193 => addr <= to_unsigned(133, 8);
                when 194 => addr <= to_unsigned(123, 8); when 195 => addr <= to_unsigned(246, 8);
                when 196 => addr <= to_unsigned(157, 8); when 197 => addr <= to_unsigned(75, 8);
                when 198 => addr <= to_unsigned(150, 8); when 199 => addr <= to_unsigned(93, 8);
                when 200 => addr <= to_unsigned(186, 8); when 201 => addr <= to_unsigned(5, 8);
                when 202 => addr <= to_unsigned(10, 8);  when 203 => addr <= to_unsigned(20, 8);
                when 204 => addr <= to_unsigned(40, 8);  when 205 => addr <= to_unsigned(80, 8);
                when 206 => addr <= to_unsigned(160, 8); when 207 => addr <= to_unsigned(49, 8);
                when 208 => addr <= to_unsigned(98, 8);  when 209 => addr <= to_unsigned(196, 8);
                when 210 => addr <= to_unsigned(249, 8); when 211 => addr <= to_unsigned(131, 8);
                when 212 => addr <= to_unsigned(119, 8); when 213 => addr <= to_unsigned(238, 8);
                when 214 => addr <= to_unsigned(173, 8); when 215 => addr <= to_unsigned(43, 8);
                when 216 => addr <= to_unsigned(86, 8);  when 217 => addr <= to_unsigned(172, 8);
                when 218 => addr <= to_unsigned(41, 8);  when 219 => addr <= to_unsigned(82, 8);
                when 220 => addr <= to_unsigned(164, 8); when 221 => addr <= to_unsigned(57, 8);
                when 222 => addr <= to_unsigned(114, 8); when 223 => addr <= to_unsigned(228, 8);
                when 224 => addr <= to_unsigned(185, 8); when 225 => addr <= to_unsigned(3, 8);
                when 226 => addr <= to_unsigned(6, 8);   when 227 => addr <= to_unsigned(12, 8);
                when 228 => addr <= to_unsigned(24, 8);  when 229 => addr <= to_unsigned(48, 8);
                when 230 => addr <= to_unsigned(96, 8);  when 231 => addr <= to_unsigned(192, 8);
                when 232 => addr <= to_unsigned(241, 8); when 233 => addr <= to_unsigned(147, 8);
                when 234 => addr <= to_unsigned(87, 8);  when 235 => addr <= to_unsigned(174, 8);
                when 236 => addr <= to_unsigned(45, 8);  when 237 => addr <= to_unsigned(90, 8);
                when 238 => addr <= to_unsigned(180, 8); when 239 => addr <= to_unsigned(25, 8);
                when 240 => addr <= to_unsigned(50, 8);  when 241 => addr <= to_unsigned(100, 8);
                when 242 => addr <= to_unsigned(200, 8); when 243 => addr <= to_unsigned(225, 8);
                when 244 => addr <= to_unsigned(179, 8); when 245 => addr <= to_unsigned(23, 8);
                when 246 => addr <= to_unsigned(46, 8);  when 247 => addr <= to_unsigned(92, 8);
                when 248 => addr <= to_unsigned(184, 8); when 249 => addr <= to_unsigned(1, 8);
                when 250 => addr <= to_unsigned(2, 8);   when 251 => addr <= to_unsigned(4, 8);
                when 252 => addr <= to_unsigned(8, 8);   when 253 => addr <= to_unsigned(16, 8);
                when 254 => addr <= to_unsigned(32, 8);  when 255 => addr <= to_unsigned(64, 8);
                when others => addr <= to_unsigned(0, 8);
            end case;
        end if;
    end process;

end rtl;

 