--/*
--High-Level Purpose
--This module completes the FFT computation started by FFT Part 1. It processes 256 input bytes through 4 sequential rounds of butterfly operations to produce the final 256 FFT output values.
--Input: 256 bytes (one at a time, streamed)
--Output: 256 FFT evaluation results (one at a time, streamed)
--Structure: 4 cascaded rounds, each performing one layer of the FFT

--## Complete Processing Timeline (Round 0 Example)
--```
--Cycle 0: start_i='1'
--  ??> busy='1', cnt_in=0, dout_en='0'

--Cycles 0-15: First Half
--  ??> cnt_in[4]=0 (first half indicator)
--  ??> din arrives, stored to FIFO
--  ??> FIFO: [din_0, din_1, ..., din_15]
--  ??> No outputs yet

--Cycle 16: Transition
--  ??> cnt_in=16, cnt_in[4]=1 (second half)
--  ??> cnt_out_start='1' ? dout_en='1'
--  ??> Start producing outputs

--Cycles 16-31: Second Half + Output
--  ??> Read FIFO[i-16], butterfly with din[i]
--  ??> bi = (?[i] � din[i]) ? FIFO[i-16]
--  ??> Output bi
--  ??> Store bi_N2 to FIFO

--Cycles 32-47: Next butterfly block
--  ??> cnt_in[4]=0 again (new first half)
--  ??> Pattern repeats...

--...continues through all 256 inputs...

--Cycle 255: Last input
--  ??> last_din='1', busy='0'

--Cycles continue for output...

--Output completes:
--  ??> cnt_out=255, last_dout='1'
--  ??> done_o='1' (2 cycles later)
--```

--## The Complete 4-Round Pipeline
--```
--Input (256 bytes)
--    ?
--????????????????
--?   Round 0    ?  16-sample butterflies, 16-deep FIFO
--?  (16 blocks) ?  ? from 16-entry ROM
--????????????????
--       ? start signal + data
--????????????????
--?   Round 1    ?  32-sample butterflies, 32-deep FIFO
--?  (8 blocks)  ?  ? from 32-entry ROM
--????????????????
--       ?
--????????????????
--?   Round 2    ?  64-sample butterflies, 64-deep FIFO
--?  (4 blocks)  ?  ? from 64-entry ROM
--????????????????
--       ?
--????????????????
--?   Round 3    ?  128-sample butterflies, 128-deep FIFO
--?  (2 blocks)  ?  ? from 128-entry ROM
--????????????????
--       ?
--Output (256 FFT evaluations)

--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

-- Top-level FFT Part 2
entity fft_part2 is
    generic (
        DIN_W  : integer := 8;
        DOUT_W : integer := 8
    );
    port (
        clk_i        : in  std_logic;
        rst_ni       : in  std_logic;
        start_i      : in  std_logic;
        start_o      : out std_logic;
        busy_o       : out std_logic;
        done_o       : out std_logic;
        -- Input/output data
        din_i        : in  std_logic_vector(DIN_W-1 downto 0);
        din_valid_i  : in  std_logic;
        dout_o       : out std_logic_vector(DOUT_W-1 downto 0);
        dout_valid_o : out std_logic
    );
end fft_part2;

architecture rtl of fft_part2 is

    -- Internal signal arrays
    type start_array is array (0 to 4) of std_logic;
    type busy_array is array (0 to 3) of std_logic;
    type done_array is array (0 to 3) of std_logic;
    type data_array is array (0 to 4) of std_logic_vector(DOUT_W-1 downto 0);
    type data_vld_array is array (0 to 4) of std_logic;
    
    signal start    : start_array;
    signal busy     : busy_array;
    signal done     : done_array;
    signal data     : data_array;
    signal data_vld : data_vld_array;
    
    -- Component declaration
    component fft_part2_round is
        generic (
            ROUND  : integer := 0;
            DIN_W  : integer := 8;
            DOUT_W : integer := 8
        );
        port (
            clk_i        : in  std_logic;
            rst_ni       : in  std_logic;
            start_i      : in  std_logic;
            start_o      : out std_logic;
            busy_o       : out std_logic;
            done_o       : out std_logic;
            din_i        : in  std_logic_vector(DIN_W-1 downto 0);
            din_valid_i  : in  std_logic;
            dout_o       : out std_logic_vector(DOUT_W-1 downto 0);
            dout_valid_o : out std_logic
        );
    end component;

begin

    start(0)    <= start_i;
    data(0)     <= din_i;
    data_vld(0) <= din_valid_i;
    
    start_o      <= start(4);
    busy_o       <= busy(3);
    done_o       <= done(3);
    dout_o       <= data(4);
    dout_valid_o <= data_vld(4);
    
    -- Layer connections
    -- Creates a pipeline of 4 rounds
    -- Each round:
    --   - Receives data from previous round (or external input for Round 0)
    --   - Processes all 256 values
    --   - Passes results to next round
    --   - Generates `start` signal for next round when ready
    gen_rounds: for ii in 0 to 3 generate
        FFT_ROUND : fft_part2_round
            generic map (
                ROUND  => ii,
                DIN_W  => DIN_W,
                DOUT_W => DOUT_W
            )
            port map (
                clk_i        => clk_i,
                rst_ni       => rst_ni,
                start_i      => start(ii),
                start_o      => start(ii+1),
                busy_o       => busy(ii),
                done_o       => done(ii),
                din_i        => data(ii),
                din_valid_i  => data_vld(ii),
                dout_o       => data(ii+1),
                dout_valid_o => data_vld(ii+1)
            );
    end generate;

end rtl;

-------------------------------------------------------------------------------
-- FFT Layer/Round
-------------------------------------------------------------------------------
--/*
--Each round implements one **decimation-in-frequency (DIF) FFT butterfly layer**.

--## Core Algorithm: FFT Butterfly with FIFO

--Each round performs this fundamental operation:
--For each pair of values separated by N/2:
--    out_even = input_first ? (? � input_second)
--    out_odd  = input_first ? (? � input_second) ? input_second
    
--Where:
--N/2 varies by round (16, 32, 64, 128)
--? = twiddle factor from ROM
--? = XOR (GF addition)
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity fft_part2_round is
    generic (
        ROUND  : integer := 0;
        DIN_W  : integer := 8;
        DOUT_W : integer := 8
    );
    port (
        clk_i        : in  std_logic;
        rst_ni       : in  std_logic;
        start_i      : in  std_logic;
        start_o      : out std_logic;
        busy_o       : out std_logic;
        done_o       : out std_logic;
        -- Input/output data
        din_i        : in  std_logic_vector(DIN_W-1 downto 0);
        din_valid_i  : in  std_logic;
        dout_o       : out std_logic_vector(DOUT_W-1 downto 0);
        dout_valid_o : out std_logic
    );
end fft_part2_round;

architecture rtl of fft_part2_round is

    -- Internal signals
    signal din_d          : std_logic_vector(7 downto 0);
    signal bi             : std_logic_vector(7 downto 0);
    signal bi_N2          : std_logic_vector(7 downto 0);
    signal bi_out         : std_logic_vector(7 downto 0);
    signal dout           : std_logic_vector(7 downto 0);
    
    signal fifo_din       : std_logic_vector(7 downto 0);
    signal fifo_dout      : std_logic_vector(7 downto 0);
    signal fifo_wr        : std_logic;
    signal fifo_rd        : std_logic;
    signal fifo_empty     : std_logic;
    signal fifo_full      : std_logic;
    
    signal g              : std_logic_vector(7 downto 0);
    signal gf_out         : std_logic_vector(7 downto 0);
    
    signal start_d        : std_logic;
    signal din_valid_d    : std_logic;
    signal busy           : std_logic;
    signal cnt_in         : unsigned(7 downto 0);
    signal cnt_in_d       : unsigned(7 downto 0);
    signal cnt_out        : unsigned(7 downto 0);
    signal last_din       : std_logic;
    signal last_dout      : std_logic;
    signal cnt_out_start  : std_logic;
    signal last_dout_d1   : std_logic;
    signal last_dout_d2   : std_logic;
    signal dout_en        : std_logic;
    signal dout_en_d      : std_logic;
    signal cnt_out_start_d: std_logic;
    
    -- Component declarations

    component syncfifo is
        generic (
            DW : integer := 8;
            AW : integer := 4
        );
        port (
            clk_i   : in  std_logic;
            rst_ni  : in  std_logic;
            wr_i    : in  std_logic;
            rd_i    : in  std_logic;
            din_i   : in  std_logic_vector(DW-1 downto 0);
            empty_o : out std_logic;
            full_o  : out std_logic;
            dout_o  : out std_logic_vector(DW-1 downto 0)
        );
    end component;
    
    component gf_mul is
        generic (
            REG_IN  : integer := 0;
            REG_OUT : integer := 0
        );
        port (
            clk    : in  std_logic;
            start  : in  std_logic;
            in_1   : in  std_logic_vector(7 downto 0);
            in_2   : in  std_logic_vector(7 downto 0);
            output : out std_logic_vector(7 downto 0);
            done   : out std_logic
        );
    end component;

begin

    -- Input
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if din_valid_i = '1' then
                din_d <= din_i;
            end if;
        end if;
    end process;
    
    -- FIFO (feedback registers) - Delay line
    -- Stores the "first half" of each butterfly pair
    FIFO_FFT : syncfifo
        generic map (
            DW => 8,
            AW => 4 + ROUND
        )
        port map (
            clk_i   => clk_i,
            rst_ni  => rst_ni,
            wr_i    => fifo_wr,
            rd_i    => fifo_rd,
            din_i   => fifo_din,
            empty_o => fifo_empty,
            full_o  => fifo_full,
            dout_o  => fifo_dout
        );
 
-- /* 
--FIFO Read Conditions:
--During input processing: Read when cnt_in[4+ROUND]=1 (second half of butterfly)
--During output phase: Read to stream out results

--FIFO Write:
--First half: Write din_d (store for later pairing)
--Second half: Write bi_N2 (processed result)
--*/       
    fifo_wr  <= din_valid_d;
    fifo_rd <= '1' when (cnt_in(4 + ROUND) = '1') or (dout_en = '1' and cnt_out /= 255) else '0';
    fifo_din <= bi_N2 when cnt_in_d(4+ROUND) = '1' else din_d;


    -- GF Mult
    -- Multiplies input by twiddle factor in Galois Field GF(2^8)
    GF_MUL_INST : gf_mul
        generic map (
            REG_IN  => 0,
            REG_OUT => 0
        )
        port map (
            clk    => clk_i,
            start  => '1',
            in_1   => g,            -- Twiddle factor
            in_2   => din_d,        -- Input data
            output => gf_out,       -- ? � input
            done   => open
        );
    
    -- Butterfly
--/*
--**Two outputs from each input pair**:
--- `bi`: Combined value (first output)
--- `bi_N2`: Further combined (for storage)

--## Data Flow Through One Round

--### **Phase 1: First Half (cnt_in[4+ROUND] = 0)**
--```
--Cycles 0 to N/2-1:

--Input arrives ? Delayed ? Stored in FIFO
--                ?
--            (Waiting for pair)
--```

--**Example Round 0** (N/2 = 16):
--```
--cnt_in = 0-15:
--  - Store din_d in FIFO
--  - No output yet (building up data)
--```
--### **Phase 2: Second Half (cnt_in[4+ROUND] = 1)**
--```
--Cycles N/2 to N-1:

--New input arrives ? GF multiply by ? ? Combine with FIFO ? bi, bi_N2
--                                             ?
--                                      (Stored from first half)
                    
--bi_N2 ? Store back to FIFO
--bi    ? Output
--```
--*/
    bi_out <= bi when cnt_in_d(4+ROUND) = '1' else fifo_dout;       -- Output selection
    bi     <= gf_out xor fifo_dout;                                 -- ?�input ? stored_value
    bi_N2  <= bi xor din_d;                                         -- Further combination     
    
    -- Output
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if dout_en = '1' then
                dout <= bi_out;
            end if;
        end if;
    end process;
    
    dout_o <= dout;
    
    ------------------------------------------------------------------------------
    -- Controller
    ------------------------------------------------------------------------------
    
    -- Input
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            start_d     <= start_i;
            din_valid_d <= din_valid_i;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                busy <= '0';
            elsif start_i = '1' then
                busy <= '1';
            elsif cnt_in = 254 then
                busy <= '0';
            end if;
        end if;
    end process;
    
    busy_o <= busy;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or last_din = '1' then
                cnt_in <= (others => '0');
            elsif din_valid_i = '1' then
                cnt_in <= cnt_in + 1;
            end if;
        end if;
    end process;
    
    last_din <= '1' when cnt_in = 255 else '0';
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            cnt_in_d <= cnt_in;
        end if;
    end process;
    
    -- Output
    cnt_out_start <= '1' when cnt_in = (16 * (2**ROUND)) else '0';
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or cnt_out_start = '1' or last_dout = '1' then
                cnt_out <= (others => '0');
            elsif dout_en = '1' then
                cnt_out <= cnt_out + 1;
            end if;
        end if;
    end process;
    
    last_dout <= '1' when cnt_out = 255 else '0';
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                dout_en <= '0';
            elsif cnt_out_start = '1' then
                dout_en <= '1';
            elsif last_dout = '1' then
                dout_en <= '0';
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            dout_en_d       <= dout_en;
            cnt_out_start_d <= cnt_out_start;
            last_dout_d1    <= last_dout;
            last_dout_d2    <= last_dout_d1;
        end if;
    end process;
    
    start_o      <= cnt_out_start_d;             -- Signal next round to start
    done_o       <= last_dout_d2;
    dout_valid_o <= dout_en_d;
    
    ------------------------------------------------------------------------------
    -- Gamma sums ROM (Twiddle Factors)
    -- Twiddle factors are precomputed constants specific to each FFT stage. They're indexed by the lower bits of the input counter.
    ------------------------------------------------------------------------------
--/*    
--## Gamma ROM Pattern

--The twiddle factors follow FFT mathematical requirements:

--**Round 0** (16 values): Basic pattern for 16-point sub-FFTs  
--**Round 1** (32 values): Extended pattern for 32-point sub-FFTs  
--**Round 2** (64 values): Further extended  
--**Round 3** (128 values): Full pattern for final 128-point combination

--**Example Round 3 Pattern**:
--```
--0x00, 0x80, 0x40, 0xc0, 0x20, 0xa0, ...
--```
--These are specific GF(2^8) elements that create the required phase rotations for FFT.
--*/

    gen_round0: if ROUND = 0 generate
        process(clk_i)
        begin
            if rising_edge(clk_i) then
                case to_integer(cnt_in(3 downto 0)) is
                    when 0  => g <= x"00"; when 1  => g <= x"2d"; when 2  => g <= x"21"; when 3  => g <= x"0c";
                    when 4  => g <= x"ae"; when 5  => g <= x"83"; when 6  => g <= x"8f"; when 7  => g <= x"a2";
                    when 8  => g <= x"0b"; when 9  => g <= x"26"; when 10 => g <= x"2a"; when 11 => g <= x"07";
                    when 12 => g <= x"a5"; when 13 => g <= x"88"; when 14 => g <= x"84"; when 15 => g <= x"a9";
                    when others => g <= x"00";
                end case;
            end if;
        end process;
    end generate;
    
    gen_round1: if ROUND = 1 generate
        process(clk_i)
        begin
            if rising_edge(clk_i) then
                case to_integer(cnt_in(4 downto 0)) is
                    when 0  => g <= x"00"; when 1  => g <= x"0c"; when 2  => g <= x"b7"; when 3  => g <= x"bb";
                    when 4  => g <= x"26"; when 5  => g <= x"2a"; when 6  => g <= x"91"; when 7  => g <= x"9d";
                    when 8  => g <= x"61"; when 9  => g <= x"6d"; when 10 => g <= x"d6"; when 11 => g <= x"da";
                    when 12 => g <= x"47"; when 13 => g <= x"4b"; when 14 => g <= x"f0"; when 15 => g <= x"fc";
                    when 16 => g <= x"16"; when 17 => g <= x"1a"; when 18 => g <= x"a1"; when 19 => g <= x"ad";
                    when 20 => g <= x"30"; when 21 => g <= x"3c"; when 22 => g <= x"87"; when 23 => g <= x"8b";
                    when 24 => g <= x"77"; when 25 => g <= x"7b"; when 26 => g <= x"c0"; when 27 => g <= x"cc";
                    when 28 => g <= x"51"; when 29 => g <= x"5d"; when 30 => g <= x"e6"; when 31 => g <= x"ea";
                    when others => g <= x"00";
                end case;
            end if;
        end process;
    end generate;
    
    gen_round2: if ROUND = 2 generate
        process(clk_i)
        begin
            if rising_edge(clk_i) then
                case to_integer(cnt_in(5 downto 0)) is
                    when 0  => g <= x"00"; when 1  => g <= x"b6"; when 2  => g <= x"b3"; when 3  => g <= x"05";
                    when 4  => g <= x"ed"; when 5  => g <= x"5b"; when 6  => g <= x"5e"; when 7  => g <= x"e8";
                    when 8  => g <= x"78"; when 9  => g <= x"ce"; when 10 => g <= x"cb"; when 11 => g <= x"7d";
                    when 12 => g <= x"95"; when 13 => g <= x"23"; when 14 => g <= x"26"; when 15 => g <= x"90";
                    when 16 => g <= x"1c"; when 17 => g <= x"aa"; when 18 => g <= x"af"; when 19 => g <= x"19";
                    when 20 => g <= x"f1"; when 21 => g <= x"47"; when 22 => g <= x"42"; when 23 => g <= x"f4";
                    when 24 => g <= x"64"; when 25 => g <= x"d2"; when 26 => g <= x"d7"; when 27 => g <= x"61";
                    when 28 => g <= x"89"; when 29 => g <= x"3f"; when 30 => g <= x"3a"; when 31 => g <= x"8c";
                    when 32 => g <= x"06"; when 33 => g <= x"b0"; when 34 => g <= x"b5"; when 35 => g <= x"03";
                    when 36 => g <= x"eb"; when 37 => g <= x"5d"; when 38 => g <= x"58"; when 39 => g <= x"ee";
                    when 40 => g <= x"7e"; when 41 => g <= x"c8"; when 42 => g <= x"cd"; when 43 => g <= x"7b";
                    when 44 => g <= x"93"; when 45 => g <= x"25"; when 46 => g <= x"20"; when 47 => g <= x"96";
                    when 48 => g <= x"1a"; when 49 => g <= x"ac"; when 50 => g <= x"a9"; when 51 => g <= x"1f";
                    when 52 => g <= x"f7"; when 53 => g <= x"41"; when 54 => g <= x"44"; when 55 => g <= x"f2";
                    when 56 => g <= x"62"; when 57 => g <= x"d4"; when 58 => g <= x"d1"; when 59 => g <= x"67";
                    when 60 => g <= x"8f"; when 61 => g <= x"39"; when 62 => g <= x"3c"; when 63 => g <= x"8a";
                    when others => g <= x"00";
                end case;
            end if;
        end process;
    end generate;
    
    gen_round3: if ROUND = 3 generate
        process(clk_i)
        begin
            if rising_edge(clk_i) then
                case to_integer(cnt_in(6 downto 0)) is
                    when 0   => g <= x"00"; when 1   => g <= x"80"; when 2   => g <= x"40"; when 3   => g <= x"c0";
                    when 4   => g <= x"20"; when 5   => g <= x"a0"; when 6   => g <= x"60"; when 7   => g <= x"e0";
                    when 8   => g <= x"10"; when 9   => g <= x"90"; when 10  => g <= x"50"; when 11  => g <= x"d0";
                    when 12  => g <= x"30"; when 13  => g <= x"b0"; when 14  => g <= x"70"; when 15  => g <= x"f0";
                    when 16  => g <= x"08"; when 17  => g <= x"88"; when 18  => g <= x"48"; when 19  => g <= x"c8";
                    when 20  => g <= x"28"; when 21  => g <= x"a8"; when 22  => g <= x"68"; when 23  => g <= x"e8";
                    when 24  => g <= x"18"; when 25  => g <= x"98"; when 26  => g <= x"58"; when 27  => g <= x"d8";
                    when 28  => g <= x"38"; when 29  => g <= x"b8"; when 30  => g <= x"78"; when 31  => g <= x"f8";
                    when 32  => g <= x"04"; when 33  => g <= x"84"; when 34  => g <= x"44"; when 35  => g <= x"c4";
                    when 36  => g <= x"24"; when 37  => g <= x"a4"; when 38  => g <= x"64"; when 39  => g <= x"e4";
                    when 40  => g <= x"14"; when 41  => g <= x"94"; when 42  => g <= x"54"; when 43  => g <= x"d4";
                    when 44  => g <= x"34"; when 45  => g <= x"b4"; when 46  => g <= x"74"; when 47  => g <= x"f4";
                    when 48  => g <= x"0c"; when 49  => g <= x"8c"; when 50  => g <= x"4c"; when 51  => g <= x"cc";
                    when 52  => g <= x"2c"; when 53  => g <= x"ac"; when 54  => g <= x"6c"; when 55  => g <= x"ec";
                    when 56  => g <= x"1c"; when 57  => g <= x"9c"; when 58  => g <= x"5c"; when 59  => g <= x"dc";
                    when 60  => g <= x"3c"; when 61  => g <= x"bc"; when 62  => g <= x"7c"; when 63  => g <= x"fc";
                    when 64  => g <= x"02"; when 65  => g <= x"82"; when 66  => g <= x"42"; when 67  => g <= x"c2";
                    when 68  => g <= x"22"; when 69  => g <= x"a2"; when 70  => g <= x"62"; when 71  => g <= x"e2";
                    when 72  => g <= x"12"; when 73  => g <= x"92"; when 74  => g <= x"52"; when 75  => g <= x"d2";
                    when 76  => g <= x"32"; when 77  => g <= x"b2"; when 78  => g <= x"72"; when 79  => g <= x"f2";
                    when 80  => g <= x"0a"; when 81  => g <= x"8a"; when 82  => g <= x"4a"; when 83  => g <= x"ca";
                    when 84  => g <= x"2a"; when 85  => g <= x"aa"; when 86  => g <= x"6a"; when 87  => g <= x"ea";
                    when 88  => g <= x"1a"; when 89  => g <= x"9a"; when 90  => g <= x"5a"; when 91  => g <= x"da";
                    when 92  => g <= x"3a"; when 93  => g <= x"ba"; when 94  => g <= x"7a"; when 95  => g <= x"fa";
                    when 96  => g <= x"06"; when 97  => g <= x"86"; when 98  => g <= x"46"; when 99  => g <= x"c6";
                    when 100 => g <= x"26"; when 101 => g <= x"a6"; when 102 => g <= x"66"; when 103 => g <= x"e6";
                    when 104 => g <= x"16"; when 105 => g <= x"96"; when 106 => g <= x"56"; when 107 => g <= x"d6";
                    when 108 => g <= x"36"; when 109 => g <= x"b6"; when 110 => g <= x"76"; when 111 => g <= x"f6";
                    when 112 => g <= x"0e"; when 113 => g <= x"8e"; when 114 => g <= x"4e"; when 115 => g <= x"ce";
                    when 116 => g <= x"2e"; when 117 => g <= x"ae"; when 118 => g <= x"6e"; when 119 => g <= x"ee";
                    when 120 => g <= x"1e"; when 121 => g <= x"9e"; when 122 => g <= x"5e"; when 123 => g <= x"de";
                    when 124 => g <= x"3e"; when 125 => g <= x"be"; when 126 => g <= x"7e"; when 127 => g <= x"fe";
                    when others => g <= x"00";
                end case;
            end if;
        end process;
    end generate;

end rtl;