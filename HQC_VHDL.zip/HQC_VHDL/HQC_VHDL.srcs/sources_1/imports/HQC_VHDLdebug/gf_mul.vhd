--/*Main conversions:

--Functions: Converted both Verilog functions (mul and v_temp_rearrange) to VHDL functions with proper variable declarations and return statements
--Parameters to generics: REG_IN and REG_OUT are now integer generics
--Generate blocks: Converted conditional generate blocks to VHDL's if generate syntax with separate blocks for registered and non-registered paths
--Signal declarations: All wires became signals with proper std_logic_vector types
--Combinational logic: The series of assign statements for the 8-stage multiplication pipeline are now concurrent signal assignments
--Port name: Changed out to output since out is a reserved keyword in VHDL

--Key implementation details:

--The mul function XORs each bit of v_temp with the AND of corresponding bits from in_1 and in_2
--The v_temp_rearrange function implements the Galois Field polynomial (1 + x^2 + x^3 + x^4 + x^8)
--The 8-stage pipeline processes one bit position per stage
--Generate blocks handle optional input/output registers based on the generic parameters

--This implements a Galois Field (GF(2^8)) multiplier, commonly used in Reed-Solomon error correction codes.
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity gf_mul is
    generic (
        REG_IN  : integer := 1;
        REG_OUT : integer := 1
    );
    port (
        clk    : in  std_logic;
        start  : in  std_logic;
        in_1   : in  std_logic_vector(7 downto 0);
        in_2   : in  std_logic_vector(7 downto 0);
        output : out std_logic_vector(7 downto 0);
        done   : out std_logic
    );
end gf_mul;

architecture rtl of gf_mul is

-- Function: mul
function mul(
    v_temp : std_logic_vector(7 downto 0);
    in_1   : std_logic_vector(7 downto 0);
    in_2   : std_logic_vector(7 downto 0);
    i      : integer
) return std_logic_vector is
    variable result : std_logic_vector(7 downto 0);
begin
    for j in 0 to 7 loop
        result(j) := v_temp(j) xor (in_1(j) and in_2(8-i-1));
    end loop;
    return result;
end function;

-- Function: v_temp_rearrange (implements 1 + x^2 + x^3 + x^4 + x^8)
function v_temp_rearrange(
    v_temp : std_logic_vector(7 downto 0)
) return std_logic_vector is
    variable result : std_logic_vector(7 downto 0);
    variable dummy  : std_logic;
begin
    dummy := v_temp(7);
    result(7) := v_temp(6);
    result(6) := v_temp(5);
    result(5) := v_temp(4);
    result(4) := v_temp(3) xor dummy;
    result(3) := v_temp(2) xor dummy;
    result(2) := v_temp(1) xor dummy;
    result(1) := v_temp(0);
    result(0) := dummy;
    return result;
end function;

-- Internal signals
signal in_1_reg    : std_logic_vector(7 downto 0);
signal in_2_reg    : std_logic_vector(7 downto 0);
signal out_reg     : std_logic_vector(7 downto 0);
signal done_reg_1  : std_logic := '0';
signal done_reg_2  : std_logic := '0';

signal v_temp_0, v_temp_1, v_temp_2, v_temp_3 : std_logic_vector(7 downto 0);
signal v_temp_4, v_temp_5, v_temp_6, v_temp_7 : std_logic_vector(7 downto 0);
signal mul_0, mul_1, mul_2, mul_3 : std_logic_vector(7 downto 0);
signal mul_4, mul_5, mul_6, mul_7 : std_logic_vector(7 downto 0);
begin
 -- Input register generation
gen_reg_in: if REG_IN = 1 generate
    process(clk)
    begin
        if rising_edge(clk) then
            in_1_reg <= in_1;
            in_2_reg <= in_2;
            done_reg_1 <= start;
        end if;
    end process;
end generate;

gen_no_reg_in: if REG_IN /= 1 generate
    process(in_1, in_2, start) --could be process(all)
    begin
        in_1_reg <= in_1;
        in_2_reg <= in_2;
        done_reg_1 <= start;
    end process;
end generate;

-- Combinational logic for GF multiplication stages
v_temp_0 <= v_temp_rearrange((others => '0'));
mul_0 <= mul(v_temp_0, in_1_reg, in_2_reg, 0);

v_temp_1 <= v_temp_rearrange(mul_0);
mul_1 <= mul(v_temp_1, in_1_reg, in_2_reg, 1);

v_temp_2 <= v_temp_rearrange(mul_1);
mul_2 <= mul(v_temp_2, in_1_reg, in_2_reg, 2);

v_temp_3 <= v_temp_rearrange(mul_2);
mul_3 <= mul(v_temp_3, in_1_reg, in_2_reg, 3);

v_temp_4 <= v_temp_rearrange(mul_3);
mul_4 <= mul(v_temp_4, in_1_reg, in_2_reg, 4);

v_temp_5 <= v_temp_rearrange(mul_4);
mul_5 <= mul(v_temp_5, in_1_reg, in_2_reg, 5);

v_temp_6 <= v_temp_rearrange(mul_5);
mul_6 <= mul(v_temp_6, in_1_reg, in_2_reg, 6);

v_temp_7 <= v_temp_rearrange(mul_6);
mul_7 <= mul(v_temp_7, in_1_reg, in_2_reg, 7);

-- Output register generation
gen_reg_out: if REG_OUT = 1 generate
    process(clk)
    begin
        if rising_edge(clk) then
            out_reg <= mul_7;
            done_reg_2 <= done_reg_1;
        end if;
    end process;
end generate;

gen_no_reg_out: if REG_OUT /= 1 generate
    process(mul_7, done_reg_1) -- could be process(all)
    begin
        out_reg <= mul_7;
        done_reg_2 <= done_reg_1;
    end process;
end generate;

-- Output assignments
output <= out_reg;
done <= done_reg_2;
end rtl;