library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

use std.textio.all;
use ieee.std_logic_textio.all;

--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity mem_single is
    generic (
        WIDTH 	  : positive := 8;
        DEPTH 	  : positive := 64;
        INIT_FILE : string   := "";
        INIT  	  : boolean  := false
    );
    port (
        clk      : in  std_logic;
        data_in  : in  std_logic_vector(WIDTH-1 downto 0);
        address  : in  std_logic_vector(clog2(DEPTH)-1 downto 0);
        wr_en    : in  std_logic;
        data_out : out std_logic_vector(WIDTH-1 downto 0)
    );
end entity;

architecture behavioral of mem_single is

--------------------------------------------------------------------
-- Memory declaration
--------------------------------------------------------------------
type ram_type is array (0 to DEPTH-1) of std_logic_vector(WIDTH-1 downto 0);
signal RAM : ram_type := (others => (others => '0'));
-- Vendor RAM hints (Vivado / Quartus)
attribute ram_style : string;
attribute ram_style of RAM : signal is "block";

begin

--------------------------------------------------------------------
-- Initialization (simulation-oriented)
--------------------------------------------------------------------
    init_proc : process
        file f        : text;
        variable line : line;
        variable tmp  : std_logic_vector(WIDTH-1 downto 0);
        variable i    : integer := 0;
    begin
        if INIT_FILE /= "" then
            file_open(f, INIT_FILE, read_mode);
            while not endfile(f) and i < DEPTH loop
                readline(f, line);
                read(line, tmp);
                RAM(i) <= tmp;
                i := i + 1;
            end loop;
            file_close(f);
        elsif INIT then
            RAM <= (others => (others => '0'));
        end if;
        wait;
    end process;

--------------------------------------------------------------------
-- Single-port RAM behavior
--------------------------------------------------------------------
process (clk)
begin
  if rising_edge(clk) then
     if wr_en = '1' then
        RAM(to_integer(unsigned(address))) <= data_in;
        data_out <= data_in;
      else
        data_out <= RAM(to_integer(unsigned(address)));
      end if;
   end if;
end process;

end behavioral;



