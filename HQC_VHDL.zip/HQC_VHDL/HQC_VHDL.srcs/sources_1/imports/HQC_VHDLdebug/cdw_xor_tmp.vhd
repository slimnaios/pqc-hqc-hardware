--/*Main conversions:

--Parameters to constants: Used helper functions to calculate N1_BYTES and K_BYTES based on the generic parameter_set
--Generate statement: Converted the Verilog genvar and generate block to VHDL's for generate statement
--XOR operation: Changed ^ to xor keyword
--Port declarations: The port widths N1-K-1 are calculated from the constants defined in the architecture

--Key points:

--The generate loop runs from N1_BYTES-K_BYTES down to 2, matching the original Verilog logic (i>1)
--The lowest byte (bits 7 downto 0) is directly assigned from tmp_arr without XOR operation
--All other bytes perform XOR between shifted cdw_in and tmp_arr values
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity cdw_xor_tmp is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        cdw_in  : in  std_logic_vector;--(N1-K-1 downto 0);
        tmp_arr : in  std_logic_vector;--(N1-K-1 downto 0);
        cdw_out : out std_logic_vector--(N1-K-1 downto 0)
    );
end cdw_xor_tmp;

architecture rtl of cdw_xor_tmp is

constant HQC_PARAMS : hqc_params_t := get_hqc_params(PARAM_SET);

constant N1_BYTES     : natural := HQC_PARAMS.n1;
constant N1           : natural := 8*N1_BYTES;
--constant LOG_N1_BYTES : natural := clog2(N1_BYTES);
constant K_BYTES      : natural := HQC_PARAMS.k1;
constant K            : natural := 8*K_BYTES;

begin

    -- Generate XOR logic for bytes
    gen_xor: for i in N1_BYTES-K_BYTES downto 2 generate
        cdw_out(8*i-1 downto 8*i-8) <= cdw_in(8*(i-1)-1 downto 8*(i-1)-8) xor 
                                        tmp_arr(8*i-1 downto 8*i-8);
    end generate;
    
    -- Direct assignment for lowest byte
    cdw_out(7 downto 0) <= tmp_arr(7 downto 0);

end rtl;