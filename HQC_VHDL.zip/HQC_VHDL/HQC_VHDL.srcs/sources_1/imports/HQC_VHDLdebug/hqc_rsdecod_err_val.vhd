--/*Module Purpose - Forney Algorithm:
--This module implements the Forney algorithm to compute error values for Reed-Solomon decoding. 
--It takes error locations and the Z-polynomial to calculate the actual error magnitudes.

--e_i = Z(?_i?�) / ?'(?_i?�)
--Where:
--  Z(x) = error evaluator polynomial (input z_i)
--  ?'(x) = formal derivative of error locator polynomial
--  ?_i = error location in GF(2^8)
--  e_i = error magnitude (the actual error value)

--?'(x) = ?? + ??x� + ??x? + ... (only odd-degree terms in GF characteristic 2)

--Key Components:

--Four-state FSM:
--state_init: Initialize RAMs to zero
--state_beta: Compute beta_j values (error location powers)
--state_e: Compute e_j values (error magnitudes using Forney formula)
--state_err: Extract final error values for message positions

--Two RAM arrays:
--beta_j[0..DELTA-1]: Stores powers of error locations (?^(?_i))
--e_j[0..DELTA-1]: Stores computed error values

--Forney formula computation:
--For each error location ?_i, computes: e_i = Z(?^(-?_i)) / ?'(?^(-?_i))
--Z is the error evaluator polynomial
--?' is the formal derivative of the error locator polynomial

--Multiple nested loops:
--Outer loop (i_cnt): Processes all N1 codeword positions
--Inner loops (ii_cnt, jj_cnt): Compute error values using polynomial evaluation

--Key operations:
--GF inverse: Lookup table for multiplicative inverses in GF(2^8) - returns x?� for any x in GF(2^8)
--GF exp: Lookup table for field element powers - returns ?^x for x = 0 to 127
--Two GF multipliers: Parallel computation for efficiency
--Mask logic: Only processes positions where errors were detected

--This is the final step in Reed-Solomon decoding that produces the actual error correction values for the HQC post-quantum cryptosystem.

--## Complete Operation Flow Example

--Assume 2 errors detected at positions 5 and 12:

--### **State Init** (cycles 0-14):
--```
--Clear beta_j[0..14]
--Clear e_j[0..14]
--```

--### **State Beta** (cycles 15-60):
--```
--i=5:  beta_j[0] = ?^5,  delta_cnt=1
--i=12: beta_j[1] = ?^12, delta_cnt=2
--Result: beta_j = [?^5, ?^12, 0, ..., 0]
--```

--### **State E** (cycles 61-...):
--```
--For ii=0 (error at position 5):
--    ?_0 = ?^5
--    ?_0?� = (?^5)?�
    
--    Compute Z(?_0?�):
--        jj=0: tmp1 = z?
--        jj=1: tmp1 = z? ? (z? � ?_0?�)
--        ...
--        jj=DELTA: tmp1 = full Z(?_0?�)
    
--    Compute ?'(?_0?�):
--        Product over all other ?_k
--        tmp2 = ?(1 - ?_0?� � ?_k) for k?0
    
--    e_j[0] = tmp1 / tmp2

--For ii=1 (error at position 12):
--    Similar computation for ?_1 = ?^12
--    e_j[1] = error_value_1
--```

--### **State Err** (cycles ...):
--```
--i=0-4:  err_val += 0x00 (no errors)
--i=5:    err_val += e_j[0] (error value)
--i=6-11: err_val += 0x00
--i=12:   err_val += e_j[1] (error value)
--...

--Final: err_val = [0, 0, 0, 0, 0, e?, 0, 0, 0, 0, 0, 0, e?, ...]
--```
--*/  

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity hqc_rsdecod_err_val is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i        : in  std_logic;
        rst_ni       : in  std_logic;
        error_i      : in  std_logic_vector;--(ERR_W-1 downto 0);
        z_i          : in  std_logic_vector;--(Z_W-1 downto 0);
        start_i      : in  std_logic;
        busy_o       : out std_logic;
        error_o      : out std_logic_vector;--(MSG_W-1 downto 0);
        dout_valid_o : out std_logic
    );
end hqc_rsdecod_err_val;

architecture rtl of hqc_rsdecod_err_val is

    -- GF inverse lookup table (same as in ELP module)
    function gf_inverse(x : std_logic_vector(7 downto 0)) return std_logic_vector is
        variable result : std_logic_vector(7 downto 0);
        variable val : integer;
    begin
        val := to_integer(unsigned(x));
        case val is
            when 0   => result := x"00"; when 1   => result := x"01"; when 2   => result := x"8E"; when 3   => result := x"F4";
            when 4   => result := x"47"; when 5   => result := x"A7"; when 6   => result := x"7A"; when 7   => result := x"BA";
            when 8   => result := x"AD"; when 9   => result := x"9D"; when 10  => result := x"DD"; when 11  => result := x"98";
            when 12  => result := x"3D"; when 13  => result := x"AA"; when 14  => result := x"5D"; when 15  => result := x"96";
            when 16  => result := x"D8"; when 17  => result := x"72"; when 18  => result := x"C0"; when 19  => result := x"58";
            when 20  => result := x"E0"; when 21  => result := x"3E"; when 22  => result := x"4C"; when 23  => result := x"66";
            when 24  => result := x"90"; when 25  => result := x"DE"; when 26  => result := x"55"; when 27  => result := x"80";
            when 28  => result := x"A0"; when 29  => result := x"83"; when 30  => result := x"4B"; when 31  => result := x"2A";
            when 32  => result := x"6C"; when 33  => result := x"ED"; when 34  => result := x"39"; when 35  => result := x"51";
            when 36  => result := x"60"; when 37  => result := x"56"; when 38  => result := x"2C"; when 39  => result := x"8A";
            when 40  => result := x"70"; when 41  => result := x"D0"; when 42  => result := x"1F"; when 43  => result := x"4A";
            when 44  => result := x"26"; when 45  => result := x"8B"; when 46  => result := x"33"; when 47  => result := x"6E";
            when 48  => result := x"48"; when 49  => result := x"89"; when 50  => result := x"6F"; when 51  => result := x"2E";
            when 52  => result := x"A4"; when 53  => result := x"C3"; when 54  => result := x"40"; when 55  => result := x"5E";
            when 56  => result := x"50"; when 57  => result := x"22"; when 58  => result := x"CF"; when 59  => result := x"A9";
            when 60  => result := x"AB"; when 61  => result := x"0C"; when 62  => result := x"15"; when 63  => result := x"E1";
            when 64  => result := x"36"; when 65  => result := x"5F"; when 66  => result := x"F8"; when 67  => result := x"D5";
            when 68  => result := x"92"; when 69  => result := x"4E"; when 70  => result := x"A6"; when 71  => result := x"04";
            when 72  => result := x"30"; when 73  => result := x"88"; when 74  => result := x"2B"; when 75  => result := x"1E";
            when 76  => result := x"16"; when 77  => result := x"67"; when 78  => result := x"45"; when 79  => result := x"93";
            when 80  => result := x"38"; when 81  => result := x"23"; when 82  => result := x"68"; when 83  => result := x"8C";
            when 84  => result := x"81"; when 85  => result := x"1A"; when 86  => result := x"25"; when 87  => result := x"61";
            when 88  => result := x"13"; when 89  => result := x"C1"; when 90  => result := x"CB"; when 91  => result := x"63";
            when 92  => result := x"97"; when 93  => result := x"0E"; when 94  => result := x"37"; when 95  => result := x"41";
            when 96  => result := x"24"; when 97  => result := x"57"; when 98  => result := x"CA"; when 99  => result := x"5B";
            when 100 => result := x"B9"; when 101 => result := x"C4"; when 102 => result := x"17"; when 103 => result := x"4D";
            when 104 => result := x"52"; when 105 => result := x"8D"; when 106 => result := x"EF"; when 107 => result := x"B3";
            when 108 => result := x"20"; when 109 => result := x"EC"; when 110 => result := x"2F"; when 111 => result := x"32";
            when 112 => result := x"28"; when 113 => result := x"D1"; when 114 => result := x"11"; when 115 => result := x"D9";
            when 116 => result := x"E9"; when 117 => result := x"FB"; when 118 => result := x"DA"; when 119 => result := x"79";
            when 120 => result := x"DB"; when 121 => result := x"77"; when 122 => result := x"06"; when 123 => result := x"BB";
            when 124 => result := x"84"; when 125 => result := x"CD"; when 126 => result := x"FE"; when 127 => result := x"FC";
            when others => result := x"00";
        end case;
        return result;
    end function;
    
    -- GF exp array (first 128 entries - up to PARAM_N1 max = 90)
    function gf_exp(x : unsigned(6 downto 0)) return std_logic_vector is
        variable result : std_logic_vector(7 downto 0);
        variable val : integer;
    begin
        val := to_integer(x);
        case val is
            when 0   => result := x"00"; when 1   => result := x"01"; when 2   => result := x"8E"; when 3   => result := x"F4";
            when 4   => result := x"47"; when 5   => result := x"A7"; when 6   => result := x"7A"; when 7   => result := x"BA";
            when 8   => result := x"AD"; when 9   => result := x"9D"; when 10  => result := x"DD"; when 11  => result := x"98";
            when 12  => result := x"3D"; when 13  => result := x"AA"; when 14  => result := x"5D"; when 15  => result := x"96";
            when 16  => result := x"D8"; when 17  => result := x"72"; when 18  => result := x"C0"; when 19  => result := x"58";
            when 20  => result := x"E0"; when 21  => result := x"3E"; when 22  => result := x"4C"; when 23  => result := x"66";
            when 24  => result := x"90"; when 25  => result := x"DE"; when 26  => result := x"55"; when 27  => result := x"80";
            when 28  => result := x"A0"; when 29  => result := x"83"; when 30  => result := x"4B"; when 31  => result := x"2A";
            when 32  => result := x"6C"; when 33  => result := x"ED"; when 34  => result := x"39"; when 35  => result := x"51";
            when 36  => result := x"60"; when 37  => result := x"56"; when 38  => result := x"2C"; when 39  => result := x"8A";
            when 40  => result := x"70"; when 41  => result := x"D0"; when 42  => result := x"1F"; when 43  => result := x"4A";
            when 44  => result := x"26"; when 45  => result := x"8B"; when 46  => result := x"33"; when 47  => result := x"6E";
            when 48  => result := x"48"; when 49  => result := x"89"; when 50  => result := x"6F"; when 51  => result := x"2E";
            when 52  => result := x"A4"; when 53  => result := x"C3"; when 54  => result := x"40"; when 55  => result := x"5E";
            when 56  => result := x"50"; when 57  => result := x"22"; when 58  => result := x"CF"; when 59  => result := x"A9";
            when 60  => result := x"AB"; when 61  => result := x"0C"; when 62  => result := x"15"; when 63  => result := x"E1";
            when 64  => result := x"36"; when 65  => result := x"5F"; when 66  => result := x"F8"; when 67  => result := x"D5";
            when 68  => result := x"92"; when 69  => result := x"4E"; when 70  => result := x"A6"; when 71  => result := x"04";
            when 72  => result := x"30"; when 73  => result := x"88"; when 74  => result := x"2B"; when 75  => result := x"1E";
            when 76  => result := x"16"; when 77  => result := x"67"; when 78  => result := x"45"; when 79  => result := x"93";
            when 80  => result := x"38"; when 81  => result := x"23"; when 82  => result := x"68"; when 83  => result := x"8C";
            when 84  => result := x"81"; when 85  => result := x"1A"; when 86  => result := x"25"; when 87  => result := x"61";
            when 88  => result := x"13"; when 89  => result := x"C1"; when 90  => result := x"CB"; when 91  => result := x"63";
            when 92  => result := x"97"; when 93  => result := x"0E"; when 94  => result := x"37"; when 95  => result := x"41";
            when 96  => result := x"24"; when 97  => result := x"57"; when 98  => result := x"CA"; when 99  => result := x"5B";
            when 100 => result := x"B9"; when 101 => result := x"C4"; when 102 => result := x"17"; when 103 => result := x"4D";
            when 104 => result := x"52"; when 105 => result := x"8D"; when 106 => result := x"EF"; when 107 => result := x"B3";
            when 108 => result := x"20"; when 109 => result := x"EC"; when 110 => result := x"2F"; when 111 => result := x"32";
            when 112 => result := x"28"; when 113 => result := x"D1"; when 114 => result := x"11"; when 115 => result := x"D9";
            when 116 => result := x"E9"; when 117 => result := x"FB"; when 118 => result := x"DA"; when 119 => result := x"79";
            when 120 => result := x"DB"; when 121 => result := x"77"; when 122 => result := x"06"; when 123 => result := x"BB";
            when 124 => result := x"84"; when 125 => result := x"CD"; when 126 => result := x"FE"; when 127 => result := x"FC";
            when others => result := x"00";
        end case;
        return result;
    end function;
    
    -- Parameter calculations

    constant HQC_PARAMS : hqc_params_t := get_hqc_params(PARAM_SET);

    constant PARAM_DELTA : integer := HQC_PARAMS.delta; 
    constant PARAM_K     : integer := HQC_PARAMS.k1;
    constant PARAM_N1    : integer := HQC_PARAMS.n1;
    constant ERR_W       : integer := 8 * PARAM_N1;
    constant Z_W         : integer := 8 * (PARAM_DELTA + 1);
    constant MSG_W       : integer := 8 * PARAM_K;
    
    -- RAM types
    type beta_ram_t is array (0 to PARAM_DELTA-1) of std_logic_vector(7 downto 0);
    type e_ram_t is array (0 to PARAM_DELTA-1) of std_logic_vector(7 downto 0);
    
    -- Internal signals
    signal error_buf           : std_logic_vector(ERR_W-1 downto 0);
    signal z_buf               : std_logic_vector(Z_W-1 downto 0);
    signal err_val             : std_logic_vector(MSG_W-1 downto 0);
    signal dout_valid          : std_logic;
    signal busy                : std_logic;
    signal state               : unsigned(3 downto 0);
    signal state_init          : std_logic;
    signal state_beta          : std_logic;
    signal state_e             : std_logic;
    signal state_err           : std_logic;
    signal state_en            : std_logic;
    
    -- RAM signals
    signal beta_j              : beta_ram_t := (others => (others => '0'));
    signal beta_ji             : std_logic_vector(7 downto 0);
    signal e_j                 : e_ram_t := (others => (others => '0'));
    signal e_ji                : std_logic_vector(7 downto 0);
    signal beta_addr           : unsigned(4 downto 0);
    signal e_addr              : unsigned(4 downto 0);
    signal beta_wr             : std_logic;
    signal e_wr                : std_logic;
    
    signal beta_mask           : std_logic;
    signal delta_cnt           : unsigned(4 downto 0);
    signal e_mask              : std_logic;
    signal exp_array           : std_logic_vector(7 downto 0);
    signal err_dout            : std_logic_vector(7 downto 0);
    
    -- Inverse and temp signals
    signal inv_in              : std_logic_vector(7 downto 0);
    signal inv_out             : std_logic_vector(7 downto 0);
    signal inv_buf             : std_logic_vector(7 downto 0);
    signal tmp1                : std_logic_vector(7 downto 0);
    signal tmp2                : std_logic_vector(7 downto 0);
    signal inv_power           : std_logic_vector(7 downto 0);
    
    -- GF multiplier signals
    signal gfmul_ina1          : std_logic_vector(7 downto 0);
    signal gfmul_ina2          : std_logic_vector(7 downto 0);
    signal gfmul_inb1          : std_logic_vector(7 downto 0);
    signal gfmul_inb2          : std_logic_vector(7 downto 0);
    signal gfmul_outa          : std_logic_vector(7 downto 0);
    signal gfmul_outb          : std_logic_vector(7 downto 0);
    signal gfmul_outb_buf_xor1 : std_logic_vector(7 downto 0);
    
    -- Counter signals
    signal i_cnt               : unsigned(6 downto 0);
    signal i_cnt_en            : std_logic;
    signal ii_cnt              : unsigned(4 downto 0);
    signal ii_cnt_d            : unsigned(4 downto 0);
    signal jj_cnt              : unsigned(4 downto 0);
    signal ii_cnt_en           : std_logic;
    signal jj_cnt_en           : std_logic;
    signal jj_cnt_end          : std_logic;
    signal jj_cnt_end_d        : std_logic;
    signal ik_cnt              : unsigned(4 downto 0);
    signal ik_cnt_en           : std_logic;
    
    -- Component declaration
    component gf_mul is
        generic (
            REG_IN  : integer := 0;
            REG_OUT : integer := 0
        );
        port (
            clk    : in  std_logic;
            start  : in  std_logic;
            in_1   : in  std_logic_vector(7 downto 0);
            in_2   : in  std_logic_vector(7 downto 0);
            output : out std_logic_vector(7 downto 0);
            done   : out std_logic
        );
    end component;

begin

    ------------------------------------------------------------------------------
    -- Buffer Management
    ------------------------------------------------------------------------------
    
    -- error = {m[N1-1],m[N1-2],...,m[1],m[0]} with m[i] in byte
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if start_i = '1' or not (state_beta = '1' or state_err = '1') then
                error_buf <= error_i;
            elsif i_cnt_en = '1' then
                error_buf <= error_buf(7 downto 0) & error_buf(ERR_W-1 downto 8);
            end if;
        end if;
    end process;
    
    -- z_poly = {z[D-1],z[D-2],...,z[1],z[0]} with z[i] in byte
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if start_i = '1' or jj_cnt = 0 then
                z_buf <= z_i;
            elsif jj_cnt_en = '0' then
                z_buf <= z_buf(7 downto 0) & z_buf(Z_W-1 downto 8);
            end if;
        end if;
    end process;
    
    ------------------------------------------------------------------------------
    -- Compute beta_j
    ------------------------------------------------------------------------------
    
    beta_mask <= '1' when (delta_cnt < PARAM_DELTA) and (error_buf(7 downto 0) /= x"00") else '0';
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or not (state_beta = '1' or state_err = '1') or 
               (state_e = '1' and state_en = '1') then
                delta_cnt <= (others => '0');
            elsif beta_mask = '1' and i_cnt_en = '1' then
                delta_cnt <= delta_cnt + 1;
            end if;
        end if;
    end process;
    
    ------------------------------------------------------------------------------
    -- Compute err_val (error values = {e[K-1],e[K-2],...,e[1],e[0]})
    ------------------------------------------------------------------------------
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if state_err = '1' and i_cnt_en = '1' then
                err_val <= err_dout & err_val(MSG_W-1 downto 8);
            end if;
        end if;
    end process;
    
    err_dout <= e_ji when beta_mask = '1' else x"00";
    error_o  <= err_val;
    
    ------------------------------------------------------------------------------
    -- Compute e_j
    ------------------------------------------------------------------------------
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            e_mask <= '1' when ii_cnt_d < delta_cnt else '0';
        end if;
    end process;
    
    -- Inverse GF
    inv_in  <= tmp2 when jj_cnt = PARAM_DELTA else beta_ji;
    inv_out <= gf_inverse(inv_in);
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if state_e = '1' and ((jj_cnt = 0 and jj_cnt_en = '1') or jj_cnt = PARAM_DELTA) then
                inv_buf <= inv_out;
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if jj_cnt = 0 then
                inv_power <= x"01";
            elsif jj_cnt_en = '0' then
                inv_power <= gfmul_outa;        --inv_power = (??�)^jj
            end if;
        end if;
    end process;
    
    -- Compute tmp1 and tmp2
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if jj_cnt = 0 then
                tmp1 <= x"01";
            elsif jj_cnt_en = '1' then
                tmp1 <= tmp1 xor gfmul_outa;
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if jj_cnt = 0 then
                tmp2 <= x"01";
            elsif jj_cnt /= PARAM_DELTA and jj_cnt_en = '1' then
                tmp2 <= gfmul_outb;
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            gfmul_outb_buf_xor1 <= x"01" xor gfmul_outb;
        end if;
    end process;
    
    -- GF Multipliers
    gfmul_ina1 <= tmp1 when jj_cnt_end_d = '1' else inv_power;
    gfmul_ina2 <= inv_buf when jj_cnt_end_d = '1' else
                  z_buf(7 downto 0) when jj_cnt_en = '1' else inv_buf;
    
    gfmul_inb1 <= tmp2 when jj_cnt_en = '1' else inv_buf;
    gfmul_inb2 <= gfmul_outb_buf_xor1 when jj_cnt_en = '1' else beta_ji;
    
    GFMUL_A : gf_mul
        generic map (
            REG_IN  => 0,
            REG_OUT => 0
        )
        port map (
            clk    => clk_i,
            start  => '1',
            in_1   => gfmul_ina1,
            in_2   => gfmul_ina2,
            output => gfmul_outa,
            done   => open
        );
    
    GFMUL_B : gf_mul
        generic map (
            REG_IN  => 0,
            REG_OUT => 0
        )
        port map (
            clk    => clk_i,
            start  => '1',
            in_1   => gfmul_inb1,
            in_2   => gfmul_inb2,
            output => gfmul_outb,
            done   => open
        );
    
    ------------------------------------------------------------------------------
    -- beta_j and e_j RAMs
    ------------------------------------------------------------------------------
    
    -- beta_j RAM
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if beta_wr = '1' then
                if state_init = '1' then
                    beta_j(to_integer(beta_addr)) <= x"00";
                else
                    beta_j(to_integer(beta_addr)) <= std_logic_vector(unsigned(exp_array) + unsigned(beta_ji));
                end if;
            end if;
            beta_ji <= beta_j(to_integer(beta_addr));
        end if;
    end process;
    
    beta_wr <= '1' when (state_init = '1' and i_cnt < PARAM_DELTA) or
                        (state_beta = '1' and i_cnt_en = '1' and beta_mask = '1') else '0';
    
    beta_addr <= resize(i_cnt, 5) when state_init = '1' else
                 delta_cnt when (state_beta = '1' or state_err = '1') else
                 ii_cnt when (state_e = '1' and jj_cnt = 0 and jj_cnt_en = '0') else
                 ik_cnt;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            exp_array <= gf_exp(i_cnt(6 downto 0));
        end if;
    end process;
    
    -- e_j RAM
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if e_wr = '1' then
                if e_mask = '1' then
                    e_j(to_integer(e_addr)) <= x"00";
                else
                    e_j(to_integer(e_addr)) <= gfmul_outa;
                end if;
            end if;
            e_ji <= e_j(to_integer(e_addr));
        end if;
    end process;
    
    e_wr   <= '1' when state_e = '1' and jj_cnt_end_d = '1' else '0';
    e_addr <= ii_cnt_d when state_e = '1' else delta_cnt;
    
    ------------------------------------------------------------------------------
    -- Controller
    ------------------------------------------------------------------------------
    
    -- State machine
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                state <= "1000";
            elsif start_i = '1' then
                state <= "0001";
            elsif state_en = '1' then
                state <= '0' & state(1 downto 0) & '0';
            end if;
        end if;
    end process;
    
    state_init <= state(3);
    state_beta <= state(0);
    state_e    <= state(1);
    state_err  <= state(2);
    state_en   <= '1' when ((state_beta = '1' or state_err = '1') and i_cnt_en = '1' and i_cnt = (PARAM_N1-1)) or
                          (state_e = '1' and jj_cnt_end_d = '1' and ii_cnt = 0) else '0';
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            dout_valid <= '1' when state_err = '1' and state_en = '1' else '0';
        end if;
    end process;
    
    dout_valid_o <= dout_valid;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or (state_err = '1' and state_en = '1') then
                busy <= '0';
            elsif start_i = '1' then
                busy <= '1';
            end if;
        end if;
    end process;
    
    busy_o <= busy;
    
    -- i counter for state_beta and state_err
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or not (state_beta = '1' or state_err = '1' or state_init = '1') then
                i_cnt <= (others => '0');
            elsif i_cnt_en = '1' or (state_init = '1' and i_cnt /= (PARAM_DELTA-1)) then
                i_cnt <= i_cnt + 1;
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or not (state_beta = '1' or state_err = '1') then
                i_cnt_en <= '0';
            elsif state_beta = '1' or state_err = '1' then
                i_cnt_en <= not i_cnt_en;
            end if;
        end if;
    end process;
    
    -- Counters for state_e
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or state_e = '0' or (ii_cnt_en = '1' and ii_cnt = (PARAM_DELTA-1)) then
                ii_cnt <= (others => '0');
            elsif ii_cnt_en = '1' then
                ii_cnt <= ii_cnt + 1;
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            ii_cnt_d <= ii_cnt;
        end if;
    end process;
    
    ii_cnt_en <= jj_cnt_end;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or jj_cnt_end = '1' then
                jj_cnt <= (others => '0');
            elsif jj_cnt_en = '1' then
                jj_cnt <= jj_cnt + 1;
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or state_e = '0' then
                jj_cnt_en <= '0';
            elsif state_e = '1' then
                jj_cnt_en <= not jj_cnt_en;
            end if;
        end if;
    end process;
    
    jj_cnt_end <= '1' when jj_cnt_en = '1' and jj_cnt = PARAM_DELTA else '0';
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            jj_cnt_end_d <= jj_cnt_end;
        end if;
    end process;
    
    -- (i+k)%PARAM_DELTA counter
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or state_e = '0' or (ik_cnt_en = '1' and ik_cnt = (PARAM_DELTA-1)) then
                ik_cnt <= (others => '0');
            elsif ik_cnt_en = '1' then
                ik_cnt <= ik_cnt + 1;
            end if;
        end if;
    end process;
    
    ik_cnt_en <= not jj_cnt_en;

end rtl;