library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.math_real.all;

--use ieee.math_real.log2;
--use ieee.math_real.ceil;

package system_constants is

-- Generic constants --
-- Functions --
function clog2(n : positive) return natural;

function mat_dim ( x : std_logic_vector(5 downto 0) ) return natural;

-- Components --

component gf_mul is
    generic (
        REG_IN  : integer := 1;
        REG_OUT : integer := 1
    );
    port (
        clk    : in  std_logic;
        start  : in  std_logic;
        in_1   : in  std_logic_vector(7 downto 0);
        in_2   : in  std_logic_vector(7 downto 0);
        output : out std_logic_vector(7 downto 0);
        done   : out std_logic
    );
end component gf_mul;

component rm_encoder is
    generic (
        ENCODING_MATRIX_0 : std_logic_vector(127 downto 0) := x"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        ENCODING_MATRIX_1 : std_logic_vector(127 downto 0) := x"cccccccccccccccccccccccccccccccc";
        ENCODING_MATRIX_2 : std_logic_vector(127 downto 0) := x"f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0";
        ENCODING_MATRIX_3 : std_logic_vector(127 downto 0) := x"ff00ff00ff00ff00ff00ff00ff00ff00";
        ENCODING_MATRIX_4 : std_logic_vector(127 downto 0) := x"ffff0000ffff0000ffff0000ffff0000";
        ENCODING_MATRIX_5 : std_logic_vector(127 downto 0) := x"00000000ffffffff00000000ffffffff";
        ENCODING_MATRIX_6 : std_logic_vector(127 downto 0) := x"0000000000000000ffffffffffffffff";
        ENCODING_MATRIX_7 : std_logic_vector(127 downto 0) := x"ffffffffffffffffffffffffffffffff"
    );
    port (
        clk      : in  std_logic;
        rst      : in  std_logic;
        start    : in  std_logic;                     -- not used in logic, kept for interface compatibility
        byte_in  : in  std_logic_vector(7 downto 0);
        cdw_out  : out std_logic_vector(127 downto 0);
        done     : out std_logic
    );
end component rm_encoder;

component mem_single is
    generic (
        WIDTH 	  : positive := 8;
        DEPTH 	  : positive := 64;
        INIT_FILE : string   := "";
        INIT  	  : boolean  := false
    );
    port (
        clk      : in  std_logic;
        data_in  : in  std_logic_vector(WIDTH-1 downto 0);
        address  : in  std_logic_vector(clog2(DEPTH)-1 downto 0);
        wr_en    : in  std_logic;
        data_out : out std_logic_vector(WIDTH-1 downto 0)
    );
end component mem_single;

end system_constants;

package body system_constants is

function mat_dim ( x : std_logic_vector(5 downto 0) ) return natural is
--        variable temp : natural := x ;
--        variable n : natural := 0 ;
    begin
	if to_integer(unsigned(x)) < 4 then
--	   n := 2	
	   return ( 2 );
	elsif to_integer(unsigned(x)) < 16 then 
	   return ( 4 );
	else
	   return ( 8 );
--        while temp > 1 loop
--            temp := temp / 2 ;
--            n := n + 1 ;
--        end loop ;
        end if ;
end function mat_dim ;

-- Helper function to compute ceil(log2(n))
function clog2(n : positive) return natural is
 variable tmp : natural := 1;
 variable log : natural := 0;
  begin
   tmp := n;
   while tmp > 1 loop
    tmp := (tmp + 1) / 2;
    log := log + 1;
   end loop;
  return log;
end function clog2;

end system_constants;