--/*Main Conversions:
--1. Parameter Calculations Using Helper Functions
--Instead of Verilog's conditional expressions in parameter declarations, VHDL uses:
--vhdlconstant HQC_PARAMS   : hqc_params_t := get_hqc_params(PARAM_SET);
--constant MULTIPLICITY : integer := get_MULTIPLICITY(PARAM_SET);
--constant IN_AW        : integer := get_IN_AW(PARAM_SET);
--constant PARAM_K      : integer := HQC_PARAMS.k1;

--2. Generic Mapping
--vhdl-- Verilog: .PARAM_SECURITY (PARAM_SECURITY)
---- VHDL:
--generic map (
--    PARAM_SET => PARAM_SET
--)

--3. Port Mapping
--All Verilog port connections converted to VHDL named association:
--vhdlport map (
--    clk_i           => clk_i,
--    rst_ni          => rst_ni,
--    ...
--)

--4. Unused Outputs
--vhdl-- Verilog: .ram_dout_addr_o()
---- VHDL: Connected to internal signal
--ram_dout_addr_o => rm_dout_addr
--VHDL requires all outputs to be connected, so I created an internal signal.

--5. Component Declarations
--Both submodules declared as components with proper generic and port specifications.

--Module Purpose
--This top-level decoder integrates:

--Reed-Muller Decoder (hqc_rmdecod_top):
--Reads encoded data from input RAM
--Performs RM soft-decision decoding
--Outputs decoded bytes to RS decoder

--Reed-Solomon Decoder (hqc_rsdecod_top):
--Receives RM decoder output
--Performs RS error correction
--Outputs final corrected message

--The two decoders operate in pipeline fashion:
--RM decoder produces bytes sequentially
--RS decoder consumes them as they arrive
--Final output is error-corrected message

--This implements the complete two-stage error correction for the HQC post-quantum cryptosystem!
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity hqc_decod_top is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i           : in  std_logic;
        rst_ni          : in  std_logic;
        start_i         : in  std_logic;  -- 1 pulse start signal
        busy_o          : out std_logic;  -- decoding is busy signal
        -- Input RAM, read
        ram_din_i       : in  std_logic_vector(127 downto 0);
        ram_din_rd_o    : out std_logic;
        ram_din_addr_o  : out std_logic_vector(get_IN_AW(PARAM_SET)-1 downto 0);
        -- Output data
        dout_o          : out std_logic_vector((get_hqc_params(PARAM_SET).k1*8)-1 downto 0);--(DOUT_W-1 downto 0);  -- msg = {m[K-1],m[K-2],...,m[1],m[0]} with m[i] in byte
        dout_valid_o    : out std_logic  -- output valid
    );
end hqc_decod_top;

architecture rtl of hqc_decod_top is

    -- Parameter calculations
    constant HQC_PARAMS   : hqc_params_t := get_hqc_params(PARAM_SET);
    constant MULTIPLICITY : integer := get_MULTIPLICITY(PARAM_SET);
    constant IN_AW        : integer := get_IN_AW(PARAM_SET);
    constant PARAM_K      : integer := HQC_PARAMS.k1;
    constant DIN_W        : integer := 128;
    constant DOUT_W       : integer := 8 * PARAM_K;
    
    -- Internal signals
    signal rm_busy        : std_logic;
    signal rm_dout_done   : std_logic;
    signal rm_dout_valid  : std_logic;
    signal rm_dout        : std_logic_vector(7 downto 0);
    signal rm_dout_addr   : std_logic_vector(7 downto 0);
    signal rs_busy        : std_logic;
    signal rs_done        : std_logic;
    signal rs_dout        : std_logic_vector(DOUT_W-1 downto 0);
    signal last_busy      : std_logic;
    
    -- Component declarations
    component hqc_rmdecod_top is
        generic (
            PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
        );
        port (
            clk_i          : in  std_logic;
            rst_ni         : in  std_logic;
            start_i        : in  std_logic;
            busy_o         : out std_logic;
            done_o         : out std_logic;
            ram_din_i      : in  std_logic_vector(127 downto 0);
            ram_din_rd_o   : out std_logic;
            ram_din_addr_o : out std_logic_vector;
            ram_dout_wr_o  : out std_logic;
            ram_dout_o     : out std_logic_vector(7 downto 0);
            ram_dout_addr_o: out std_logic_vector(7 downto 0)
        );
    end component;
    
    component hqc_rsdecod_top is
        generic (
            PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET;
            DIN_W     : integer := 8
        );
        port (
            clk_i        : in  std_logic;
            rst_ni       : in  std_logic;
            start_i      : in  std_logic;
            busy_o       : out std_logic;
            last_busy_o  : out std_logic;
            done_o       : out std_logic;
            din_i        : in  std_logic_vector(7 downto 0);
            din_valid_i  : in  std_logic;
            din_done_i   : in  std_logic;
            dout_o       : out std_logic_vector
        );
    end component;

begin

    -- Reed-Muller Decoder
    RM_DECOD : hqc_rmdecod_top
        generic map (
            PARAM_SET => PARAM_SET
        )
        port map (
            clk_i           => clk_i,
            rst_ni          => rst_ni,
            start_i         => start_i,
            busy_o          => rm_busy,
            done_o          => rm_dout_done,
            ram_din_i       => ram_din_i,
            ram_din_rd_o    => ram_din_rd_o,
            ram_din_addr_o  => ram_din_addr_o,
            ram_dout_wr_o   => rm_dout_valid,
            ram_dout_o      => rm_dout,
            ram_dout_addr_o => rm_dout_addr
        );
    
    -- Reed-Solomon Decoder
    RS_DECOD : hqc_rsdecod_top
        generic map (
            PARAM_SET => PARAM_SET,
            DIN_W     => 8
        )
        port map (
            clk_i        => clk_i,
            rst_ni       => rst_ni,
            start_i      => start_i,
            din_i        => rm_dout,
            din_valid_i  => rm_dout_valid,
            din_done_i   => rm_dout_done,
            busy_o       => rs_busy,
            last_busy_o  => last_busy,
            done_o       => rs_done,
            dout_o       => rs_dout
        );
    
    -- Output assignments
    dout_o       <= rs_dout;
    busy_o       <= rs_busy;
    dout_valid_o <= rs_done;

end rtl;