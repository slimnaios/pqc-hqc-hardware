library ieee;  
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.system_constants.all;
use WORK.HQC_parameters.all;

entity tb_concat_code is
     generic (
        PARAM_SET : hqc_params_set_t := HQC_128
    );
end tb_concat_code;

architecture test of tb_concat_code is

component concat_code is
    generic (
        PARAM_SET : hqc_params_set_t := HQC_128
    );
    port (
        clk           : in  std_logic;
        rst           : in  std_logic;
        start         : in  std_logic;
        msg_in        : in  std_logic_vector((get_hqc_params(PARAM_SET).k1*8)-1 downto 0); --(K-1 downto 0);
        cdw_out_en    : in  std_logic;
        cdw_out_addr  : in  std_logic_vector(clog2(get_hqc_params(PARAM_SET).n1)-1 downto 0); --(LOG_N1_BYTES-1 downto 0);
        cdw_out       : out std_logic_vector(127 downto 0);
        done          : out std_logic
    );
end component concat_code;

constant HQC_PARAMS   : hqc_params_t := get_hqc_params(PARAM_SET);

constant N1_BYTES     : natural := HQC_PARAMS.n1;
constant N1           : natural := 8*N1_BYTES;
constant LOG_N1_BYTES : natural := clog2(N1_BYTES);
constant K_BYTES      : natural := HQC_PARAMS.k1;
constant K            : natural := 8*K_BYTES;

signal  clk, rst  : std_logic;
signal  start     : std_logic := '1';
signal  msg_in    : std_logic_vector(K-1 downto 0);
signal cdw_out_en : std_logic;

signal cdw_out_addr : std_logic_vector(LOG_N1_BYTES-1 downto 0);
signal cdw_out      : std_logic_vector(127 downto 0);
signal done         : std_logic;
    
constant CLOCK_PERIOD : time := 10 ns;

--type arr is array(integer range <>) of std_logic_vector(367 downto 0);    
type arr is array(integer range <>) of std_logic_vector(K-1 downto 0);

constant CHECK_CASES : integer := 2;

constant cdw_check: arr(0 to CHECK_CASES-1)  := (
--x"1f1e1d1c1b1a191817161514131211100f0e0d0c0b0a09080706050403020100",
--x"000000000000000000000000000000000000000000000000000F878C4BF65402"

x"0f0e0d0c0b0a09080706050403020100",
x"0000000000000000000D96089C6C8158"
--x"00000000000000000000000000000000000000000000000000000000000000000000000000000000BD1E364C58AA",
--x"00000000000000000000000000000000000000000000000000000000000000000000000000000002FD6E20D14535",
--x"00000000000000000000000000000000000000000000000000000000000000000000000000000007F94C958C3EDD",
--x"00000000000000000000000000000000000000000000000000000000000000000000000000000008C1651250ECEC",
--x"00000000000000000000000000000000000000000000000000000000000000000000000000000004047081E8F810",
--x"00000000000000000000000000000000000000000000000000000000000000000000000000000006164E626A87E5",
--x"0000000000000000000000000000000000000000000000000000000000000000000000000000000564DAB6C6F29F"
);   
   
begin
    
dut: concat_code
    generic map(
        PARAM_SET => PARAM_SET
    )
     port map
     (
        clk          => clk,
        rst          => rst,
        start        => start,
	    msg_in       => msg_in,  -- length depends on parameter_set
	    cdw_out_en   => cdw_out_en,
        cdw_out_addr => (others => '0'),  -- width = ceil(log2(N1_BYTES))
        cdw_out      => cdw_out,
        done   	     => done
);
-----------------------------------------------------------------------    
    
tb: process  

begin
       
wait until rst = '1';
wait until rst = '0';

report "Simulation started!";

start <= '0'; 
cdw_out_en <= '1';

-- 4 cycles
   for i in 0 to 3 loop
    wait until rising_edge(clk);
   end loop;	

start <= '1'; 

--for k in 1 to CHECK_CASES loop
--
-- if (enc_dec = '0') then
	msg_in <= cdw_check(0);		 
-- else

-- end if;

--New input every 40 cycles
 for i in 0 to 43 loop
  wait until rising_edge(clk);
 end loop;
 
--end loop;

start <= '0';

end process;

check_results: process
       
variable result: std_logic_vector (127 downto 0);
    
begin

wait until rst = '1';
wait until rst = '0';
        
--for t in 0 to CHECK_CASES-1 loop
 wait until cdw_out_en = '1';
 wait until rising_edge(clk);

--	if (enc_dec = '0') then
	 result := cdw_out;		 
--	else 
--	 result := Data_out((DATAPATH_SIZE-1) downto 0) & Data_out((2*DATAPATH_SIZE-1) downto DATAPATH_SIZE);
--	end if;
    if done = '1' then
    --if result = ciphertext_check(t) then
	 report "Codeword produced!";
    --else
	 --report "Test vector failed!" severity failure;
   end if;  
        
--end loop;       
	
end process;    
   
clock: process				
begin					
 clk <= '0';
 wait for CLOCK_PERIOD/2;	--5 ns
 clk <= '1';
 wait for CLOCK_PERIOD/2;

if NOW > 1200 ns then
 assert false report "Simulation terminated!" severity note;
 wait;
end if;

end process;

reset: process
begin
 rst <= '0';
 wait for 5 ns;
 rst <= '1';
 wait for 5 ns;
 rst <= '0';
 wait;
 
end process;

end test;  




