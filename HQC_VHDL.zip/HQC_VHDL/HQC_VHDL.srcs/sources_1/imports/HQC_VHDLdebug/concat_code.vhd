--/*Main conversions:

--Helper functions: Added get_N1_BYTES, get_K_BYTES, and clog2 functions to calculate parameters based on the generic parameter_set
--CLOG2 macro: The Verilog  `CLOG2 macro is replaced with a VHDL clog2 function that calculates the ceiling of log base 2
--Component declarations: Declared both reed_solomon_encode and reed_muller_encode components with their interfaces
--Component instantiation: Converted Verilog module instances to VHDL component instances with generic map and port map
--Signal connections: The done_rs signal connects the output of the Reed-Solomon encoder to the start input of the Reed-Muller encoder, creating a pipeline

--Key implementation details:

--The clog2 function implements ceiling(log2(n)) by iteratively dividing by 2 and counting steps
--Constants are calculated from the helper functions based on the parameter_set generic
--The module instantiates two encoders in sequence: Reed-Solomon followed by Reed-Muller
--The Reed-Muller encoder starts when the Reed-Solomon encoder completes (controlled by done_rs)
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity concat_code is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk           : in  std_logic;
        rst           : in  std_logic;
        start         : in  std_logic;
        msg_in        : in  std_logic_vector((get_hqc_params(PARAM_SET).k1*8)-1 downto 0); --(K-1 downto 0);
        cdw_out_en    : in  std_logic;
        cdw_out_addr  : in  std_logic_vector(clog2(get_hqc_params(PARAM_SET).n1)-1 downto 0); --(LOG_N1_BYTES-1 downto 0);
        cdw_out       : out std_logic_vector(127 downto 0);
        done          : out std_logic
    );
end concat_code;

architecture rtl of concat_code is

constant HQC_PARAMS : hqc_params_t := get_hqc_params(PARAM_SET);

constant N1_BYTES     : natural := HQC_PARAMS.n1;
constant N1           : natural := 8*N1_BYTES;
constant LOG_N1_BYTES : natural := clog2(N1_BYTES);
constant K_BYTES      : natural := HQC_PARAMS.k1;
constant K            : natural := 8*K_BYTES;
    
-- Internal signals
signal rs_cdw_out : std_logic_vector(N1-1 downto 0);
signal done_rs    : std_logic;
    
begin

    -- Reed-Solomon Encoder instance
    REED_SOLOMON_CODE : reed_solomon_encode
        generic map (
            PARAM_SET => PARAM_SET
        )
        port map (
            clk     => clk,
            rst     => rst,
            start   => start,
            msg_in  => msg_in,
            cdw_out => rs_cdw_out,
            done    => done_rs
        );
    
    -- Reed-Muller Encoder instance
    REED_MULLER_CODE : reed_muller_encode
        generic map (
            PARAM_SET => PARAM_SET
        )
        port map (
            clk          => clk,
            rst          => rst,
            start        => done_rs,
            rs_cdw_in    => rs_cdw_out,
            cdw_out_addr => cdw_out_addr,
            cdw_out_en   => cdw_out_en,
            cdw_out      => cdw_out,
            done         => done
        );

end rtl;