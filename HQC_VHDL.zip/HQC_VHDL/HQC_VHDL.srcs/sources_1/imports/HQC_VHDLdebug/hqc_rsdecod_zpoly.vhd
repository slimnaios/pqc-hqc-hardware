--/*Main conversions:

--Z-polynomial calculation: This module computes the error evaluator polynomial Z(x) using the syndrome and error locator polynomial (sigma). 
--It allows to determine the magnitude (value) of each error, not just its location.


--Three shift buffers:
--syndrome_buf1: Rotates right on each i_cnt (outer loop iteration)
--syndrome_buf2: Loaded from buf1, then rotates left on each j_cnt (inner loop iteration)
--sigma_buf: Reloaded from input on i_cnt, rotates right on each j_cnt

--Nested loop structure:
--Outer loop (i_cnt): Iterates PARAM_DELTA times (0 to DELTA)
--Inner loop (j_cnt): For each i, iterates from 0 to i-1
--Computes: Z[i] = ?(sigma[j] � syndrome[i-j-1]) for j=0 to deg_sigma

--Z-value computation:
--When i=0: Z[0] = 1
--When j=0: Z[i] starts with sigma[i] ? syndrome[i-1]
--Accumulates: Z[i] ?= sigma[j] � syndrome[i-j-1]


--Mask logic: Only compute when i < deg_sigma+1 (within polynomial degree)

--Key implementation details:

--Sequential accumulation: z_buf accumulates the XOR of GF multiplications
--i_sigma selection: Chooses appropriate sigma coefficient based on i_cnt value
--j_cnt_end logic: Inner loop completes when j reaches i-1 (special case for i=0)
--Combinational z calculation: Uses process sensitivity list for immediate updates

--Algorithm purpose:
--The Z-polynomial (also called omega or error evaluator polynomial) is used in the Forney algorithm to compute error values. 
--Together with the error locator polynomial (sigma), it enables complete error correction:

--Sigma: Tells WHERE errors occurred (error locations)
--Z: Tells WHAT the error values are (error magnitudes)

--The formula computed is:
--Z(x) = S(x) � ?(x) mod x^(2t)
--Where:
--  S(x) = syndrome polynomial = S? + S?x + S?x� + ...
--  ?(x) = error locator polynomial (from previous module)
--  t = PARAM_DELTA (error correction capability)
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity hqc_rsdecod_zpoly is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i        : in  std_logic;
        rst_ni       : in  std_logic;
        synd_i       : in  std_logic_vector;--(SYN_W-1 downto 0);   -- syndrome, first DELTA syndromes
        sigma_i      : in  std_logic_vector;--(DIN_W-1 downto 0);   -- sigma
        start_i      : in  std_logic;
        deg_sigma_i  : in  std_logic_vector;--(7 downto 0);         -- degree of sigma
        busy_o       : out std_logic;
        dout_o       : out std_logic_vector;--(DOUT_W-1 downto 0);  -- z poly
        dout_valid_o : out std_logic
    );
end hqc_rsdecod_zpoly;

architecture rtl of hqc_rsdecod_zpoly is

  -- Parameter calculations 
constant HQC_PARAMS : hqc_params_t := get_hqc_params(PARAM_SET);

constant PARAM_DELTA : integer := HQC_PARAMS.delta;
    
    constant SYN_W       : integer := 8 * PARAM_DELTA;
    constant DIN_W       : integer := 8 * (PARAM_DELTA + 1);
    constant DOUT_W      : integer := 8 * (PARAM_DELTA + 1);
    
    -- Internal signals
    signal dout           : std_logic_vector(DOUT_W-1 downto 0);
    signal syndrome_buf1  : std_logic_vector(SYN_W-1 downto 0);
    signal syndrome_buf2  : std_logic_vector(SYN_W-1 downto 0);
    signal sigma_buf      : std_logic_vector(DIN_W-1 downto 0);
    signal i_sigma        : std_logic_vector(7 downto 0);
    signal z_buf          : std_logic_vector(7 downto 0);
    signal z              : std_logic_vector(7 downto 0);
    signal gf_mul_out     : std_logic_vector(7 downto 0);
    signal mask           : std_logic;
    signal i_cnt          : unsigned(5 downto 0);
    signal j_cnt          : unsigned(5 downto 0);
    signal i_cnt_en       : std_logic;
    signal j_cnt_en       : std_logic;
    signal j_cnt_end      : std_logic;
    signal busy_end       : std_logic;
    signal busy           : std_logic;
    signal dout_valid     : std_logic;
    
    -- Component declaration
--    /*component gf_mul is
--        generic (
--            REG_IN  : integer := 0;
--            REG_OUT : integer := 0
--        );
--        port (
--            clk    : in  std_logic;
--            start  : in  std_logic;
--            in_1   : in  std_logic_vector(7 downto 0);
--            in_2   : in  std_logic_vector(7 downto 0);
--            output : out std_logic_vector(7 downto 0);
--            done   : out std_logic
--        );
--    end component;
--    */

begin

    -- First D syndromes = {m[D-1],m[D-2],...,m[1],m[0]} with m[i] in byte
    -- Syndromes buffer from input, rotates right on each i_cnt
    -- Holds syndromes, rotates to select S[i-1], S[i-2], etc.
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if start_i = '1' then
                syndrome_buf1 <= synd_i;
            elsif i_cnt_en = '1' then
                syndrome_buf1 <= syndrome_buf1(7 downto 0) & syndrome_buf1(8*PARAM_DELTA-1 downto 8);
            end if;
        end if;
    end process;
    
    -- Syndromes buffer from buffer1, rotates left on each j_cnt
    -- Working copy for inner loop, rotates to access S[i-j-1]
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if i_cnt_en = '1' then
                syndrome_buf2 <= syndrome_buf1;
            elsif j_cnt_en = '1' then
                syndrome_buf2 <= syndrome_buf2(8*PARAM_DELTA-8-1 downto 0) & 
                                 syndrome_buf2(8*PARAM_DELTA-1 downto 8*PARAM_DELTA-8);
            end if;
        end if;
    end process;
    
    -- Sigma buffer from input in start or each i_cnt, rotates right on each j_cnt
    -- Provides ?[j] coefficients for multiplication
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if start_i = '1' or i_cnt_en = '1' then
                sigma_buf <= sigma_i;
            elsif j_cnt_en = '1' then
                sigma_buf <= std_logic_vector(resize(unsigned(sigma_buf(7 downto 0) & sigma_buf(8*PARAM_DELTA-1 downto 8)),sigma_buf'length));
                
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if i_cnt_en = '1' then
                if i_cnt = 0 then
                    i_sigma <= sigma_buf(15 downto 8);
                else
                    i_sigma <= sigma_buf(23 downto 16);
                end if;
            end if;
        end if;
    end process;
    
    -- Calculate z poly
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if start_i = '1' then
                dout <= (others => '0');
            elsif i_cnt_en = '1' then
                dout <= z & dout(DOUT_W-1 downto 8);            -- Shift in new coefficient
            end if;
        end if;
    end process;
    
    dout_o <= dout;
    
    -- Calculate z value
    process(i_cnt, mask, j_cnt, i_sigma, syndrome_buf2, z_buf, gf_mul_out)
    begin
        if i_cnt = 0 then
            z <= x"01";                                         -- Z[0] = 1
        elsif mask = '1' then
            if j_cnt = 0 then
                z <= i_sigma xor syndrome_buf2(7 downto 0);     -- Initial value 
            else
                z <= z_buf xor gf_mul_out;                      -- Accumulate GF multiplications
            end if;
        else
            z <= x"00";                                         -- Outside degree, Z[i] = 0       
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if j_cnt_en = '1' then
                if mask = '1' then
                    z_buf <= z;
                else
                    z_buf <= x"00";
                end if;
            end if;
        end if;
    end process;
    
    mask <= '1' when i_cnt < unsigned(deg_sigma_i) + 1 else '0';
    
    -- gf_mul(sigma[j], syndrome[i-j-1])
    GF_MULT : gf_mul
        generic map (
            REG_IN  => 0,
            REG_OUT => 0
        )
        port map (
            clk    => clk_i,
            start  => '1',
            in_1   => syndrome_buf2(7 downto 0),    -- S[i-j-1]
            in_2   => sigma_buf(7 downto 0),        -- ?[j]
            output => gf_mul_out,                   -- ?[j] � S[i-j-1]
            done   => open
        );
    
    ------------------------------------------------------------------------------
    -- Controller
    ------------------------------------------------------------------------------
    
    -- Busy flag
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or busy_end = '1' then
                busy <= '0';
            elsif start_i = '1' then
                busy <= '1';
            end if;
        end if;
    end process;
    
    busy_o <= busy;
    
    -- i counter
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or busy_end = '1' then
                i_cnt <= (others => '0');
            elsif i_cnt_en = '1' then
                i_cnt <= i_cnt + 1;
            end if;
        end if;
    end process;
    
    --i_cnt_en <= j_cnt_end and busy;
    i_cnt_en <= '1' when (j_cnt_end = '1') and (busy = '1') else '0';
    busy_end <= '1' when (i_cnt = PARAM_DELTA) and (i_cnt_en = '1') else '0';
    
    -- j counter
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or i_cnt_en = '1' then
                j_cnt <= (others => '0');
            elsif j_cnt_en = '1' then
                j_cnt <= j_cnt + 1;
            end if;
        end if;
    end process;
    
    j_cnt_en  <= busy;
    j_cnt_end <= '1' when i_cnt /= 0 else '0';      --equivalent Verilog expression => assign j_cnt_end = (i_cnt==0)? 0 : (i_cnt-1);
    
    -- Output valid
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            dout_valid <= busy_end;
        end if;
    end process;
    
    dout_valid_o <= dout_valid;

--/*
--## Control Flow Summary
--```
--START
--  ?
--busy = '1'
--  ?
--i_cnt = 0 ???? Z[0] = 1 ???? i_cnt++
--  ?
--i_cnt = 1 ???? j=0: Z[1] = ?[1]?S[0] ???? i_cnt++
--  ?
--i_cnt = 2 ???? j=0: Z[2] = ?[2]?S[1]
--             j=1: Z[2] ?= ?[0]�S[0] ???? i_cnt++
--  ?
--...continue until i_cnt = DELTA...
--  ?
--busy_end = '1'
--  ?
--dout_valid = '1'
--  ?
--Output Z-polynomial ready
--```

--## Example Calculation

--Assume DELTA=3, deg(?)=2:
--- ?(x) = ?? + ??x + ??x�
--- S = [S?, S?, S?]

--**Computation**:
--```
--Z[0] = 1

--Z[1] = ?[1] ? S[0]
--     = ?? ? S?

--Z[2] = ?[2] ? S[1]
--     ? ?[0] � S[0]
--     = ?? ? S? ? (?? � S?)

--Z[3] = 0 (beyond deg(?)+1)
--*/

end rtl;