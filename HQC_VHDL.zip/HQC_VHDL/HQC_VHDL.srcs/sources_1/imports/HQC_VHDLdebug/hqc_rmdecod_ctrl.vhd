--/*Main conversions:

--Helper functions: Created functions to calculate MULTIPLICITY, N1, IN_AW, and OUT_AW based on the PARAM_SECURITY generic
--Parameter dependencies: All parameters that depend on PARAM_SECURITY are now calculated using helper functions and stored as constants
--Always blocks to processes: All always @(posedge clk_i) blocks converted to clocked processes with rising_edge(clk_i)
--Reset logic: Active-low reset rst_ni (reset not inverted) is checked with rst_ni = '0'
--Counters: Changed reg counters to unsigned signals with proper width
--Combinational assignments: Wire assignments converted to concurrent signal assignments
--Type conversions: Added std_logic_vector() conversions when assigning unsigned counters to output ports

--Key implementation details:
--This is the master controller that coordinates three processing stages:
--Input RAM - reads encoded data
--Expand-and-Sum (EAS) - performs Reed-Muller decoding
--Peak Detection + Output RAM - finds peaks and stores results

--The module controls a Reed-Muller decoder with three main sections: input RAM, expand-and-sum (EAS), and output RAM with peak detection
--Input counter tracks RAM reads up to N1*MULTIPLICITY*128/128-1
--Output counter tracks valid peaks up to N1-1
--The eas_start_o signal uses edge detection on eas_start_ready_i to generate start pulses
--Busy flag is set on start and cleared when the last output is detected
--Done flag pulses for one cycle when decoding completes

--## Data Flow Timeline
--```
--start_i pulse ? ram_din_en='1' ? Read input RAM ? Feed to EAS
--                                                      ?
--                                              EAS processes data
--                                                      ?
--                                          Peak detection finds maxima
--                                                      ?
--                              peak_valid_i pulses ? Write to output RAM
--                                                      ?
--                                          cnt_out reaches N1_BYTES-1
--                                                      ?
--                                  last_dout='1' ? done_o pulses, busy_o='0'

--Key Design Patterns
--Handshaking: Uses ready/valid protocols to prevent data loss
--Edge Detection: Generates start pulses on rising edges to avoid continuous triggering
--Pipelined Control: Each stage operates semi-independently with flow control
--State-Free Design: Uses counters and flags instead of explicit FSM states
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity hqc_rmdecod_ctrl is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i              : in  std_logic;
        rst_ni             : in  std_logic;
        start_i            : in  std_logic;
        busy_o             : out std_logic;
        done_o             : out std_logic;
        -- Input RAM
        ram_din_i          : in  std_logic_vector(127 downto 0);
        ram_din_rd_o       : out std_logic;
        ram_din_addr_o     : out std_logic_vector;--(IN_AW-1 downto 0);
        -- Expand and Sum
        eas_din_o          : out std_logic_vector(127 downto 0);
        eas_start_ready_i  : in  std_logic;
        eas_start_o        : out std_logic;
        eas_din_valid_o    : out std_logic;
        eas_din_ready_i    : in  std_logic;
        -- Find Peaks
        peak_valid_i       : in  std_logic;
        peak_dout_i        : in  std_logic_vector(7 downto 0);
        -- Output RAM
        ram_dout_wr_o      : out std_logic;
        ram_dout_o         : out std_logic_vector(7 downto 0);
        ram_dout_addr_o    : out std_logic_vector--(OUT_AW-1 downto 0)
    );
end hqc_rmdecod_ctrl;

architecture rtl of hqc_rmdecod_ctrl is
 
-- Parameter calculations
constant HQC_PARAMS   : hqc_params_t := get_hqc_params(PARAM_SET);
constant N1_BYTES     : integer := HQC_PARAMS.n1;
constant MULTIPLICITY : integer := get_MULTIPLICITY(PARAM_SET);
constant IN_AW        : integer := get_IN_AW(PARAM_SET);
constant OUT_AW       : integer := get_OUT_AW(PARAM_SET);

-- Internal signals
signal start_d           : std_logic;
signal eas_start_ready_d : std_logic;
signal ram_din_en        : std_logic;
signal ram_din_ack       : std_logic;
signal cnt_in            : unsigned(IN_AW-1 downto 0);
signal cnt_out           : unsigned(OUT_AW-1 downto 0);
signal busy              : std_logic;
signal done              : std_logic;
signal last_din          : std_logic;
signal last_dout         : std_logic;
signal ram_din_rd        : std_logic;

begin

-- Input Counter
process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or start_i = '1' or last_din = '1' then
            cnt_in <= (others => '0');
        elsif ram_din_rd = '1' then
            cnt_in <= cnt_in + 1;
        end if;
    end if;
end process;

last_din <= '1' when (cnt_in = (N1_BYTES*MULTIPLICITY*128/128-1)) and (ram_din_rd = '1') else '0';

-- Input RAM Control
process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or last_din = '1' then
            ram_din_en <= '0';
        elsif start_i = '1' then
            ram_din_en <= '1';
        end if;
    end if;
end process;

process(clk_i)
begin
    if rising_edge(clk_i) then
        ram_din_ack <= ram_din_rd;
    end if;
end process;

ram_din_rd      <= ram_din_en and eas_start_ready_i;
ram_din_rd_o    <= ram_din_rd;
ram_din_addr_o  <= std_logic_vector(cnt_in);

-- Expand and Sum Control
eas_din_o       <= ram_din_i;
eas_start_o     <= (start_d or (not eas_start_ready_d and eas_start_ready_i)) and ram_din_en;
eas_din_valid_o <= ram_din_ack;

process(clk_i)
begin
    if rising_edge(clk_i) then
        start_d           <= start_i;
        eas_start_ready_d <= eas_start_ready_i;
    end if;
end process;

-- Output Counter
process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or start_i = '1' then
            cnt_out <= (others => '0');
        elsif peak_valid_i = '1' then
            cnt_out <= cnt_out + 1;
        end if;
    end if;
end process;

ram_dout_o      <= peak_dout_i;
ram_dout_wr_o   <= peak_valid_i;
ram_dout_addr_o <= std_logic_vector(resize(cnt_out, ram_dout_addr_o'length));

-- Busy and Done Control
process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or last_dout = '1' then
            busy <= '0';
        elsif start_i = '1' then
            busy <= '1';
        end if;
    end if;
end process;

process(clk_i)
begin
    if rising_edge(clk_i) then
        done <= last_dout;
    end if;
end process;

last_dout <= '1' when (peak_valid_i = '1') and (cnt_out = (N1_BYTES-1)) else '0';

busy_o <= busy;
done_o <= done;

end rtl;