--/*Main conversions:

--Encoding matrices: 8 parameterizable 128-bit matrices representing Reed-Muller generator matrix rows
--Matrix selection: Based on input byte bits, selects which encoding matrices to include (similar to basis vector selection)
--XOR combination: All selected matrices are XORed together to produce the codeword
--Byte rearrangement: Two-stage permutation:

--First: Reorders bytes in groups (bytes 12-15, 8-11, 4-7, 0-3)
--Second: Bit-reverses each byte



--Key implementation details:

--Combinational logic: Matrix selection is combinational (sensitivity to in_byte)
--Array type: Used matrix_array_t for cleaner array of matrices
--Generate statement: Creates the final byte reversal mapping

--Algorithm purpose:
--This implements a (128,8) Reed-Muller code encoder:

--Input: 8-bit message
--Output: 128-bit codeword
--Each bit of the input selects one row of the generator matrix
--Selected rows are XORed to form the codeword
--Final permutation ensures proper bit/byte ordering

--Initial ordering ? Bits are conceptually indexed by natural binary order of 7-bit vectors (0..127), 
--packed sequentially into bytes ? misaligned with RM recursive structure.
--Transformation 1 (cdw_rearrange) ? Custom byte shuffle to realign with the mathematical grouping.
--Transformation 2 (byte reversal) ? Final flip to standard big-endian/memory order.

--The encoding matrices form a first-order Reed-Muller code basis, commonly used in the HQC cryptosystem for error correction.
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

--library WORK;
use WORK.system_constants.all;

entity rm_encoder is
    generic (
        ENCODING_MATRIX_0 : std_logic_vector(127 downto 0) := x"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        ENCODING_MATRIX_1 : std_logic_vector(127 downto 0) := x"cccccccccccccccccccccccccccccccc";
        ENCODING_MATRIX_2 : std_logic_vector(127 downto 0) := x"f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0";
        ENCODING_MATRIX_3 : std_logic_vector(127 downto 0) := x"ff00ff00ff00ff00ff00ff00ff00ff00";
        ENCODING_MATRIX_4 : std_logic_vector(127 downto 0) := x"ffff0000ffff0000ffff0000ffff0000";
        ENCODING_MATRIX_5 : std_logic_vector(127 downto 0) := x"00000000ffffffff00000000ffffffff";
        ENCODING_MATRIX_6 : std_logic_vector(127 downto 0) := x"0000000000000000ffffffffffffffff";
        ENCODING_MATRIX_7 : std_logic_vector(127 downto 0) := x"ffffffffffffffffffffffffffffffff"
    );
    port (
        clk      : in  std_logic;
        rst      : in  std_logic;
        start    : in  std_logic;                     -- not used in logic, kept for interface compatibility
        byte_in  : in  std_logic_vector(7 downto 0);
        cdw_out  : out std_logic_vector(127 downto 0);
        done     : out std_logic
    );
end entity rm_encoder;

architecture Behavioral of rm_encoder is

    -- Array of selected matrices (one per input bit)
    type matrix_array_t is array (0 to 7) of std_logic_vector(127 downto 0);
    signal en_matrix : matrix_array_t;

    -- Intermediate XOR of all selected matrices
    signal cdw_temp      : std_logic_vector(127 downto 0);

    -- Rearranged version before final reversal
    signal cdw_rearrange : std_logic_vector(127 downto 0);

    -- Final output
    signal cdw_final     : std_logic_vector(127 downto 0);

begin

    -- Select Encoding_Matrix record based on input byte bits
    process(byte_in)
    begin
        for i in 0 to 7 loop
            if byte_in(i) = '1' then
                case i is
                    when 0 => en_matrix(i) <= ENCODING_MATRIX_0;
                    when 1 => en_matrix(i) <= ENCODING_MATRIX_1;
                    when 2 => en_matrix(i) <= ENCODING_MATRIX_2;
                    when 3 => en_matrix(i) <= ENCODING_MATRIX_3;
                    when 4 => en_matrix(i) <= ENCODING_MATRIX_4;
                    when 5 => en_matrix(i) <= ENCODING_MATRIX_5;
                    when 6 => en_matrix(i) <= ENCODING_MATRIX_6;
                    when 7 => en_matrix(i) <= ENCODING_MATRIX_7;
                    when others => en_matrix(i) <= (others => '0');
                end case;
            else
                en_matrix(i) <= (others => '0');
            end if;
        end loop;
    end process;

    -- XOR all selected matrices
    cdw_temp <= en_matrix(0) xor en_matrix(1) xor
                en_matrix(2) xor en_matrix(3) xor
                en_matrix(4) xor en_matrix(5) xor
                en_matrix(6) xor en_matrix(7);

    -- The encoder computes the correct bit pattern mathematically, but the positions of those bits 
    -- inside the 128-bit codeword must be re-ordered to match the exact mathematical definition of the RM(1,7) code used in HQC.
    -- Original: {13,14,15,16, 9,10,11,12, 5,6,7,8, 1,2,3,4} * 8-bit slices
    -- Actually, bytes are 0 to 15, where byte 0 = bits [7:0], byte 15 = [127:120]
    -- So byte N = cdw_temp(8*N + 7 downto 8*N)
    cdw_rearrange <=
        cdw_temp(8*12 + 7 downto 8*12) & -- byte 12
        cdw_temp(8*13 + 7 downto 8*13) &
        cdw_temp(8*14 + 7 downto 8*14) &
        cdw_temp(8*15 + 7 downto 8*15) & -- byte 15 
        cdw_temp(8*8 + 7 downto 8*8) &	 -- byte 08
        cdw_temp(8*9 + 7 downto 8*9) &
        cdw_temp(8*10 + 7 downto 8*10) &
        cdw_temp(8*11 + 7 downto 8*11) & -- byte 11
        cdw_temp(8*4 + 7 downto 8*4) &   -- byte 04
        cdw_temp(8*5 + 7 downto 8*5) &
        cdw_temp(8*6 + 7 downto 8*6) &
        cdw_temp(8*7 + 7 downto 8*7) &   -- byte 07
        cdw_temp(8*0 + 7 downto 8*0) &   -- byte 0
        cdw_temp(8*1 + 7 downto 8*1) &   
        cdw_temp(8*2 + 7 downto 8*2) &
        cdw_temp(8*3 + 7 downto 8*3);    -- byte 03

    -- Final step: reverse byte order (MSB to LSB)
    -- Verilog generate loop: cdw_out[8*k-1:8*k-8] = cdw_out_rearrange[127 - (8*k-8) : 120 - (8*k-8)]
    -- This effectively reverses the 16 bytes so that byte 0 becomes byte 15, byte 1 becomes byte 14, etc.
    -- Final order: {15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0}
    gen_reverse_bytes: for k in 1 to 16 generate
        cdw_final(8*k - 1 downto 8*k - 8) <= cdw_rearrange(127 - (8*(k-1)) downto 120 - (8*(k-1)));
    end generate;

    -- Output and done signal (one cycle after input valid)
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                cdw_out <= (others => '0');
                done    <= '0';
            else
                cdw_out <= cdw_final;
                done    <= '1';  -- always done in next cycle; adjust if start-based handshake needed
            end if;
        end if;
    end process;

-- Purely combinatorial output
--cdw_out <= cdw_final;

end Behavioral;




