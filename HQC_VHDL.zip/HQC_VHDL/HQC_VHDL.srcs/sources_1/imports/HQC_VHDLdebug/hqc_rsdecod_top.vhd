--/*Main components and data flow:

--hqc_rsdecod_syndromes: Computes syndrome polynomial from received codeword

--Input: Received codeword bytes
--Output: 2�DELTA syndrome values + message portion


--hqc_rsdecod_elp: Berlekamp-Massey algorithm for Error Locator Polynomial

--Input: Syndromes
--Output: Sigma polynomial (ELP) and its degree


--hqc_rsdecod_zpoly: Computes Z-polynomial (Error Evaluator Polynomial)

--Input: First DELTA syndromes + sigma polynomial
--Output: Z polynomial for Forney algorithm


--hqc_rsdecod_roots: FFT-based Chien search for error locations

--Input: Sigma polynomial
--Output: Error location pattern (N1 bytes)


--hqc_rsdecod_err_val: Forney algorithm for error values

--Input: Error locations + Z polynomial
--Output: Error values for K message bytes



--Key features:

--Parallel execution: Z-polynomial and root finding run concurrently after sigma is computed
--Pipeline stages: Multiple modules operate in sequence with handshaking
--Error correction: Final XOR of original message with computed error values
--Status signals:

--busy_o: Active during entire decoding process
--last_busy_o: Pulses one clock before completion
--done_o: Indicates corrected message is ready



--Complete RS decoding pipeline:
--Input ? Syndromes ? ELP (?) ? Z-poly + Roots ? Error Values ? Corrected Output
--                      ?           ?
--                    Parallel execution
--This implements a complete Reed-Solomon decoder for the HQC post-quantum cryptosystem, supporting 128-bit, 192-bit, and 256-bit security levels.
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity hqc_rsdecod_top is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET;
        DIN_W          : integer := 8
    );
    port (
        clk_i        : in  std_logic;
        rst_ni       : in  std_logic;
        start_i      : in  std_logic;
        busy_o       : out std_logic;
        last_busy_o  : out std_logic;  -- 1 clock before NOT busy
        done_o       : out std_logic;
        -- Input data
        din_i        : in  std_logic_vector(DIN_W-1 downto 0);
        din_valid_i  : in  std_logic;
        din_done_i   : in  std_logic;
        -- Output data (msg = {m[K-1],m[K-2],...,m[1],m[0]} with m[i] in byte)
        dout_o       : out std_logic_vector--(DOUT_W-1 downto 0)
    );
end hqc_rsdecod_top;

architecture rtl of hqc_rsdecod_top is
    
    -- Parameter calculations
    constant HQC_PARAMS : hqc_params_t := get_hqc_params(PARAM_SET);
    constant PARAM_DELTA : integer := HQC_PARAMS.delta;
    constant PARAM_G     : integer := HQC_PARAMS.G;
    constant PARAM_K     : integer := HQC_PARAMS.k1;
    constant PARAM_N1    : integer := HQC_PARAMS.n1;
    constant DOUT_W      : integer := 8 * PARAM_K;
    
    -- Internal signals
    signal syndromes      : std_logic_vector(8*2*PARAM_DELTA-1 downto 0);
    signal syn_valid      : std_logic;
    signal msg_temp       : std_logic_vector(DOUT_W-1 downto 0);
    signal corrected_msg  : std_logic_vector(DOUT_W-1 downto 0);
    signal sigma          : std_logic_vector(8*(PARAM_DELTA+1)-1 downto 0);
    signal sigma_valid    : std_logic;
    signal elp_busy       : std_logic;
    signal deg_sigma      : std_logic_vector(7 downto 0);
    signal z              : std_logic_vector(8*(PARAM_DELTA+1)-1 downto 0);
    signal z_valid        : std_logic;
    signal zpoly_busy     : std_logic;
    signal rs_error       : std_logic_vector(8*PARAM_N1-1 downto 0);
    signal root_busy      : std_logic;
    signal root_valid     : std_logic;
    signal err_val        : std_logic_vector(DOUT_W-1 downto 0);
    signal err_busy       : std_logic;
    signal err_val_valid  : std_logic;
    signal busy           : std_logic;
    signal done           : std_logic;
    signal rst_err_val    : std_logic;
    
    -- Component declarations
    component hqc_rsdecod_syndromes is
        generic (
            PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
        );
        port (
            clk_i        : in  std_logic;
            rst_ni       : in  std_logic;
            start_i      : in  std_logic;
            din_i        : in  std_logic_vector(7 downto 0);
            din_valid_i  : in  std_logic;
            din_done_i   : in  std_logic;
            dout_o       : out std_logic_vector(8*2*PARAM_DELTA-1 downto 0);
            dout_valid_o : out std_logic;
            msg_o        : out std_logic_vector(8*PARAM_K-1 downto 0)
        );
    end component;
    
    component hqc_rsdecod_elp is
        generic (
            PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
        );
        port (
            clk_i        : in  std_logic;
            rst_ni       : in  std_logic;
            din_i        : in  std_logic_vector(8*2*PARAM_DELTA-1 downto 0);
            din_valid_i  : in  std_logic;
            busy_o       : out std_logic;
            dout_o       : out std_logic_vector(8*(PARAM_DELTA+1)-1 downto 0);
            dout_valid_o : out std_logic;
            deg_sigma_o  : out std_logic_vector(7 downto 0)
        );
    end component;
    
    component hqc_rsdecod_zpoly is
        generic (
            PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
        );
        port (
            clk_i        : in  std_logic;
            rst_ni       : in  std_logic;
            synd_i       : in  std_logic_vector(8*PARAM_DELTA-1 downto 0);
            sigma_i      : in  std_logic_vector(8*(PARAM_DELTA+1)-1 downto 0);
            start_i      : in  std_logic;
            deg_sigma_i  : in  std_logic_vector(7 downto 0);
            busy_o       : out std_logic;
            dout_o       : out std_logic_vector(8*(PARAM_DELTA+1)-1 downto 0);
            dout_valid_o : out std_logic
        );
    end component;
    
    component hqc_rsdecod_roots is
        generic (
            PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
        );
        port (
            clk_i        : in  std_logic;
            rst_ni       : in  std_logic;
            sigma_i      : in  std_logic_vector(8*(PARAM_DELTA+1)-1 downto 0);
            start_i      : in  std_logic;
            busy_o       : out std_logic;
            error_o      : out std_logic_vector(8*PARAM_N1-1 downto 0);
            dout_valid_o : out std_logic
        );
    end component;
    
    component hqc_rsdecod_err_val is
        generic (
            PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
        );
        port (
            clk_i        : in  std_logic;
            rst_ni       : in  std_logic;
            error_i      : in  std_logic_vector(8*PARAM_N1-1 downto 0);
            z_i          : in  std_logic_vector(8*(PARAM_DELTA+1)-1 downto 0);
            start_i      : in  std_logic;
            busy_o       : out std_logic;
            error_o      : out std_logic_vector(8*PARAM_K-1 downto 0);
            dout_valid_o : out std_logic
        );
    end component;

begin

    -- Compute Syndromes
    COMPUTE_SYNDROMES : hqc_rsdecod_syndromes
        generic map (
            PARAM_SET => PARAM_SET
        )
        port map (
            clk_i        => clk_i,
            rst_ni       => rst_ni,
            start_i      => start_i,
            din_i        => din_i,
            din_valid_i  => din_valid_i,
            din_done_i   => din_done_i,
            dout_o       => syndromes,
            dout_valid_o => syn_valid,
            msg_o        => msg_temp
        );
    
    -- Compute Error Locator Polynomial (Berlekamp-Massey)
    COMPUTE_ELP : hqc_rsdecod_elp
        generic map (
            PARAM_SET => PARAM_SET
        )
        port map (
            clk_i        => clk_i,
            rst_ni       => rst_ni,
            din_i        => syndromes,
            din_valid_i  => syn_valid,
            busy_o       => elp_busy,
            dout_o       => sigma,
            dout_valid_o => sigma_valid,
            deg_sigma_o  => deg_sigma
        );
    
    -- Compute Z-Polynomial (Error Evaluator)
    COMPUTE_ZPOLY : hqc_rsdecod_zpoly
        generic map (
            PARAM_SET => PARAM_SET
        )
        port map (
            clk_i        => clk_i,
            rst_ni       => rst_ni,
            synd_i       => syndromes(8*PARAM_DELTA-1 downto 0),  -- first PARAM_DELTA syndromes
            sigma_i      => sigma,
            deg_sigma_i  => deg_sigma,
            start_i      => sigma_valid,
            busy_o       => zpoly_busy,
            dout_o       => z,
            dout_valid_o => z_valid
        );
    
    -- Compute Error Locations (Chien Search via FFT)
    COMPUTE_ROOTS : hqc_rsdecod_roots
        generic map (
            PARAM_SET => PARAM_SET
        )
        port map (
            clk_i        => clk_i,
            rst_ni       => rst_ni,
            sigma_i      => sigma,
            start_i      => sigma_valid,
            busy_o       => root_busy,
            error_o      => rs_error,
            dout_valid_o => root_valid
        );
    
    -- Compute Error Values (Forney Algorithm)
    rst_err_val <= rst_ni and (not start_i);
    
    COMPUTE_ERRVALS : hqc_rsdecod_err_val
        generic map (
            PARAM_SET => PARAM_SET
        )
        port map (
            clk_i        => clk_i,
            rst_ni       => rst_err_val,
            error_i      => rs_error,
            z_i          => z,
            start_i      => root_valid,
            busy_o       => err_busy,
            error_o      => err_val,
            dout_valid_o => err_val_valid
        );
    
    -- Busy and done control
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or err_val_valid = '1' then
                busy <= '0';
            elsif start_i = '1' then
                busy <= '1';
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            done <= err_val_valid;
        end if;
    end process;
    
    -- Correct message by XORing with error values
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if err_val_valid = '1' then
                corrected_msg <= std_logic_vector(unsigned(msg_temp) xor unsigned(err_val));
            end if;
        end if;
    end process;
    
    -- Output assignments
    last_busy_o <= err_val_valid;
    busy_o      <= busy;
    done_o      <= done;
    dout_o      <= corrected_msg;

end rtl;
