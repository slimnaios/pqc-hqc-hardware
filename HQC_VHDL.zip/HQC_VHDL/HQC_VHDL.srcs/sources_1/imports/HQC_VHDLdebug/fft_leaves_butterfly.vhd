--/*Main conversions:
--1. Always Blocks to Processes
--All always @(posedge clk_i) blocks converted to process(clk_i) with rising_edge(clk_i).
--2. Reset Logic
--Changed from ~rst_ni to rst_ni = '0' for active-low reset.
--3. Counter Type
--reg [3:0] cnt ? signal cnt : unsigned(3 downto 0)
--4. Bit Vector Extraction
---- Verilog: assign {t0, t01, t012, t0123} = tmp;
---- VHDL:
--t0    <= tmp(31 downto 24);
--t01   <= tmp(23 downto 16);
--t012  <= tmp(15 downto 8);
--t0123 <= tmp(7 downto 0);
--5. Conditional Assignments
--Verilog ternary operators converted to VHDL when-else chains:
--tmp_out <= t0123 when cnt = 7 else
--           t012  when cnt = 3 or cnt = 11 else
--           t01   when cnt = 1 or cnt = 5 or cnt = 9 or cnt = 13 else
--           t0;
--6. Concatenation and Shift
---- Verilog: tmp <= {tmp[23:0], gf_out^tmp[7:0]};
---- VHDL:
--tmp <= tmp(23 downto 0) & (gf_out xor tmp(7 downto 0));
--7. Hex Constants
--8'h08 ? x"08" in VHDL
--8. Multiple Condition Checks
---- Handles multiple OR conditions properly
--if rst_ni = '0' or start_i = '1' or 
--   (init_state = '1' and cnt = 3) or 
--   (compute_state = '1' and cnt = 15) then
--    ...

--The module computes butterfly operations on pairs of coefficients (a0, a1) using pre-multiplied 
--twiddle factors specific to the "leaves" (final stage) of the FFT tree.:
--Init state (4 cycles): Computes 4 GF multiplications of a1_i with constants {0x08, 0x54, 0x9d, 0x4e} and accumulates XORs
--Compute state (16 cycles): XORs accumulated values with a0_i at specific counter positions to 
--produce final butterfly outputs

--The butterfly operation computes:
--For i = 0 to 15:
--    output[i] = a0 ? (twiddle_factor[i] � a1)
--Where twiddle factors are specific GF constants based on position i.

--{0x08, 0x54, 0x9d, 0x4e}:
--- These are specific **twiddle factors** for the FFT leaf level
--- Chosen based on FFT algorithm requirements for GF(2^8)
--- Represent powers of the primitive element or specific combinations

--### **4. State Machine**
--```
--       start_i
--          ?
--    ???????????????
--    ? INIT_STATE  ?  (4 cycles, cnt=0-3)
--    ?  busy='1'   ?  Compute t0, t01, t012, t0123
--    ???????????????
--           ? cnt=3
--           ?
--  ???????????????????
--  ? COMPUTE_STATE   ?  (16 cycles, cnt=0-15)
--  ?   busy='1'      ?  Generate 16 outputs
--  ? dout_valid='1'  ?
--  ???????????????????
--           ? cnt=15
--           ?
--        IDLE
--      busy='0'

--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity fft_leaves_butterfly is
    generic (
        DIN_W  : integer := 8;
        DOUT_W : integer := 8
    );
    port (
        clk_i        : in  std_logic;
        rst_ni       : in  std_logic;
        start_i      : in  std_logic;
        busy_o       : out std_logic;
        -- Input/output data
        a0_i         : in  std_logic_vector(DIN_W-1 downto 0);
        a1_i         : in  std_logic_vector(DIN_W-1 downto 0);
        dout_o       : out std_logic_vector(DOUT_W-1 downto 0);
        dout_valid_o : out std_logic
    );
end fft_leaves_butterfly;

architecture rtl of fft_leaves_butterfly is

    -- Internal signals
    signal dout          : std_logic_vector(7 downto 0);
    signal dout_prev     : std_logic_vector(7 downto 0);
    signal tmp           : std_logic_vector(4*8-1 downto 0);
    signal t0            : std_logic_vector(7 downto 0);
    signal t01           : std_logic_vector(7 downto 0);
    signal t012          : std_logic_vector(7 downto 0);
    signal t0123         : std_logic_vector(7 downto 0);
    signal tmp_out       : std_logic_vector(7 downto 0);
    signal gf_in         : std_logic_vector(7 downto 0);
    signal gf_out        : std_logic_vector(7 downto 0);
    signal cnt           : unsigned(3 downto 0);
    signal init_state    : std_logic;
    signal compute_state : std_logic;
    signal busy          : std_logic;
    signal dout_valid    : std_logic;
    
    -- Component declaration
    component gf_mul is
        generic (
            REG_IN  : integer := 0;
            REG_OUT : integer := 0
        );
        port (
            clk    : in  std_logic;
            start  : in  std_logic;
            in_1   : in  std_logic_vector(7 downto 0);
            in_2   : in  std_logic_vector(7 downto 0);
            output : out std_logic_vector(7 downto 0);
            done   : out std_logic
        );
    end component;

begin

    -- t0 = gfmul(0x08, a1), t1 = gfmul(0x54, a1), 
    -- t2 = gfmul(0x9d, a1), t3 = gfmul(0x4e, a1)
    -- after init state: tmp = {t0, t0^t1, t0^t1^t2, t0^t1^t2^t3}
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if start_i = '1' then
                tmp <= (others => '0');
            elsif init_state = '1' then
                tmp <= tmp(23 downto 0) & (gf_out xor tmp(7 downto 0));
            end if;
        end if;
    end process;
    
    t0    <= tmp(31 downto 24);
    t01   <= tmp(23 downto 16);
    t012  <= tmp(15 downto 8);
    t0123 <= tmp(7 downto 0);
    
    tmp_out <= t0123 when cnt = 7 else
               t012  when cnt = 3 or cnt = 11 else
               t01   when cnt = 1 or cnt = 5 or cnt = 9 or cnt = 13 else
               t0;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if start_i = '1' or init_state = '1' then
                dout <= a0_i;                       -- Initialize with a0
            elsif compute_state = '1' and cnt /= 15 then
                dout <= dout xor tmp_out;           -- Accumulate XORs 
            end if;
        end if;
    end process;
    
    dout_o <= dout;
    
    -- Calculate dd
    -- dd = gf_mul(d,inv_dp)
    DD_MUL : gf_mul
        generic map (
            REG_IN  => 0,
            REG_OUT => 0
        )
        port map (
            clk    => clk_i,
            start  => '1',
            in_1   => a1_i,
            in_2   => gf_in,
            output => gf_out,
            done   => open
        );
    
    gf_in <= x"08" when cnt = 0 else
             x"54" when cnt = 1 else
             x"9d" when cnt = 2 else
             x"4e";
    
    ------------------------------------------------------------------------------
    -- Controller
    ------------------------------------------------------------------------------
    
    -- Busy flag
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                busy <= '0';
            elsif start_i = '1' then
                busy <= '1';
            elsif compute_state = '1' and cnt = 15 then
                busy <= '0';
            end if;
        end if;
    end process;
    
    busy_o <= busy;
    
    -- Counter
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or 
               (init_state = '1' and cnt = 3) or 
               (compute_state = '1' and cnt = 15) then
                cnt <= (others => '0');
            elsif busy = '1' then
                cnt <= cnt + 1;
            end if;
        end if;
    end process;
    
    -- Init state
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                init_state <= '0';
            elsif start_i = '1' then
                init_state <= '1';
            elsif init_state = '1' and cnt = 3 then
                init_state <= '0';
            end if;
        end if;
    end process;
    
    -- Compute state
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' then
                compute_state <= '0';
            elsif init_state = '1' and cnt = 3 then
                compute_state <= '1';
            elsif compute_state = '1' and cnt = 15 then
                compute_state <= '0';
            end if;
        end if;
    end process;
    
    dout_valid_o <= compute_state;

end rtl;

--/*
--## Complete Operation Timeline
--```
--Cycle 0: start_i='1'
--  ??> init_state='1', cnt=0
--  ??> dout = a0
--  ??> GF: a1 � 0x08

--Cycle 1: init_state='1', cnt=1
--  ??> tmp = [0, 0, 0, a1�0x08]
--  ??> GF: a1 � 0x54

--Cycle 2: init_state='1', cnt=2
--  ??> tmp = [0, 0, a1�0x08, (a1�0x08)?(a1�0x54)]
--  ??> GF: a1 � 0x9d

--Cycle 3: init_state='1', cnt=3
--  ??> tmp = [0, a1�0x08, t01, t012]
--  ??> GF: a1 � 0x4e
--  ??> Transition to compute_state

--Cycle 4: compute_state='1', cnt=0, dout_valid='1'
--  ??> tmp = [t0, t01, t012, t0123] (complete)
--  ??> tmp_out = t0
--  ??> dout = a0 ? t0 ? First output

--Cycle 5: compute_state='1', cnt=1
--  ??> tmp_out = t01
--  ??> dout = a0 ? t0 ? t01 ? Second output

--Cycle 6: compute_state='1', cnt=2
--  ??> tmp_out = t0
--  ??> dout = a0 ? t01 ? Third output

--...continues for 16 total outputs...

--Cycle 19: compute_state='1', cnt=15
--  ??> No XOR (cnt=15 excluded)
--  ??> dout unchanged (final output)
--  ??> busy='0', compute_state='0'
--```

--## Why This Design?

--### **Precomputation Efficiency**:
--Instead of computing 16 different GF multiplications, compute 4 base values and reuse them. This saves:
--- **Hardware**: Only 1 GF multiplier needed
--- **Time**: 4 cycles to precompute vs 16 cycles if done individually

--### **XOR Accumulation Pattern**:
--The selection pattern creates all 16 needed twiddle-factor combinations through clever reuse:
--```
--Different subsets of {t0, t01, t012, t0123} XORed together
--create the 16 required butterfly coefficients
--```

--### **Streaming Output**:
--Produces one output per cycle during compute state - efficient for pipelined FFT.

--### **State-Based Control**:
--Clear separation between precomputation and output phases simplifies control logic.

--## Mathematical Insight

--In FFT butterfly operations over GF, we need:
--```
--output[i] = a0 ? (?^i � a1)  for various i

--Instead of computing ?^i for each i, this module:

--Computes 4 base multiplications
--Combines them in patterns that equal the needed ?^i values
--XORs with a0 to get final results

--The magic constants {0x08, 0x54, 0x9d, 0x4e} and the selection pattern are carefully chosen so the combinations produce exactly the 16 twiddle factors needed for the FFT leaf butterflies.
--*/