--/*Main conversions:
--FFT-based root finding: Finds error locations by evaluating the error locator polynomial ?(x) 
--at all field elements using additive FFT.
--Implements Chien search using FFT to locate errors in Reed-Solomon decoding for HQC.
--Error locator polynomial ?(x) roots - the values where ?(?^i) = 0 need to be found. 
--These roots reveal the error positions in the received codeword.
--Traditional Chien search evaluates ?(x) at every field element iteratively. 
--This module uses FFT (Fast Fourier Transform) to evaluate ?(x) at all 256 field elements simultaneously, 
--making it much faster.

--????????????????
--   sigma_i ?????????? Zero Padding ?
--   (DELTA+1 bytes)   ????????????????
--                            ? 32 bytes (256 bits)
--                            ?
--                    ????????????????
--                    ?   ADD_FFT    ?  ? Evaluates ? at all 256 points
--                    ????????????????
--                           ? Write results
--                           ?
--                    ????????????????
--                    ?  Shared RAM  ?  ? 256-byte buffer
--                    ?  (256 � 8)   ?
--                    ????????????????
--                           ? Read with permutation
--                           ?
--                    ????????????????
--                    ? FFT_RETRIEVE ?  ? Extracts error pattern
--                    ????????????????
--                           ?
--                           ?
--                      error_o (N1 bytes)

--Component instantiation: 
--Two main components:
--add_fft: Performs additive FFT on sigma polynomial
--fft_retrieve_error_poly: Extracts error pattern from FFT results

--Shared RAM: 256-byte RAM buffer stores FFT output and provides input to retrieval module

--Write mode: FFT writes results
--Read mode: Retrieval module reads with permuted addressing
--Zero-padding: Sigma polynomial (DELTA+1 bytes) is padded to 256 bits (32 bytes) for FFT input

--Key implementation details:

--RAM multiplexing: ram_addr switches between write address (from FFT) and read address (from retrieval) based on ret_busy flag
--Single-port RAM: Implemented as synchronous RAM with one clock cycle read latency
--Reset control: Retrieval module gets rst_ni AND NOT start_i to reset when parent module starts
--Sequential operation: FFT completes first, then fft_done triggers retrieval module
--Busy signal: Combined OR of FFT and retrieval busy signals

--Algorithm overview:
--Implements Chien search using FFT:
--Input: Error locator polynomial sigma(x) with degree ? DELTA
--FFT: Evaluates sigma at all 256 field elements (powers of primitive element)
--Retrieval: Maps FFT results to error positions using permuted indexing
--Output: Error polynomial indicating which positions have errors

--## Operational Timeline
--```
--Cycle 0: start_i = '1'
--  ?? FFT starts processing sigma_i
--  ?? Retrieval module resets
  
--Cycles 1-N: FFT Processing
--  ?? Evaluating ? at all 256 points
--  ?? Writing results to RAM
--  ?? ram_wr toggles, addresses increment
  
--Cycle N: fft_done = '1'
--  ?? FFT completes
--  ?? RAM contains [?(0), ?(?), ?(?�), ..., ?(?^255)]
--  ?? Triggers retrieval module
  
--Cycles N+1 to M: Retrieval Processing
--  ?? ret_busy = '1'
--  ?? RAM switches to read mode
--  ?? Reads FFT results with permuted addressing
--  ?? Identifies zeros (error positions)
--  ?? Builds error pattern
  
--Cycle M: dout_valid_o = '1'
--  ?? error_o contains complete error pattern
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity hqc_rsdecod_roots is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i        : in  std_logic;
        rst_ni       : in  std_logic;
        sigma_i      : in  std_logic_vector;--(SIG_W-1 downto 0);
        start_i      : in  std_logic;
        busy_o       : out std_logic;
        error_o      : out std_logic_vector;--(ERR_W-1 downto 0);
        dout_valid_o : out std_logic
    );
end hqc_rsdecod_roots;

architecture rtl of hqc_rsdecod_roots is
   
    constant HQC_PARAMS  : hqc_params_t := get_hqc_params(PARAM_SET);
    constant PARAM_DELTA : integer := HQC_PARAMS.delta;
    constant PARAM_G     : integer := HQC_PARAMS.G;
    constant PARAM_K     : integer := HQC_PARAMS.k1;
    constant PARAM_N1    : integer := HQC_PARAMS.n1;
    constant ERR_W       : integer := 8 * PARAM_N1;
    constant SIG_W       : integer := 8 * (PARAM_DELTA + 1);
    
    -- RAM type
    type ram_t is array (0 to 255) of std_logic_vector(7 downto 0);
    signal mem : ram_t := (others => (others => '0'));
    
    -- Internal signals
    signal fft_start_out : std_logic;
    signal fft_busy      : std_logic;
    signal fft_done      : std_logic;
    signal fft_din       : std_logic_vector(32*8-1 downto 0);
    signal ram_din       : std_logic_vector(7 downto 0);
    signal ram_wr        : std_logic;
    signal ram_wr_addr   : std_logic_vector(7 downto 0);
    signal ram_dout      : std_logic_vector(7 downto 0);
    signal ram_rd        : std_logic;
    signal ram_rd_addr   : std_logic_vector(7 downto 0);
    signal ram_addr      : std_logic_vector(7 downto 0);
    signal ret_busy      : std_logic;
    signal rst_retrieve  : std_logic;
    
    -- Component declarations
    component add_fft is
        generic (
            DIN_W : integer := 256;
            AW    : integer := 8;
            DW    : integer := 8
        );
        port (
            clk_i      : in  std_logic;
            rst_ni     : in  std_logic;
            start_i    : in  std_logic;
            start_o    : out std_logic;
            done_o     : out std_logic;
            din_i      : in  std_logic_vector(DIN_W-1 downto 0);
            ram_din_o  : out std_logic_vector(DW-1 downto 0);
            ram_addr_o : out std_logic_vector(AW-1 downto 0);
            ram_wr     : out std_logic
        );
    end component;
    
    component fft_retrieve_error_poly is
        generic (
            PARAM_SET      : hqc_params_set_t := DEFAULT_PARAM_SET;
            IN_AW          : integer := 8;
            IN_DW          : integer := 8
        );
        port (
            clk_i           : in  std_logic;
            rst_ni          : in  std_logic;
            start_i         : in  std_logic;
            busy_o          : out std_logic;
            ram_din_i       : in  std_logic_vector(IN_DW-1 downto 0);
            ram_din_rd_o    : out std_logic;
            ram_din_addr_o  : out std_logic_vector(IN_AW-1 downto 0);
            dout_o          : out std_logic_vector(ERR_W-1 downto 0);
            dout_valid_o    : out std_logic
        );
    end component;

begin

    -- FFT operates on 256-bit (32-byte) blocks for GF(2^8)
    -- Zero-pad sigma_i to 256 bits (32 bytes)
    fft_din(SIG_W-1 downto 0) <= sigma_i;
    fft_din(32*8-1 downto SIG_W) <= (others => '0');
    
    -- Additive FFT
    ADD_FFT_INST : add_fft
        generic map (
            DIN_W => 32*8,
            AW    => 8,
            DW    => 8
        )
        port map (
            clk_i      => clk_i,
            rst_ni     => rst_ni,
            start_i    => start_i,
            start_o    => fft_start_out,
            done_o     => fft_done,
            din_i      => fft_din,
            ram_din_o  => ram_din,
            ram_addr_o => ram_wr_addr,
            ram_wr     => ram_wr
        );
    
    -- RAM
    -- Write Mode (FFT active): Address from FFT, writes evaluation results
    -- Read Mode (Retrieval active): Address from retrieval module, reads with permutation
    ram_addr <= ram_rd_addr when ret_busy = '1' else ram_wr_addr;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if ram_wr = '1' then
                mem(to_integer(unsigned(ram_addr))) <= ram_din;
            end if;
            ram_dout <= mem(to_integer(unsigned(ram_addr)));
        end if;
    end process;
    
    -- Retrieve Error Polynomial 
    -- Converts FFT output to error location pattern
    -- FFT outputs are in **bit-reversed** or transformed order. 
    -- Retrieval module applies correct addressing to map FFT results back to actual codeword positions.
    rst_retrieve <= rst_ni and (not start_i);
    
    FFT_RETRIEVE_ERROR_INST : fft_retrieve_error_poly
        generic map (
            PARAM_SET => PARAM_SET,
            IN_AW          => 8,
            IN_DW          => 8
        )
        port map (
            clk_i           => clk_i,
            rst_ni          => rst_retrieve,
            start_i         => fft_done,
            busy_o          => ret_busy,
            ram_din_i       => ram_dout,
            ram_din_rd_o    => ram_rd,
            ram_din_addr_o  => ram_rd_addr,
            dout_o          => error_o,
            dout_valid_o    => dout_valid_o
        );
    
    busy_o <= fft_busy or ret_busy;

end rtl;
