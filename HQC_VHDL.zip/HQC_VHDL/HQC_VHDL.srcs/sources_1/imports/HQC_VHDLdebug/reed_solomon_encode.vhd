--/*Major conversions:

--Parameters to generics: Verilog parameters became VHDL generics and constants
--Conditional parameters: Used conditional expressions in constant declarations
--Always blocks to processes: Converted all always@(posedge clk) blocks to clocked processes
--Combinational logic: The always@(state, start) became a combinational process
--Generate statements: Converted Verilog generate blocks to VHDL generate statements
--State machine: Changed from integer-based states to enumerated state_type
--Data types: Changed reg to signal, used std_logic_vector and unsigned

--Important notes:

--The polynomial constants are stored using hexadecimal literals with the x"" notation
--I created a function get_G_x to return the appropriate polynomial based on the parameter set
--Component declarations are included for gf_mul and cdw_xor_tmp - you'll need to ensure these exist
--The state machine uses an enumerated type for better readability and synthesis
--All bit vector operations maintain the same logic as the original Verilog

--Reed-Solomon Encoding Overview
--Reed-Solomon codes work by:

--Taking a message of K bytes
--Computing parity bytes (N1-K bytes) using polynomial division
--Producing a codeword of N1 bytes = message || parity

--The encoding uses Galois Field arithmetic (GF(2^8)) where operations are XOR-based.
--What the bitwise operations do:
--XOR = polynomial addition/subtraction in GF(2^8)
--GF Multiply = polynomial coefficient multiplication in GF(2^8)
--Shifting = processes message byte-by-byte (like synthetic division)

--Initial logical view (cycle 0):  
--[m_{15} m_{14} ? m_1 m_0  0  0  ?  0 ]   ? exactly m(x)�x^{30}

--After first feedback + rotate:  
--[m_{14} m_{13} ? m_0  m_{15}  p'_{29} p'_{28} ? p'_0 ]  
--   ? message part rotated           ? parity already updated

--But because the feedback canceled the highest term, it's as if we already handled the x^{45} term.

--After 16 cycles:  
--[some rotated mess  p_{29} ? p_0 ]  
--? We discard the rotated message and just take original msg + final parity

--Data Flow:
--Input Message (K bytes) ? GF Multiplication ? Parity Bytes (N1-K bytes) ? Codeword (N1 bytes)

--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity reed_solomon_encode is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk     : in  std_logic;
        rst     : in  std_logic;
        start   : in  std_logic;
        msg_in  : in  std_logic_vector;--(K-1 downto 0);
        cdw_out : out std_logic_vector;--(N1-1 downto 0);
        done    : out std_logic
    );
end reed_solomon_encode;

architecture rtl of reed_solomon_encode is

constant HQC_PARAMS : hqc_params_t := get_hqc_params(PARAM_SET);
    
constant N1_BYTES : natural := HQC_PARAMS.n1;
constant N1       : natural := 8*N1_BYTES;
constant LOG_N1_BYTES : natural := clog2(N1_BYTES);
constant K_BYTES : natural := HQC_PARAMS.k1;
constant K       : natural := 8*K_BYTES;

-- Polynomial constants    
constant G_x_WIDTH : natural := HQC_PARAMS.G_x_WIDTH; -- in bits
constant G_x : std_logic_vector(G_x_WIDTH-1 downto 0) := get_G_x(PARAM_SET, G_x_WIDTH);
    
-- Internal signals
signal msg           : std_logic_vector(K-1 downto 0);
signal gate_value    : std_logic_vector(7 downto 0);
signal cdw_bytes     : std_logic_vector(N1-1 downto 0);--should be clarified
signal cdw_out_int   : std_logic_vector(N1-K-1 downto 0);
signal capture_cdw   : std_logic;
signal init_msg      : std_logic;
signal shift_msg     : std_logic;
signal done_gf_mul   : std_logic;
signal gf_mul_out    : std_logic_vector(G_x_WIDTH*8-1 downto 0);
    
-- State machine
type state_type is (s_wait_start, s_gf_mult, s_mult_done, s_update_count, s_done);
signal state : state_type := s_wait_start;
signal count_msg_bytes : unsigned(4 downto 0) := (others => '0');

begin

-- Output assignment
-- Concatenates original message with computed parity bytes = systematic RS codeword
cdw_out <= msg & cdw_bytes(N1-K-1 downto 0);

-- Gate value computation
--/* Takes the current message byte (MSB of msg)
--XORs it with the current parity byte (MSB of cdw_bytes)
--This implements the feedback term in polynomial division */
gate_value <= msg(K-1 downto K-8) xor cdw_bytes(N1-K-1 downto N1-K-8);

-- Message register process
--/* Message Shifting
--msg <= msg(K-8-1 downto 0) & msg(K-1 downto K-8);
--```
--- **Rotates** the message by 8 bits (1 byte)
--- Processes each message byte sequentially
--- Similar to shifting a dividend in long division

--### **Reed-Solomon Connection:**

--The algorithm implements **systematic encoding**:

--1. **Polynomial Representation:**
--   - Message: `m(x) = m[K-1]�x^(K-1) + ... + m[1]�x + m[0]`
--   - Generator: `g(x)` (stored in G_x constant)

--2. **Encoding Formula:**
--```
--   codeword(x) = m(x)�x^(N1-K) - remainder[m(x)�x^(N1-K) / g(x)] */
   
process(clk)
begin
    if rising_edge(clk) then
        if init_msg = '1' then
            msg <= msg_in;
        elsif shift_msg = '1' then
            msg <= msg(K-8-1 downto 0) & msg(K-1 downto K-8);
        end if;
    end if;
end process;

-- Codeword bytes register process
process(clk)
begin
    if rising_edge(clk) then
        if init_msg = '1' then
            cdw_bytes <= (others => '0');
        elsif capture_cdw = '1' then
            cdw_bytes <= (others => '0');
            cdw_bytes(N1-K-1 downto 0) <= cdw_out_int;
        end if;
    end if;
end process;

-- Generate GF multipliers
--/* Polynomial Division (via GF Multiplication)
--G_x is the generator polynomial (fixed for each security level)
--Each byte of G_x represents a coefficient in GF(256)
--Multiple parallel GF multipliers compute: gate_value � G_x[i] for each coefficient
--This is the core of polynomial division in Galois Field arithmetic */
gen_gf_mul: for i in G_x_WIDTH/8 downto 1 generate --could probably be HQC_PARAMS.G parameter
    gfmul_inst : gf_mul
        port map (
            clk    => clk,
            start  => '1',
            in_1   => gate_value,
            in_2   => G_x(8*i-1 downto 8*i-8),
            output => gf_mul_out(8*i-1 downto 8*i-8),
            done   => done_gf_mul
        );
end generate;

-- CDW XOR component
--/* Parity Update (XOR Operation)
-- This component **XORs** the multiplication results with existing parity bytes:
--```
--new_parity = old_parity XOR (gate_value � G_x)
--This is the accumulation step in polynomial remainder computation.*/
cdw_xor_inst : cdw_xor_tmp
    generic map (
        PARAM_SET => PARAM_SET
    )
    port map (
        cdw_in  => cdw_bytes,
        tmp_arr => gf_mul_out(N1-K-1 downto 0),
        cdw_out => cdw_out_int
    );

-- State machine process
process(clk)
begin
    if rising_edge(clk) then
        if rst = '1' then
            state <= s_wait_start;
            count_msg_bytes <= (others => '0');
            done <= '0';
        else
            case state is
                when s_wait_start =>
                    done <= '0';
                    if start = '1' then
                        count_msg_bytes <= (others => '0');
                        state <= s_gf_mult;
                    end if;
                
                when s_gf_mult =>
                    state <= s_mult_done;
                    done <= '0';
                
                when s_mult_done =>
                    state <= s_update_count;
                    done <= '0';
                
                when s_update_count =>
                    if count_msg_bytes = K_BYTES-1 then
                        state <= s_wait_start;
                        count_msg_bytes <= (others => '0');
                        done <= '1';
                    else
                        state <= s_gf_mult;
                        count_msg_bytes <= count_msg_bytes + 1;
                        done <= '0';
                    end if;
                
                when others =>
                    state <= s_wait_start;
            end case;
        end if;
    end if;
end process;

-- Control signal generation process
process(state, start)
begin
    -- Default values
    shift_msg <= '0';
    capture_cdw <= '0';
    init_msg <= '0';
    
    case state is
        when s_wait_start =>
            if start = '1' then
                init_msg <= '1';
            end if;
        
        when s_gf_mult =>
            null;
        
        when s_mult_done =>
            null;
        
        when s_update_count =>
            shift_msg <= '1';
            capture_cdw <= '1';
        
        when others =>
            null;
    end case;
end process;

end rtl;