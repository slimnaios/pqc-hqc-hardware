library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.math_real.all;
library WORK;
use work.system_constants.all;

--use ieee.math_real.log2;
--use ieee.math_real.ceil;

package HQC_parameters is

--------------------------------------------------------------------
-- HQC security levels
--------------------------------------------------------------------
type hqc_params_set_t is (
        HQC_128,
        HQC_192,
        HQC_256
    );

constant DEFAULT_PARAM_SET : hqc_params_set_t := HQC_128;

-- Shortened Reed-Solomon Code [n,k,dmin] , Systematic form of encoding is used where the rightmost(?) k elements 
-- of the codeword polynomial are the message
-- bits and the leftmost(?) n ? k bits are the parity-check bits
-- Duplicated first-order Reed-Muller Code RM(1,7) [128,8,64] by 3 or 5 times 

--------------------------------------------------------------------
-- HQC parameter record
--------------------------------------------------------------------
type hqc_params_t is record
        n           : natural;  -- Length of ambient space namely the smallest primitive prime greater than n1n2
        n1          : natural;  -- Block length of external Reed-Solomon Code (bytes)
        n2          : natural;  -- Block length of internal Reed-Muller Code (bytes)
        k1          : natural;  -- Dimension of RS code (message length in bytes)
        k2          : natural;  -- Dimension of RM code (message length in bytes)
        delta       : natural;
        G           : natural;  -- dmin of RS Code (also determines the degree of the error locator polynomial in the RS decoder)
        w           : natural;  -- weight of vectors x,y - not used
        we          : natural;  -- weight of vectors e
        wr          : natural;  -- weight of vectors r1,r2 - not used
        seed_bytes  : natural;  -- - not used
	    G_x_WIDTH   : natural;
	--G_x	    : std_logic_vector;
end record;



-- Functions --

function get_hqc_params(p : hqc_params_set_t) return hqc_params_t;

function get_G_x(p : hqc_params_set_t; width : positive) return std_logic_vector;

function get_MULTIPLICITY(p : hqc_params_set_t) return integer;

function get_IN_AW(p : hqc_params_set_t) return integer;

function get_OUT_AW(p : hqc_params_set_t) return integer;

function get_SUM_W(p : hqc_params_set_t) return integer;

function get_DIN_W(p : hqc_params_set_t) return integer;

function get_NWIDTH(p : hqc_params_set_t) return integer;

function get_EAS_W(p : hqc_params_set_t) return integer;

function get_ALPHA_AW(p : hqc_params_set_t) return natural;


--    constant G_x_WIDTH : integer :=
--        256 when parameter_set = "hqc128" else
--        264 when parameter_set = "hqc192" else
--        480 when parameter_set = "hqc256" else
--        256;
--

-- Component Declarations --

component cdw_xor_tmp is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        cdw_in  : in  std_logic_vector;
        tmp_arr : in  std_logic_vector;
        cdw_out : out std_logic_vector
    );
end component cdw_xor_tmp;

component reed_solomon_encode is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk     : in  std_logic;
        rst     : in  std_logic;
        start   : in  std_logic;
        msg_in  : in  std_logic_vector;
        cdw_out : out std_logic_vector;
        done    : out std_logic
    );
end component reed_solomon_encode;

component reed_muller_encode is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk          : in  std_logic;
        rst          : in  std_logic;
        start        : in  std_logic;
        rs_cdw_in    : in  std_logic_vector;
        cdw_out_addr : in  std_logic_vector;
        cdw_out_en   : in  std_logic;
        cdw_out      : out std_logic_vector(127 downto 0);
        done         : out std_logic
    );
end component reed_muller_encode;

component hqc_rmdecod_expnsum is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i          : in  std_logic;
        rst_ni         : in  std_logic;
        start_i        : in  std_logic;
        start_ready_o  : out std_logic;
        din_i          : in  std_logic_vector(127 downto 0);
        din_valid_i    : in  std_logic;
        din_ready_o    : out std_logic;
        dout_start_o   : out std_logic;
        dout0_o        : out std_logic_vector;--(NWIDTH-1 downto 0);
        dout1_o        : out std_logic_vector;--(NWIDTH-1 downto 0);
        dout_valid_o   : out std_logic;
        dout_ready_i   : in  std_logic
    );
end component hqc_rmdecod_expnsum;

component hqc_rmdecod_hadamard is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i         : in  std_logic;
        rst_ni        : in  std_logic;
        start_i       : in  std_logic;
        din0_i        : in  std_logic_vector;--(DIN_W-1 downto 0);
        din1_i        : in  std_logic_vector;--(DIN_W-1 downto 0);
        din_valid_i   : in  std_logic;
        dout_start_o  : out std_logic;
        dout0_o       : out std_logic_vector;--(DOUT_W-1 downto 0);
        dout1_o       : out std_logic_vector;--(DOUT_W-1 downto 0);
        dout_valid_o  : out std_logic
    );
end component hqc_rmdecod_hadamard;

component hqc_rmdecod_findpeaks is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i         : in  std_logic;
        rst_ni        : in  std_logic;
        start_i       : in  std_logic;
        din0_i        : in  std_logic_vector;--(DIN_W-1 downto 0);
        din1_i        : in  std_logic_vector;--(DIN_W-1 downto 0);
        din_valid_i   : in  std_logic;
        dout_o        : out std_logic_vector;--(DOUT_W-1 downto 0);
        dout_valid_o  : out std_logic
    );
end component hqc_rmdecod_findpeaks;

component hqc_rmdecod_ctrl is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i              : in  std_logic;
        rst_ni             : in  std_logic;
        start_i            : in  std_logic;
        busy_o             : out std_logic;
        done_o             : out std_logic;
        -- Input RAM
        ram_din_i          : in  std_logic_vector(127 downto 0);
        ram_din_rd_o       : out std_logic;
        ram_din_addr_o     : out std_logic_vector;--(IN_AW-1 downto 0);
        -- Expand and Sum
        eas_din_o          : out std_logic_vector(127 downto 0);
        eas_start_ready_i  : in  std_logic;
        eas_start_o        : out std_logic;
        eas_din_valid_o    : out std_logic;
        eas_din_ready_i    : in  std_logic;
        -- Find Peaks
        peak_valid_i       : in  std_logic;
        peak_dout_i        : in  std_logic_vector(7 downto 0);
        -- Output RAM
        ram_dout_wr_o      : out std_logic;
        ram_dout_o         : out std_logic_vector(7 downto 0);
        ram_dout_addr_o    : out std_logic_vector--(OUT_AW-1 downto 0)
    );
end component hqc_rmdecod_ctrl;

end HQC_parameters;

package body HQC_parameters is

function get_hqc_params(p : hqc_params_set_t) return hqc_params_t is
        variable r : hqc_params_t := (
        n          => 0,
        n1         => 0,
        n2         => 0,
        k1         => 0,
        k2         => 0,
        delta      => 0,
        G          => 0,
        w          => 0,
        we         => 0,
        wr         => 0,
        seed_bytes => 0,
        G_x_WIDTH  => 0
    );
    begin
        case p is

            ----------------------------------------------------------------
            -- HQC-128
            ----------------------------------------------------------------
            when HQC_128 =>
                r.n          := 17669;--
                r.n1         := 46;
                r.n2         := 16;
                r.k1         := 16;
                r.k2         := 8;
                r.delta      := 15;
                r.G          := 31;
                --r.k          := 46;
                r.w          := 66;--
                r.we         := 75;--
                r.wr         := 75;--
                r.seed_bytes := 40;
                
		        r.G_x_WIDTH  := 256;
		--r.G_x	     := x"0001B5FF52E4454A6EAED2697643AD678B15D241E9F2E9494B6F75B074994559"
       
            ----------------------------------------------------------------
            -- HQC-192
            ----------------------------------------------------------------
            when HQC_192 =>
                r.n          := 35851;--
                r.n1         := 56;
                r.n2         := 16;
                r.k1         := 24;
                r.k2         := 8;
                r.delta      := 16;
                r.G          := 33;
               --r.k          := 56;
                r.w          := 100;--
                r.we         := 114;--
                r.wr         := 114;--
                r.seed_bytes := 40;
                
		        r.G_x_WIDTH  := 264;
		--r.G_x	     := x"01E81DBD328EF6E80F2B52A4EE019E0D779EE086E3D2A3326B281B68FD18EFD82D"
                
            ----------------------------------------------------------------
            -- HQC-256
            ----------------------------------------------------------------
            when HQC_256 =>
                r.n          := 57637;--
                r.n1         := 90;
                r.n2         := 16;
                r.k1         := 32;
                r.k2         := 8;
                r.delta      := 29;
                r.G          := 59; 
                --r.k          := 90;
                r.w          := 131;--
                r.we         := 149;--
                r.wr         := 149;--
                r.seed_bytes := 40;
                
		        r.G_x_WIDTH  := 480;
		--r.G_x	     := x"0001bbc730d8bc272f7c4082b28d1b2fe80890bff6048d63ef98dbb4f31f0c7bd98db7bad26173c9479fd72065577b9647943ff05b7c79c82731a731"
                
        end case;

        return r;
    end function;

function get_G_x (p : hqc_params_set_t; width : positive) return std_logic_vector is
    variable tmp : std_logic_vector(width-1 downto 0);
begin
    tmp := (others => '0');  -- zero-pad default
    if p = HQC_128 then
        return x"0001B5FF52E4454A6EAED2697643AD678B15D241E9F2E9494B6F75B074994559";
    elsif p = HQC_192 then
        return x"01E81DBD328EF6E80F2B52A4EE019E0D779EE086E3D2A3326B281B68FD18EFD82D";
    elsif p = HQC_256 then
        return x"0001bbc730d8bc272f7c4082b28d1b2fe80890bff6048d63ef98dbb4f31f0c7bd98db7bad26173c9479fd72065577b9647943ff05b7c79c82731a731";
    else
        return x"0001B5FF52E4454A6EAED2697643AD678B15D241E9F2E9494B6F75B074994559";
    end if;
end function;

    function get_MULTIPLICITY(p : hqc_params_set_t) return integer is
    begin
        if p = HQC_128 then
            return 3;
        else
            return 5;
        end if;
    end function;

    function get_IN_AW(p : hqc_params_set_t) return integer is
    begin
        if p = HQC_128 then
            return 8;
        elsif p = HQC_192 then
            return 9;
        elsif p = HQC_256 then
            return 9;
        else
            return 8;
        end if;
    end function;
    
    function get_OUT_AW(p : hqc_params_set_t) return integer is
    begin
        if p = HQC_128 then
            return 6;
        elsif p = HQC_192 then
            return 6;
        elsif p = HQC_256 then
            return 7;
        else
            return 6;
        end if;
    end function;

    
    function get_SUM_W(p : hqc_params_set_t) return integer is
    begin
        if p = HQC_128 then
            return 2;
        else
            return 3;
        end if;
    end function;

    function get_DIN_W(p : hqc_params_set_t) return integer is
    begin
        if p = HQC_128 then
            return 2;
        else
            return 3;
        end if;
    end function;

    function get_NWIDTH(p : hqc_params_set_t) return integer is
    begin
        if p = HQC_128 then
            return 2;
        else
            return 3;
        end if;
    end function;

        
    function get_EAS_W(p : hqc_params_set_t) return integer is
    begin
        if p = HQC_128 then
            return 2;
        else
            return 3;
        end if;
    end function;

    function get_ALPHA_AW(p : hqc_params_set_t) return natural is
    begin
        if p = HQC_128 then
            return 6;
        elsif p = HQC_192 then
            return 6;
        elsif p = HQC_256 then
            return 7;
        else
            return 6;
        end if;
    end function;

end HQC_parameters;
