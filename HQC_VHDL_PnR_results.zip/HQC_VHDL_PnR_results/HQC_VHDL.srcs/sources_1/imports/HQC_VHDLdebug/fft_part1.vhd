--/*Main conversions:
--1. Permutation Function
--The Verilog function with 32 input parameters has been converted to a VHDL function that takes the same parameters and returns a std_logic_vector.

--2. Register Updates
--All Verilog always @(posedge clk_i) blocks converted to VHDL process(clk_i) with rising_edge(clk_i).

--3. Reset Logic
--Changed from ~rst_ni to rst_ni = '0' for active-low reset.

--4. Counter Types
--reg [1:0] round ? signal round : unsigned(1 downto 0)
--reg [3:0] cnt ? signal cnt : unsigned(3 downto 0)
--All counters use unsigned type

--5. Concatenation
--Verilog {a, b, c} ? VHDL a & b & c

--6. Bit Slicing
--Verilog buff[(32-4)*8 +: 4*8] ? VHDL buff((32-4)*8+31 downto (32-4)*8)
--VHDL uses explicit range notation

--7. Conditional Assignments
--Verilog ternary operators ? : converted to VHDL when-else statements or if-then-else in processes.

--8. Complex Buffer Logic
--The large always block for buff was converted to a single process with nested if-elsif structure matching the Verilog priority.

--9. Hex Constants
--The 224-bit constant bm_pow_R initialization uses VHDL hex string notation with x"...".

--10. Last Counter Logic
--Complex multi-condition logic converted to a single concurrent assignment with proper VHDL boolean expressions.
--The converted code maintains the same functionality and structure as the original Verilog implementation while following VHDL syntax and conventions.

--performs the first half of a 256-point additive FFT in GF(2^8). It takes a 32-byte polynomial as input and produces 
--intermediate results through multiple processing rounds using permutations and radix-4 operations.

--Input: 32-byte polynomial (??, ??, ..., ???)
--Output: 4-byte chunks produced sequentially (intermediate FFT results)

--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity fft_part1 is
    generic (
        DIN_W  : integer := 32*8;
        DOUT_W : integer := 4*8
    );
    port (
        clk_i        : in  std_logic;
        rst_ni       : in  std_logic;
        start_i      : in  std_logic;
        busy_o       : out std_logic;
        done_o       : out std_logic;
        -- Input/output data
        din_i        : in  std_logic_vector(DIN_W-1 downto 0);
        dout_read_i  : in  std_logic;
        dout_o       : out std_logic_vector(DOUT_W-1 downto 0);
        dout_valid_o : out std_logic
    );
end fft_part1;

architecture rtl of fft_part1 is

    -- Internal signals
    signal buff                : std_logic_vector(32*8-1 downto 0);
    signal next_buff_044       : std_logic_vector(32*8-1 downto 0);
    signal next_buff_111       : std_logic_vector(32*8-1 downto 0);
    signal next_buff_114       : std_logic_vector(32*8-1 downto 0);
    signal next_buff_144       : std_logic_vector(32*8-1 downto 0);
    signal next_buff_211       : std_logic_vector(32*8-1 downto 0);
    signal next_buff_214       : std_logic_vector(32*8-1 downto 0);
    signal next_buff_244       : std_logic_vector(32*8-1 downto 0);
    
    signal temp0, temp1, temp2, temp3 : std_logic_vector(32*8-1 downto 0);
    signal temp4, temp5, temp6        : std_logic_vector(32*8-1 downto 0);
    signal temp7, temp8               : std_logic_vector(32*8-1 downto 0);
    
    signal radix_a0, radix_a1, radix_a2, radix_a3 : std_logic_vector(7 downto 0);
    signal radix_b0, radix_b1, radix_b2, radix_b3 : std_logic_vector(7 downto 0);
    
    signal busy       : std_logic;
    signal round      : unsigned(1 downto 0);
    signal cnt        : unsigned(3 downto 0);
    signal k          : unsigned(1 downto 0);
    signal last_k     : unsigned(1 downto 0);
    signal round_en   : std_logic;
    signal last_round : std_logic;
    signal cnt_en     : std_logic;
    signal last_cnt   : std_logic;
    signal k_en       : std_logic;
    signal done       : std_logic;
    
    signal bm_pow_R   : std_logic_vector(223 downto 0);
    signal gf_in1     : std_logic_vector(7 downto 0);
    signal gf_in2     : std_logic_vector(7 downto 0);
    signal gf_out     : std_logic_vector(7 downto 0);
    signal gf_out_d1  : std_logic_vector(7 downto 0);
    signal gf_out_d2  : std_logic_vector(7 downto 0);
    signal gf_out_d3  : std_logic_vector(7 downto 0);
    
    -- Component declaration
    component gf_mul is
        generic (
            REG_IN  : integer := 0;
            REG_OUT : integer := 0
        );
        port (
            clk    : in  std_logic;
            start  : in  std_logic;
            in_1   : in  std_logic_vector(7 downto 0);
            in_2   : in  std_logic_vector(7 downto 0);
            output : out std_logic_vector(7 downto 0);
            done   : out std_logic
        );
    end component;
    
    -- Permutation function
    -- Reorders the 32 bytes according to a permutation pattern
    -- FFT algorithms require specific data reordering between stages (bit-reversal, decimation patterns). 
    -- Different permutations are used for different rounds.
    function perm(
        x : std_logic_vector(32*8-1 downto 0);
        n0, n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15 : integer;
        n16, n17, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30, n31 : integer
    ) return std_logic_vector is
        variable result : std_logic_vector(32*8-1 downto 0);
    begin
        result((32-0 -1)*8+7 downto (32-0 -1)*8) := x((32-n0 -1)*8+7 downto (32-n0 -1)*8);
        result((32-1 -1)*8+7 downto (32-1 -1)*8) := x((32-n1 -1)*8+7 downto (32-n1 -1)*8);
        result((32-2 -1)*8+7 downto (32-2 -1)*8) := x((32-n2 -1)*8+7 downto (32-n2 -1)*8);
        result((32-3 -1)*8+7 downto (32-3 -1)*8) := x((32-n3 -1)*8+7 downto (32-n3 -1)*8);
        result((32-4 -1)*8+7 downto (32-4 -1)*8) := x((32-n4 -1)*8+7 downto (32-n4 -1)*8);
        result((32-5 -1)*8+7 downto (32-5 -1)*8) := x((32-n5 -1)*8+7 downto (32-n5 -1)*8);
        result((32-6 -1)*8+7 downto (32-6 -1)*8) := x((32-n6 -1)*8+7 downto (32-n6 -1)*8);
        result((32-7 -1)*8+7 downto (32-7 -1)*8) := x((32-n7 -1)*8+7 downto (32-n7 -1)*8);
        result((32-8 -1)*8+7 downto (32-8 -1)*8) := x((32-n8 -1)*8+7 downto (32-n8 -1)*8);
        result((32-9 -1)*8+7 downto (32-9 -1)*8) := x((32-n9 -1)*8+7 downto (32-n9 -1)*8);
        result((32-10-1)*8+7 downto (32-10-1)*8) := x((32-n10-1)*8+7 downto (32-n10-1)*8);
        result((32-11-1)*8+7 downto (32-11-1)*8) := x((32-n11-1)*8+7 downto (32-n11-1)*8);
        result((32-12-1)*8+7 downto (32-12-1)*8) := x((32-n12-1)*8+7 downto (32-n12-1)*8);
        result((32-13-1)*8+7 downto (32-13-1)*8) := x((32-n13-1)*8+7 downto (32-n13-1)*8);
        result((32-14-1)*8+7 downto (32-14-1)*8) := x((32-n14-1)*8+7 downto (32-n14-1)*8);
        result((32-15-1)*8+7 downto (32-15-1)*8) := x((32-n15-1)*8+7 downto (32-n15-1)*8);
        result((32-16-1)*8+7 downto (32-16-1)*8) := x((32-n16-1)*8+7 downto (32-n16-1)*8);
        result((32-17-1)*8+7 downto (32-17-1)*8) := x((32-n17-1)*8+7 downto (32-n17-1)*8);
        result((32-18-1)*8+7 downto (32-18-1)*8) := x((32-n18-1)*8+7 downto (32-n18-1)*8);
        result((32-19-1)*8+7 downto (32-19-1)*8) := x((32-n19-1)*8+7 downto (32-n19-1)*8);
        result((32-20-1)*8+7 downto (32-20-1)*8) := x((32-n20-1)*8+7 downto (32-n20-1)*8);
        result((32-21-1)*8+7 downto (32-21-1)*8) := x((32-n21-1)*8+7 downto (32-n21-1)*8);
        result((32-22-1)*8+7 downto (32-22-1)*8) := x((32-n22-1)*8+7 downto (32-n22-1)*8);
        result((32-23-1)*8+7 downto (32-23-1)*8) := x((32-n23-1)*8+7 downto (32-n23-1)*8);
        result((32-24-1)*8+7 downto (32-24-1)*8) := x((32-n24-1)*8+7 downto (32-n24-1)*8);
        result((32-25-1)*8+7 downto (32-25-1)*8) := x((32-n25-1)*8+7 downto (32-n25-1)*8);
        result((32-26-1)*8+7 downto (32-26-1)*8) := x((32-n26-1)*8+7 downto (32-n26-1)*8);
        result((32-27-1)*8+7 downto (32-27-1)*8) := x((32-n27-1)*8+7 downto (32-n27-1)*8);
        result((32-28-1)*8+7 downto (32-28-1)*8) := x((32-n28-1)*8+7 downto (32-n28-1)*8);
        result((32-29-1)*8+7 downto (32-29-1)*8) := x((32-n29-1)*8+7 downto (32-n29-1)*8);
        result((32-30-1)*8+7 downto (32-30-1)*8) := x((32-n30-1)*8+7 downto (32-n30-1)*8);
        result((32-31-1)*8+7 downto (32-31-1)*8) := x((32-n31-1)*8+7 downto (32-n31-1)*8);
        return result;
    end function;

begin

    -- Radix calculation
    -- Radix4
    -- Input: A0, A1, A2, A3
    -- Output: B0 = A0
    --         B1 = A1^A2^A3
    --         B2 = A2^A3
    --         B3 = A3
    radix_a0 <= gf_out_d3 when (k = 0 and round /= 0) else buff((32-4)*8+31 downto (32-4)*8+24);
    radix_a1 <= gf_out_d2 when (k = 0 and round /= 0) else buff((32-4)*8+23 downto (32-4)*8+16);
    radix_a2 <= gf_out_d1 when (k = 0 and round /= 0) else buff((32-4)*8+15 downto (32-4)*8+8);
    radix_a3 <= gf_out when (k = 0 and round /= 0) else buff((32-4)*8+7 downto (32-4)*8+0);
    
    radix_b0 <= radix_a0;
    radix_b1 <= radix_a1 xor radix_a2 xor radix_a3;
    radix_b2 <= radix_a2 xor radix_a3;
    radix_b3 <= radix_a3;
    
    -- Buffer
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if start_i = '1' then
                buff <= perm(din_i, 0,8,16,24,1,9,17,25,2,10,18,26,3,11,19,27,4,12,20,28,5,13,21,29,6,14,22,30,7,15,23,31);
            elsif busy = '1' and round = 0 then
                if k = 0 and cnt = 7 then
                    buff <= perm(temp0, 0,4,8,12,16,20,24,28,1,5,9,13,17,21,25,29,2,6,10,14,18,22,26,30,3,7,11,15,19,23,27,31);
                elsif k = 1 and cnt = 7 then
                    buff <= perm(temp1, 0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31);
                elsif k = 2 and cnt = 7 then
                    buff <= perm(temp2, 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
                elsif k = 3 and cnt = 7 then
                    buff <= perm(temp3, 0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
                else
                    buff <= next_buff_044;
                end if;
            elsif busy = '1' and round = 1 then
                if k = 0 then
                    if cnt = 15 then
                        buff <= perm(temp4, 0,2,4,6,8,10,12,14,1,3,5,7,9,11,13,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
                    elsif cnt(1 downto 0) = "11" then
                        buff <= next_buff_114;
                    else
                        buff <= next_buff_111;
                    end if;
                elsif k = 1 and cnt = 3 then
                    buff <= perm(temp5, 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
                elsif k = 2 and cnt = 3 then
                    buff <= perm(temp6, 0,2,4,6,1,3,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
                else
                    buff <= next_buff_144;
                end if;
            elsif busy = '1' and round = 2 then
                if k = 0 then
                    if cnt = 7 then
                        buff <= perm(temp7, 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
                    elsif cnt(1 downto 0) = "11" then
                        buff <= next_buff_214;
                    else
                        buff <= next_buff_211;
                    end if;
                elsif k = 1 and cnt = 1 then
                    buff <= perm(temp8, 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
                else
                    buff <= next_buff_244;
                end if;
            elsif busy = '1' and round = 3 then
                buff <= radix_b0 & radix_b1 & radix_b2 & radix_b3 & buff(28*8-1 downto 0);
            elsif dout_read_i = '1' then
                buff <= buff(28*8-1 downto 0) & buff(32*8-1 downto 28*8);  -- Circular shift to expose next 4-byte output
            end if;
        end if;
    end process;
    
    dout_o <= buff((32-4)*8+31 downto (32-4)*8);
    
    -- Apply different permutations to intermediate results
    -- Used at specific transition points (when `cnt=7` in round 0, etc.) to reorganize data for next phase.
    -- round 0
    temp0 <= perm(next_buff_044, 0,4,8,12,16,20,24,28,1,5,9,13,17,21,25,29,2,6,10,14,18,22,26,30,3,7,11,15,19,23,27,31);
    temp1 <= perm(next_buff_044, 0,8,16,24,1,9,17,25,2,10,18,26,3,11,19,27,4,12,20,28,5,13,21,29,6,14,22,30,7,15,23,31);
    temp2 <= perm(next_buff_044, 0,16,1,17,2,18,3,19,4,20,5,21,6,22,7,23,8,24,9,25,10,26,11,27,12,28,13,29,14,30,15,31);
    temp3 <= perm(next_buff_044, 0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31);
    
    -- round 1
    temp4 <= perm(next_buff_114, 0,4,8,12,1,5,9,13,2,6,10,14,3,7,11,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
    temp5 <= perm(next_buff_144, 0,8,1,9,2,10,3,11,4,12,5,13,6,14,7,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
    temp6 <= perm(next_buff_144, 0,2,4,6,8,10,12,14,1,3,5,7,9,11,13,15,16,18,20,22,24,26,28,30,17,19,21,23,25,27,29,31);
    
    -- round 2
    temp7 <= perm(next_buff_214, 0,4,1,5,2,6,3,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31);
    temp8 <= perm(next_buff_244, 0,2,4,6,1,3,5,7,8,10,12,14,9,11,13,15,16,18,20,22,17,19,21,23,24,26,28,30,25,27,29,31);
    
    -- Precompute next buffer values by inserting radix outputs at specific positions
    next_buff_044 <= buff(28*8-1 downto 0) & radix_b0 & radix_b1 & radix_b2 & radix_b3;
    next_buff_144 <= buff(28*8-1 downto 16*8) & radix_b0 & radix_b1 & radix_b2 & radix_b3 & buff(16*8-1 downto 0);
    next_buff_114 <= buff(31*8-1 downto 19*8) & radix_b0 & radix_b1 & radix_b2 & radix_b3 & buff(16*8-1 downto 0);
    next_buff_111 <= buff(31*8-1 downto 16*8) & buff(32*8-1 downto 31*8) & buff(16*8-1 downto 0);
    next_buff_244 <= buff(28*8-1 downto 24*8) & radix_b0 & radix_b1 & radix_b2 & radix_b3 & buff(24*8-1 downto 0);
    next_buff_214 <= buff(31*8-1 downto 27*8) & radix_b0 & radix_b1 & radix_b2 & radix_b3 & buff(24*8-1 downto 0);
    next_buff_211 <= buff(31*8-1 downto 24*8) & buff(32*8-1 downto 31*8) & buff(24*8-1 downto 0);
    
    -- GF Mult
    -- Multiplies data by twiddle factors (precomputed constants in GF)
    GF_MUL_INST : gf_mul
        generic map (
            REG_IN  => 0,
            REG_OUT => 0
        )
        port map (
            clk    => clk_i,
            start  => '1',
            in_1   => gf_in1,
            in_2   => gf_in2,
            output => gf_out,
            done   => open
        );
    
    gf_in1 <= buff(32*8-1 downto 31*8);     -- Top byte of buff
    gf_in2 <= bm_pow_R(223 downto 216);     -- Twiddle factor
    
    process(clk_i)                          -- 3-stage delay pipeline
    begin
        if rising_edge(clk_i) then
            gf_out_d3 <= gf_out_d2;
            gf_out_d2 <= gf_out_d1;
            gf_out_d1 <= gf_out;
        end if;
    end process;
    
    -- Constants
    -- 224-bit constant (28 bytes)
    -- Rotates left by 8 bits each k=0 iteration
    -- Provides different scaling factors for FFT stages
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if start_i = '1' then
                bm_pow_R <= x"010d51ba062efbbb14e420bd7862c0a901195c2f12bf1194011f486b";
            elsif busy = '1' and k = 0 and round /= 0 then
                bm_pow_R <= bm_pow_R(215 downto 0) & bm_pow_R(223 downto 216);
            end if;
        end if;
    end process;
    
    ------------------------------------------------------------------------------
    -- Controller
    ------------------------------------------------------------------------------
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' then
                busy <= '0';
            elsif start_i = '1' then
                busy <= '1';
            elsif last_round = '1' then
                busy <= '0';
            end if;
        end if;
    end process;
    
    busy_o <= busy;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or last_round = '1' then
                round <= (others => '0');
            elsif round_en = '1' then
                round <= round + 1;
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or last_cnt = '1' or last_round = '1' then
                cnt <= (others => '0');
            elsif cnt_en = '1' then
                cnt <= cnt + 1;
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or round_en = '1' then
                k <= (others => '0');
            elsif k_en = '1' then
                k <= k + 1;
            end if;
        end if;
    end process;
    
    cnt_en <= busy;
    
    last_cnt <= '1' when (round = 0 and cnt = 7) or
                         (round = 1 and ((k = 0 and cnt = 15) or (k /= 0 and cnt = 3))) or
                         (round = 2 and ((k = 0 and cnt = 7) or (k /= 0 and cnt = 1))) or
                         (round = 3 and cnt = 3) else '0';
    
    round_en   <= '1' when last_cnt = '1' and k = last_k else '0';
    last_round <= '1' when round = 3 and cnt = 3 else '0';
    k_en       <= last_cnt;
    last_k     <= 3 - round;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' then
                done <= '0';
            else
                done <= last_round;
            end if;
        end if;
    end process;
    
    done_o <= done;

--/*
-- **Counter Hierarchy**:
--```
--round (0-3)
--  ??> k (0 to last_k)
--       ??> cnt (0 to last_cnt)

--## Data Flow Timeline
--```
--Cycle 0: start_i='1'
--  ??> buff = perm(din_i, ...)
--  ??> round=0, k=0, cnt=0, busy='1'

--Cycles 1-8: Round 0, k=0
--  ??> cnt increments 0?7
--  ??> Each cycle: radix operation on top 4 bytes
--  ??> next_buff_044 updated with radix results
--  ??> At cnt=7: buff = perm(temp0, ...)

--Cycles 9-16: Round 0, k=1
--  ??> Similar pattern with different permutation

--...Continue through all rounds...

--Final: Round 3, cnt=3
--  ??> last_round='1'
--  ??> busy='0', done='1'
  
--Output Phase: dout_read_i pulses
--  ??> buff rotates, exposing 4-byte chunks
--  ??> dout_o = top 4 bytes
--*/

end rtl;