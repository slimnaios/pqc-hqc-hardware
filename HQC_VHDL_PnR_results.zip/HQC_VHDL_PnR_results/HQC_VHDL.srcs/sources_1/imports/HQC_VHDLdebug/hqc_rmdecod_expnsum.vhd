--/*Main conversions:

--Parameter calculations: Helper functions calculate MULTIPLICITY (3 or 5) and NWIDTH (2 or 3) based on PARAM_SECURITY
--Buffer operations:

--din_buf stores incoming 128-bit words
--dout_buf stores the complete buffer and shifts right by 2 bits each cycle during output


--For loop in process: The Verilog for loop that shifts the buffer is converted to a VHDL process with a variable and loop
--Conditional generate: Used if generate to create different adder configurations for MULTIPLICITY = 3 vs MULTIPLICITY = 5
--Adders: Sum corresponding bits from multiple 128-bit segments (either 3 or 5 segments)

--Key implementation details:

--Expand operation: Takes MULTIPLICITY 128-bit words and expands them into a larger buffer
--Sum operation: Adds corresponding bits from all segments (positions 0, 128, 256, etc. for even; positions 1, 129, 257, etc. for odd)
--Shift mechanism: Each cycle shifts the buffer right by 2 bits to present the next pair of bits for summation
--Outputs 64 pairs: Processes 64 output cycles (cnt_out: 0-63), producing two sums per cycle (dout0, dout1)
--Flow control: start_ready indicates when ready to accept new data, din_ready gates input acceptance

--This module expands the received codeword and sums corresponding positions, 
--which is part of the Reed-Muller soft-decision decoding process in the HQC cryptosystem.

--Overview
--Purpose: Takes multiple repetitions of a received codeword and combines them to improve reliability through soft-decision decoding.
--Key Concept: Instead of decoding a single noisy codeword, it combines MULTIPLICITY copies (3 or 5) to create more reliable soft decision values.
--This module implements repetition code combining for soft-decision Reed-Muller decoding:
--? Expands: Stores MULTIPLICITY repetitions of 128-bit blocks
--? Sums: Adds corresponding bits across all repetitions
--? Outputs: 64 pairs of confidence values (0 to MULTIPLICITY)
--? Efficiency: Processes 2 bits per cycle via parallel summation    
--*/    

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity hqc_rmdecod_expnsum is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i          : in  std_logic;
        rst_ni         : in  std_logic;
        start_i        : in  std_logic;
        start_ready_o  : out std_logic;
        din_i          : in  std_logic_vector(127 downto 0);
        din_valid_i    : in  std_logic;
        din_ready_o    : out std_logic;
        dout_start_o   : out std_logic;
        dout0_o        : out std_logic_vector(get_NWIDTH(PARAM_SET)-1 downto 0);--(NWIDTH-1 downto 0);
        dout1_o        : out std_logic_vector(get_NWIDTH(PARAM_SET)-1 downto 0);--(NWIDTH-1 downto 0);
        dout_valid_o   : out std_logic;
        dout_ready_i   : in  std_logic
    );
end hqc_rmdecod_expnsum;

architecture rtl of hqc_rmdecod_expnsum is

-- Parameter calculations
constant MULTIPLICITY : integer := get_MULTIPLICITY(PARAM_SET);
constant NWIDTH       : integer := get_NWIDTH(PARAM_SET);

-- Internal signals
signal din_ready      : std_logic;
signal start_ready    : std_logic; -- Ready to accept new input (deasserts during processing)
signal dout_valid     : std_logic; -- Output data is valid (asserted for 64 cycles)
signal dout_start     : std_logic; -- Pulses when output starts (tells next module to prepare)
signal dout0          : std_logic_vector(NWIDTH-1 downto 0);
signal dout1          : std_logic_vector(NWIDTH-1 downto 0);
signal add_out0       : std_logic_vector(NWIDTH-1 downto 0);
signal add_out1       : std_logic_vector(NWIDTH-1 downto 0);
signal din_buf        : std_logic_vector(MULTIPLICITY*128-128-1 downto 0);
signal dout_buf       : std_logic_vector(MULTIPLICITY*128-1 downto 0);
signal last_din       : std_logic; -- Last input block received (cnt = MULTIPLICITY-1)
signal cnt            : unsigned(2 downto 0) := (others => '0');
signal cnt_out        : unsigned(7 downto 0) := (others => '0');
signal cnt_out_en     : std_logic; -- Output processing active (gates the shifting and output)
signal din_ack        : std_logic; -- Input acknowledged (valid AND ready) 

begin
    
 din_ack <= din_valid_i and din_ready;
--initial  din_ack <= din_valid_i and din_ready_o;

 -- Input Buffer
 -- Receives MULTIPLICITY 128-bit blocks sequentially
 -- Shifts previous data right, inserts new data on left
process(clk_i)
begin
    if rising_edge(clk_i) then
        if din_ack = '1' then
            din_buf <= din_i & din_buf(MULTIPLICITY*128-128-1 downto 128);
        end if;
    end if;
end process;

-- Output Buffer (stores input and shifts for summation)
-- Shifts each 128-bit block **right by 2 bits** every cycle
-- Inserts zeros at the bottom
-- Does this for all MULTIPLICITY blocks simultaneously
-- Presents the next pair of bits for summation each cycle
BUFF: process(clk_i)
    variable temp_buf : std_logic_vector(MULTIPLICITY*128-1 downto 0);
begin
    if rising_edge(clk_i) then
        if din_ack = '1' and last_din = '1' then
            dout_buf <= din_i & din_buf;
        elsif cnt_out_en = '1' then
            temp_buf := dout_buf;
            for ii in 0 to MULTIPLICITY-1 loop
                temp_buf(ii*128+125 downto ii*128) := dout_buf(ii*128+127 downto ii*128+2);
                temp_buf(ii*128+127 downto ii*128+126) := "00";
            end loop;
            dout_buf <= temp_buf;
        end if;
    end if;
end process;

-- Adder (generate based on MULTIPLICITY)
-- `add_out0`: Sums bit 0 from all 3 blocks
-- `add_out1`: Sums bit 1 from all 3 blocks
-- Result ranges from 0 to MULTIPLICITY
gen_mult_3: if MULTIPLICITY = 3 generate
    add_out0 <= std_logic_vector(
        resize(unsigned'('0' & dout_buf(0)), NWIDTH) +     -- Block 0, bits [0]
        resize(unsigned'('0' & dout_buf(128)), NWIDTH) +   -- Block 1, bits [0]
        resize(unsigned'('0' & dout_buf(256)), NWIDTH)       -- Block 2, bits [0]
    );
    add_out1 <= std_logic_vector(
        resize(unsigned'('0' & dout_buf(1)), NWIDTH) +     -- Block 0, bits [1]
        resize(unsigned'('0' & dout_buf(129)), NWIDTH) +   -- Block 1, bits [1]
        resize(unsigned'('0' & dout_buf(257)), NWIDTH)       -- Block 2, bits [1]
    );

end generate;
gen_mult_5: if MULTIPLICITY = 5 generate
    add_out0 <= std_logic_vector(
        resize(unsigned'('0' & dout_buf(0)), NWIDTH) +     
        resize(unsigned'('0' & dout_buf(128)), NWIDTH) +   
        resize(unsigned'('0' & dout_buf(256)), NWIDTH) +    
        resize(unsigned'('0' & dout_buf(384)), NWIDTH) +
        resize(unsigned'('0' & dout_buf(512)), NWIDTH) 
    );
    add_out1 <= std_logic_vector(
        resize(unsigned'('0' & dout_buf(1)), NWIDTH) +     
        resize(unsigned'('0' & dout_buf(129)), NWIDTH) +   
        resize(unsigned'('0' & dout_buf(257)), NWIDTH) +    
        resize(unsigned'('0' & dout_buf(385)), NWIDTH) +
        resize(unsigned'('0' & dout_buf(513)), NWIDTH)
    );
end generate;

process(clk_i)
begin
    if rising_edge(clk_i) then
        if cnt_out_en = '1' then
            dout0 <= add_out0;
            dout1 <= add_out1;
        end if;
    end if;
end process;

dout0_o <= dout0;
dout1_o <= dout1;

------------------------------------------------------------------------------
-- Controller
------------------------------------------------------------------------------

-- Input counter
process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or start_i = '1' or last_din = '1' then
            cnt <= (others => '0');
        elsif din_ack = '1' then
            cnt <= cnt + 1;
        end if;
    end if;
end process;

last_din <= '1' when cnt = (MULTIPLICITY*128/128-1) and din_ack = '1' else '0';

process(clk_i)
begin
    if rising_edge(clk_i) then
        din_ready <= start_ready;
    end if;
end process;

din_ready_o <= din_ready;

process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or cnt_out = 59 then
            start_ready <= '1';
        elsif cnt = (MULTIPLICITY*128/128-2) and din_ack = '1' then
            start_ready <= '0';
        end if;
    end if;
end process;

start_ready_o <= start_ready;

-- Output control
process(clk_i)
begin
    if rising_edge(clk_i) then
        dout_start <= last_din;
    end if;
end process;

dout_start_o <= dout_start;

process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or last_din = '1' then
            cnt_out <= (others => '0');
        elsif cnt_out_en = '1' then
            cnt_out <= cnt_out + 1;
        end if;
    end if;
end process;

process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or (cnt_out = 63 and last_din = '0') then
            cnt_out_en <= '0';
        elsif last_din = '1' then
            cnt_out_en <= '1';
        end if;
    end if;
end process;

process(clk_i)
begin
    if rising_edge(clk_i) then
        dout_valid <= cnt_out_en;
    end if;
end process;

dout_valid_o <= dout_valid;

end rtl;