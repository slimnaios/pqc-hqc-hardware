library ieee;  
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use work.system_constants.all;
use WORK.HQC_parameters.all;

entity tb_hqc_decod_top is
     generic (
        PARAM_SET : hqc_params_set_t := HQC_128
    );
end tb_hqc_decod_top;

architecture test of tb_hqc_decod_top is

component hqc_decod_top is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i           : in  std_logic;
        rst_ni          : in  std_logic;
        start_i         : in  std_logic;  -- 1 pulse start signal
        busy_o          : out std_logic;  -- decoding is busy signal
        -- Input RAM, read
        ram_din_i       : in  std_logic_vector(127 downto 0);
        ram_din_rd_o    : out std_logic;
        ram_din_addr_o  : out std_logic_vector(get_IN_AW(PARAM_SET)-1 downto 0);
        -- Output data
        dout_o          : out std_logic_vector((get_hqc_params(PARAM_SET).k1*8)-1 downto 0);--(DOUT_W-1 downto 0);  -- msg = {m[K-1],m[K-2],...,m[1],m[0]} with m[i] in byte
        dout_valid_o    : out std_logic  -- output valid
    );
end component hqc_decod_top;

constant HQC_PARAMS   : hqc_params_t := get_hqc_params(PARAM_SET);

constant N1_BYTES : natural := HQC_PARAMS.n1;
constant N1       : natural := 8*N1_BYTES;
constant LOG_N1_BYTES : natural := clog2(N1_BYTES);
constant K_BYTES : natural := HQC_PARAMS.k1;
constant K       : natural := 8*K_BYTES;

signal  clk_i, rst_ni, start_i  : std_logic;
signal  ram_din_i    : std_logic_vector(127 downto 0);
signal  busy_o, ram_din_rd_o, dout_valid_o : std_logic;

signal ram_din_addr_o  : std_logic_vector(get_IN_AW(PARAM_SET)-1 downto 0);
signal dout_o : std_logic_vector((get_hqc_params(PARAM_SET).k1*8)-1 downto 0);

    
constant CLOCK_PERIOD : time := 10 ns;

constant CHECK_CASES : integer := 5;    
type arr is array(integer range <>) of std_logic_vector(K-1 downto 0);
type check_array_t is array (0 to 45) of arr(0 to CHECK_CASES-1);

------ Input vectors ------
constant cdw_check0: arr(0 to CHECK_CASES-1)  := (
x"3345b62bccd0f9fa93c9f66d5ba459dc",
x"3345b62bccd0f9fa93c9f66d5ba459dc",
x"024d9b3b49ad6182864b80224db76b39",
x"886bd7616b819996cfe0e6c85a14a058",
x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check1: arr(0 to CHECK_CASES-1)  := (
x"3345b62bccd0f9fa93c9f66d5ba459dc",
x"408d22cba41f2256891d98a81bc90855",
x"2f694a7667057641364ddfd909b1593d",
x"274e736a947da9e2481d1091da3af496",
x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check2: arr(0 to CHECK_CASES-1)  := (
x"3345b62bccd0f9fa93c9f66d5ba459dc",
x"2c9d30e5cf860441554c3e18a3d28fb8",
x"391f5f9281234a10bc7cb0306f91dfc3",
x"120ddcb90b0b408ecbc3eb69e8b1f933",
x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check3: arr(0 to CHECK_CASES-1)  := (
x"3345b62bccd0f9fa93c9f66d5ba459dc",
x"a2ff60d108f5b07d8a153e13ab552945",
x"a0d4ac01ae3e0b5b8d5ea8d572144ad4",
x"b2796a513b730a1b9e54e220b0a12224",
x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check4: arr(0 to CHECK_CASES-1)  := (
x"3345b62bccd0f9fa93c9f66d5ba459dc",
x"07af91514c033aeb4d81b12f66b6b154",
x"0b28d35414d52b837d523a9a68ca5b55",
x"8aee358ad557a2027757de726eecd15b",
x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check5: arr(0 to CHECK_CASES-1)  := (
x"3345b62bccd0f9fa93c9f66d5ba459dc",
x"9a6a6667bc676edccb4d983551493baa",
x"74125a0af866260af1c5b9f1b40c21b9",
x"224e06557e64456e08998990dc89b992",
x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check6: arr(0 to CHECK_CASES-1)  := (
x"3345b62bccd0f9fa93c9f66d5ba459dc",
x"f1ae0b5daa15e1627066dff4eb573d0e",
x"5196ed158f511dbacb41aa57e6a6543a",
x"5fefba6da259acbe0fa62a4adbd992e2",
x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check7: arr(0 to CHECK_CASES-1)  := (
x"3345b62bccd0f9fa93c9f66d5ba459dc",
x"3d4904de558b7887e1dfcdb7e22f1acc",
x"1d980d1adbe72080e15ccdc84671ca82",
x"ac5901e81be71a2c1750e002f7817ee5",
x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check8: arr(0 to CHECK_CASES-1)  := (
x"3345b62bccd0f9fa93c9f66d5ba459dc",
x"c8db66ea6326911fc6c6dd18b09a464d",
x"8b932f46de6595ad3762582119c6b7d7",
x"833094dc5120b891aa3f95eb53e5e643",
x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check9: arr(0 to CHECK_CASES-1)  := (
x"3345b62bccd0f9fa93c9f66d5ba459dc",
x"68e93905b01bede829384c7abedc34eb",
x"9eee7f0bba487da851f2cadeadddb36a",
x"8cc981373719cec551815c86d01c3a1e",
x"3345b62bccd0f9fa93c9f66d5ba459dc"
);   
 
constant cdw_check10 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"d6071990fa8e03bcfa178622a14d0f96",
    x"8c618fff56330bd9fa3d1776729a27c0",
    x"d47f3dfc620d15f4bd4f0580c86f6af9",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check11 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"46ab3ac1e83a142214a0f37fa67d65a8",
    x"d70fabd10035872ac4be09553ad975ea",
    x"11ca296598d5d7b2874f8a146a560682",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check12 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"6da14258956756cf25a9335aa58562ab",
    x"883557f6e1a52e7273b54adaeced6843",
    x"bbaf0f9f6b6252b1ae8a5fd2a1a91ade",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check13 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"1dc09eb7fee87b8e8a8b7331e15bac41",
    x"1115923bae22f9a18e7a82e0fd907564",
    x"5dbf9dd78382e2aaf886ae3ec163627f",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check14 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"93fb7854dc795a02d7f25e21e1909a67",
    x"ae4e8ae6d3e129d448908465f2950dad",
    x"826b6883fe6823d32a2a166d6515047b",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check15 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"c0f2dcec4bca4a2a28f32d75a0b410e1",
    x"f2b8c0dc140f435ebbde598eaa22f3d0",
    x"d9b058f8c73fcf3a572e8908eefd60f4",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check16 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"154e7604463e9e4720b48def82e7b531",
    x"08c6e1b6429b99c6708da14699a6e49c",
    x"884f52921488dbe65349af07bd476099",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check17 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"66eaa2f33cc5f0ab5df310af7ce92c4e",
    x"0fc529e354c13163bb2bb85bbf4f4a00",
    x"3def806ade43bf4278424c6058ad0caa",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check18 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"e1a3af2f119dd7832f68e9cb939b5faf",
    x"d30bb5fce56f180c357587f113abe8cd",
    x"6d809e2dfcec1769113eeb82c3501d2d",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check19 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"8764f9a7fe605c011f98d7ac7dff0c27",
    x"47890cdfaeb328f13800fb7dabff1008",
    x"4c4cd3ee69da13019030fb7ed56b2adc",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check20 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"9f216369fb6675d24b991579a1179e21",
    x"5ee8e976562d78d2e9b2272379279401",
    x"36ea4fceb5e3e1857b72455e08b7b56b",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check21 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"232c2032ea75725d5168dd9d8fbc3e04",
    x"c10b413023416fd5163a16bab23c8128",
    x"5d6b0d803e0dacfd15e0569e3311eaf5",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check22 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"c0396cd5acaee1bbd0051e410d82b81c",
    x"359648ac4bebc1a315fc957743e9e8da",
    x"5d0316dd2eae978b0b5df997b8c1fb36",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check23 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"cf2770d1c0f78f430c2d24c0a2713f4f",
    x"2f0c58f28af44f0fcf0f7232e8b73a8f",
    x"2c21f5b97b34131dc05b64b2f6810b3f",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check24 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"79693eaf96f47606850c968a2be97931",
    x"fb296b4f16838fc49a37cc88ac7be6f4",
    x"a66c45f094b10649b446f6940df16d21",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check25 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"38d3506465bbc344aa271dea92741e5b",
    x"0a33598c73ab81510a4715b03dace1d6",
    x"6a0c4ba0c3368c45423509bb7e898a62",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check26 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"f2be4b5deef6148fa30f62a2eb4ef0f8",
    x"eaba29635e1b3621a05e9be01382f2f0",
    x"b068392bf912e693c77fca292e089de6",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check27 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"39c0821e339dc911c53bb68ad6270198",
    x"7b0dce783b846a91cc3252acfa337188",
    x"2eacbc52564e0a9b801331af77237ade",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check28 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"7fce82ad16440949ac5be0f675f3c164",
    x"a7aed69caf4fa31bda1f8f96357618f9",
    x"303693c977cc348c0c72de4af8a8bd23",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check29 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"8f0ff8214f1f9a72b0dc4d1b6661ac9d",
    x"064f58cb3baea0e302703f4ff5d5025e",
    x"4f45e4fc9dfc2458ab6a1d57a0dc0b03",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check30 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"0ba0a15206010683888da235289a4071",
    x"00586484c130648273049a253ea85152",
    x"08598062170906834303282212aa0141",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check31 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"adb63b88e88432ab8b1a93a238c6fae3",
    x"a20b6e2b2e75e8e308a2d2f728eee3a1",
    x"d6f777e0c080cbb8c88235a78d7aaeb1",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check32 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"476dc7dc147c9db684ea9de4c8f88c4e",
    x"2683f8e0ac6e8c6fecddaedc08e7cee4",
    x"eeef8444789cbecec08818c82148dcc2",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check33 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"ee677474f46a27a64b6621c6b4567466",
    x"7ee6afc59629af719d277277026d2c76",
    x"ee025f774de7e6e07d6866a6c06032cc",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check34 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"7cfca4d8c42b1a55deec586a77c8a834",
    x"f7c0a4aee834e0b864b8b0f1f039fae3",
    x"f4f2e9d2f0e0b8dff071c4d4f030b091",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check35 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"e2517efafb48fbf3466b5c1b584a548a",
    x"7a436b98525f5a9f7ff33a4b523af2ca",
    x"4af8e27ddb726b6f79801e9600bb76e4",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check36 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"7e349d1939fd38f89cac376c1ce83bad",
    x"b71ce804712f2d3e9e18fc1ba4687e30",
    x"701ff434a4ba54dcf217ad3d0c2d2d20",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check37 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"b4baa6969a06861656dea61486d68a96",
    x"8a8016d4c496c7ae9f1a0e3ab69cd50a",
    x"e7b49794923ef3b37dc8d0cb8e67d4d0",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check38 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"5b2e67240c2bc30bd5069e28fe00b9c2",
    x"fb0887c04a8b8d4a7aa89438de824700",
    x"1e1aff43498c5d67b96539d5ee8a9d23",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check39 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"6daf4508308a7124552becc8bdac552a",
    x"5b02548c7fa04e2a75b816c7b792c5d2",
    x"556a5c80f5b437b275a3f4bad7a8a78e",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check40 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"76d824dc15c01dccafecb24607ec8b8c",
    x"73ecd385536d3949ac0da38411c4814e",
    x"b56abb76df8d9eb2ea6537b628ef33dd",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check41 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"d3d652deafee17aac0c2c928f867917e",
    x"9cc399108dea9943c824d80621569551",
    x"dcb7417802c7d8638c07d8269ff2c5a0",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check42 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"0fcaab3477a029f813ec66e02ab8a123",
    x"48a2da5c0f318dc017e609321f20ada4",
    x"0ff00f7acb458fc8cff70f685c5841e1",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check43 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"54d21873f0fea76e81d8616da1b903d8",
    x"e6dcb332c9f63442a478ed5acf2abd10",
    x"a61e031b2762eb073c3ad1128cd4e4f3",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check44 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"d110d19aa770d1b8237e45ac8937474c",
    x"aa2cc368fe38db0a6a55424517bed70a",
    x"03345325e205f308c20c90bef3ecf325",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant cdw_check45 : arr(0 to CHECK_CASES-1) := (
    x"3345b62bccd0f9fa93c9f66d5ba459dc",
    x"f95e769271d60038f396601a031267c4",
    x"c19974872d876d82695c7097e9ada996",
    x"08542871762ff9761d924f5c71ee288e",
    x"3345b62bccd0f9fa93c9f66d5ba459dc"
);

constant check_data : check_array_t := (
  cdw_check0,  cdw_check1,  cdw_check2,  cdw_check3,  cdw_check4,
  cdw_check5,  cdw_check6,  cdw_check7,  cdw_check8,  cdw_check9,
  cdw_check10, cdw_check11, cdw_check12, cdw_check13, cdw_check14,
  cdw_check15, cdw_check16, cdw_check17, cdw_check18, cdw_check19,
  cdw_check20, cdw_check21, cdw_check22, cdw_check23, cdw_check24,
  cdw_check25, cdw_check26, cdw_check27, cdw_check28, cdw_check29,
  cdw_check30, cdw_check31, cdw_check32, cdw_check33, cdw_check34,
  cdw_check35, cdw_check36, cdw_check37, cdw_check38, cdw_check39,
  cdw_check40, cdw_check41, cdw_check42, cdw_check43, cdw_check44,
  cdw_check45
);

---------------------------
 
begin
    
dut: hqc_decod_top
    generic map(
        PARAM_SET => PARAM_SET
    )
     port map
     (
        clk_i          => clk_i,
        rst_ni          => rst_ni,
        start_i        => start_i,
	    busy_o          => busy_o,  -- decoding is busy signal
        -- Input RAM, read
        ram_din_i       => ram_din_i,
        ram_din_rd_o    => ram_din_rd_o,
        ram_din_addr_o  => ram_din_addr_o,
        -- Output data
        dout_o          => dout_o,
        dout_valid_o    => dout_valid_o
);
  
    
tb: process  

begin
       
wait until rst_ni = '1';
wait until rst_ni = '0';

report "Simulation started!";

start_i <= '0'; 

-- 2 cycles
   for i in 0 to 1 loop
    wait until rising_edge(clk_i);
   end loop;	

start_i <= '1'; 
wait until rising_edge(clk_i);

start_i <= '0'; 

------ Input vectors loop ------
for j in 0 to 45 loop
  for k in 0 to CHECK_CASES-1 loop
    ram_din_i <= check_data(j)(k);
    wait until rising_edge(clk_i);
  end loop;
  
  for i in 0 to 58 loop
    wait until rising_edge(clk_i);
  end loop;
end loop;
--------------------------------

end process;

check_results: process
       
variable result: std_logic_vector (7 downto 0);
    
begin

wait until rst_ni = '1';
wait until rst_ni = '0';
        
--for t in 0 to CHECK_CASES-1 loop

 wait until rising_edge(clk_i);
	result := dout_o;		 

    if dout_valid_o = '1' then
    --if result = ciphertext_check(t) then
	 report "Codeword produced!";
    --else
	 --report "Test vector failed!" severity failure;
   end if;  
        
--end loop;       
	
end process;    
   
clock: process				
begin					
 clk_i <= '0';
 wait for CLOCK_PERIOD/2;	--5 ns
 clk_i <= '1';
 wait for CLOCK_PERIOD/2;

if NOW > 46500 ns then
 assert false report "Simulation terminated!" severity note;
 wait;
end if;

end process;

reset: process
begin
 --rst_ni <= '0';
 --wait for 5 ns;
 rst_ni <= '1';
 wait for 5 ns;
 rst_ni <= '0';
 wait for 5 ns;
 rst_ni <= '1';
 wait;
 
end process;

end test;  


