--/*Main conversions:

--Berlekamp-Massey Algorithm: This module implements the Berlekamp-Massey algorithm to find the Error Locator Polynomial (ELP) sigma(x) from syndromes.
--The Berlekamp-Massey algorithm finds the shortest Linear Feedback Shift Register (LFSR) that generates the syndrome sequence. 
--The resulting polynomial sigma(x) encodes the error locations in the Reed-Solomon codeword (polynomial's roots reveal where errors occurred in the received codeword).

--Helper functions:
--xor_byte: XORs all bytes in a vector (reduces multiple bytes to single byte)
--gf_inverse: Complete 256-entry lookup table for GF(2^8) multiplicative inverses

--Key variables:
--sigma: Error locator polynomial coefficients
--d: Discrepancy value
--dd: Normalized discrepancy (d � inv_dp)
--deg_sigma: Degree of current sigma polynomial
--X_sigma_p: Previous sigma polynomial multiplied by X

--Algorithm flow:
--Processes syndromes in 2�DELTA iterations
--Updates sigma polynomial when discrepancy is non-zero and degree test passes
--Uses mask logic (mask1, mask2, mask12) to control updates

--Pipeline control: cnt_en_buf is a 3-stage shift register that sequences operations:
--Stage 0: Update dd and deg_X_sigma_p
--Stage 1: Update sigma and X_sigma_p conditionally
--Stage 2: Update d and inv_dp

--Key implementation details:
--Syndrome rotation: Circular shifts syndrome buffer to present next byte
--Syndrome swap: Reverses byte order for discrepancy calculation
--GF multipliers: PARAM_DELTA parallel multipliers for polynomial operations
--Degree calculation: Tracks polynomial degree for algorithm termination
--Inverse calculation: Uses precomputed lookup table (faster than calculation)
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity hqc_rsdecod_elp is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i        : in  std_logic;
        rst_ni       : in  std_logic;
        din_i        : in  std_logic_vector;--(DIN_W-1 downto 0);  -- syndrome
        din_valid_i  : in  std_logic;
        busy_o       : out std_logic;
        dout_o       : out std_logic_vector;--(DOUT_W-1 downto 0); -- coefficients of sigma(x)
        dout_valid_o : out std_logic;
        deg_sigma_o  : out std_logic_vector--(7 downto 0)         -- degree of sigma(x) = number of errors found (? ?)
    );
end hqc_rsdecod_elp;

architecture rtl of hqc_rsdecod_elp is

constant HQC_PARAMS  : hqc_params_t := get_hqc_params(PARAM_SET);
constant PARAM_DELTA : integer := HQC_PARAMS.delta;
constant DIN_W       : integer := 8 * 2 * PARAM_DELTA;   --2? syndromes packed into bytes (? = t = error-correcting capability, e.g. 15 for HQC-128 ? 30 syndromes ? DIN_W = 240 bits)
constant DOUT_W      : integer := 8 * (PARAM_DELTA + 1);

    -- Helper function for parameter calculations

    -- XOR all bytes in a vector
    function xor_byte(x : std_logic_vector) return std_logic_vector is
        variable result : std_logic_vector(7 downto 0);
        variable delta : integer;
    begin
        delta := x'length / 8;
        result := (others => '0');
        for j in 0 to delta-1 loop
            result := result xor x(8*j+7 downto 8*j);
        end loop;
        return result;
    end function;
    
    -- Galois Field inverse lookup table
    function gf_inverse(x : std_logic_vector(7 downto 0)) return std_logic_vector is
        variable result : std_logic_vector(7 downto 0);
        variable val : integer;
    begin
        val := to_integer(unsigned(x));
        case val is
            when 0   => result := x"00"; when 1   => result := x"01"; when 2   => result := x"8E"; when 3   => result := x"F4";
            when 4   => result := x"47"; when 5   => result := x"A7"; when 6   => result := x"7A"; when 7   => result := x"BA";
            when 8   => result := x"AD"; when 9   => result := x"9D"; when 10  => result := x"DD"; when 11  => result := x"98";
            when 12  => result := x"3D"; when 13  => result := x"AA"; when 14  => result := x"5D"; when 15  => result := x"96";
            when 16  => result := x"D8"; when 17  => result := x"72"; when 18  => result := x"C0"; when 19  => result := x"58";
            when 20  => result := x"E0"; when 21  => result := x"3E"; when 22  => result := x"4C"; when 23  => result := x"66";
            when 24  => result := x"90"; when 25  => result := x"DE"; when 26  => result := x"55"; when 27  => result := x"80";
            when 28  => result := x"A0"; when 29  => result := x"83"; when 30  => result := x"4B"; when 31  => result := x"2A";
            when 32  => result := x"6C"; when 33  => result := x"ED"; when 34  => result := x"39"; when 35  => result := x"51";
            when 36  => result := x"60"; when 37  => result := x"56"; when 38  => result := x"2C"; when 39  => result := x"8A";
            when 40  => result := x"70"; when 41  => result := x"D0"; when 42  => result := x"1F"; when 43  => result := x"4A";
            when 44  => result := x"26"; when 45  => result := x"8B"; when 46  => result := x"33"; when 47  => result := x"6E";
            when 48  => result := x"48"; when 49  => result := x"89"; when 50  => result := x"6F"; when 51  => result := x"2E";
            when 52  => result := x"A4"; when 53  => result := x"C3"; when 54  => result := x"40"; when 55  => result := x"5E";
            when 56  => result := x"50"; when 57  => result := x"22"; when 58  => result := x"CF"; when 59  => result := x"A9";
            when 60  => result := x"AB"; when 61  => result := x"0C"; when 62  => result := x"15"; when 63  => result := x"E1";
            when 64  => result := x"36"; when 65  => result := x"5F"; when 66  => result := x"F8"; when 67  => result := x"D5";
            when 68  => result := x"92"; when 69  => result := x"4E"; when 70  => result := x"A6"; when 71  => result := x"04";
            when 72  => result := x"30"; when 73  => result := x"88"; when 74  => result := x"2B"; when 75  => result := x"1E";
            when 76  => result := x"16"; when 77  => result := x"67"; when 78  => result := x"45"; when 79  => result := x"93";
            when 80  => result := x"38"; when 81  => result := x"23"; when 82  => result := x"68"; when 83  => result := x"8C";
            when 84  => result := x"81"; when 85  => result := x"1A"; when 86  => result := x"25"; when 87  => result := x"61";
            when 88  => result := x"13"; when 89  => result := x"C1"; when 90  => result := x"CB"; when 91  => result := x"63";
            when 92  => result := x"97"; when 93  => result := x"0E"; when 94  => result := x"37"; when 95  => result := x"41";
            when 96  => result := x"24"; when 97  => result := x"57"; when 98  => result := x"CA"; when 99  => result := x"5B";
            when 100 => result := x"B9"; when 101 => result := x"C4"; when 102 => result := x"17"; when 103 => result := x"4D";
            when 104 => result := x"52"; when 105 => result := x"8D"; when 106 => result := x"EF"; when 107 => result := x"B3";
            when 108 => result := x"20"; when 109 => result := x"EC"; when 110 => result := x"2F"; when 111 => result := x"32";
            when 112 => result := x"28"; when 113 => result := x"D1"; when 114 => result := x"11"; when 115 => result := x"D9";
            when 116 => result := x"E9"; when 117 => result := x"FB"; when 118 => result := x"DA"; when 119 => result := x"79";
            when 120 => result := x"DB"; when 121 => result := x"77"; when 122 => result := x"06"; when 123 => result := x"BB";
            when 124 => result := x"84"; when 125 => result := x"CD"; when 126 => result := x"FE"; when 127 => result := x"FC";
            when 128 => result := x"1B"; when 129 => result := x"54"; when 130 => result := x"A1"; when 131 => result := x"1D";
            when 132 => result := x"7C"; when 133 => result := x"CC"; when 134 => result := x"E4"; when 135 => result := x"B0";
            when 136 => result := x"49"; when 137 => result := x"31"; when 138 => result := x"27"; when 139 => result := x"2D";
            when 140 => result := x"53"; when 141 => result := x"69"; when 142 => result := x"02"; when 143 => result := x"F5";
            when 144 => result := x"18"; when 145 => result := x"DF"; when 146 => result := x"44"; when 147 => result := x"4F";
            when 148 => result := x"9B"; when 149 => result := x"BC"; when 150 => result := x"0F"; when 151 => result := x"5C";
            when 152 => result := x"0B"; when 153 => result := x"DC"; when 154 => result := x"BD"; when 155 => result := x"94";
            when 156 => result := x"AC"; when 157 => result := x"09"; when 158 => result := x"C7"; when 159 => result := x"A2";
            when 160 => result := x"1C"; when 161 => result := x"82"; when 162 => result := x"9F"; when 163 => result := x"C6";
            when 164 => result := x"34"; when 165 => result := x"C2"; when 166 => result := x"46"; when 167 => result := x"05";
            when 168 => result := x"CE"; when 169 => result := x"3B"; when 170 => result := x"0D"; when 171 => result := x"3C";
            when 172 => result := x"9C"; when 173 => result := x"08"; when 174 => result := x"BE"; when 175 => result := x"B7";
            when 176 => result := x"87"; when 177 => result := x"E5"; when 178 => result := x"EE"; when 179 => result := x"6B";
            when 180 => result := x"EB"; when 181 => result := x"F2"; when 182 => result := x"BF"; when 183 => result := x"AF";
            when 184 => result := x"C5"; when 185 => result := x"64"; when 186 => result := x"07"; when 187 => result := x"7B";
            when 188 => result := x"95"; when 189 => result := x"9A"; when 190 => result := x"AE"; when 191 => result := x"B6";
            when 192 => result := x"12"; when 193 => result := x"59"; when 194 => result := x"A5"; when 195 => result := x"35";
            when 196 => result := x"65"; when 197 => result := x"B8"; when 198 => result := x"A3"; when 199 => result := x"9E";
            when 200 => result := x"D2"; when 201 => result := x"F7"; when 202 => result := x"62"; when 203 => result := x"5A";
            when 204 => result := x"85"; when 205 => result := x"7D"; when 206 => result := x"A8"; when 207 => result := x"3A";
            when 208 => result := x"29"; when 209 => result := x"71"; when 210 => result := x"C8"; when 211 => result := x"F6";
            when 212 => result := x"F9"; when 213 => result := x"43"; when 214 => result := x"D7"; when 215 => result := x"D6";
            when 216 => result := x"10"; when 217 => result := x"73"; when 218 => result := x"76"; when 219 => result := x"78";
            when 220 => result := x"99"; when 221 => result := x"0A"; when 222 => result := x"19"; when 223 => result := x"91";
            when 224 => result := x"14"; when 225 => result := x"3F"; when 226 => result := x"E6"; when 227 => result := x"F0";
            when 228 => result := x"86"; when 229 => result := x"B1"; when 230 => result := x"E2"; when 231 => result := x"F1";
            when 232 => result := x"FA"; when 233 => result := x"74"; when 234 => result := x"F3"; when 235 => result := x"B4";
            when 236 => result := x"6D"; when 237 => result := x"21"; when 238 => result := x"B2"; when 239 => result := x"6A";
            when 240 => result := x"E3"; when 241 => result := x"E7"; when 242 => result := x"B5"; when 243 => result := x"EA";
            when 244 => result := x"03"; when 245 => result := x"8F"; when 246 => result := x"D3"; when 247 => result := x"C9";
            when 248 => result := x"42"; when 249 => result := x"D4"; when 250 => result := x"E8"; when 251 => result := x"75";
            when 252 => result := x"7F"; when 253 => result := x"FF"; when 254 => result := x"7E"; when 255 => result := x"FD";
            when others => result := x"00";
        end case;
        return result;
    end function;
    
    -- Internal signals
    signal syndrome_buf      : std_logic_vector(DIN_W-1 downto 0);
    signal sigma             : std_logic_vector(DOUT_W-1 downto 0);
    signal syndrome_swap     : std_logic_vector(8*PARAM_DELTA-1 downto 0);
    signal d                 : std_logic_vector(7 downto 0);
    signal dd                : std_logic_vector(7 downto 0);
    signal deg_X_sigma_p     : std_logic_vector(7 downto 0);
    signal dd_mul_out        : std_logic_vector(7 downto 0);
    signal pp                : std_logic_vector(7 downto 0);
    signal dp                : std_logic_vector(7 downto 0);
    signal inv_dp            : std_logic_vector(7 downto 0);
    signal deg_sigma         : std_logic_vector(7 downto 0);
    signal deg_sigma_p       : std_logic_vector(7 downto 0);
    signal X_sigma_p         : std_logic_vector(DOUT_W-1 downto 0);
    signal mask1             : std_logic;
    signal mask2             : std_logic;
    signal mask12            : std_logic;                                      --update condition: discrepancy ? 0 AND degree condition satisfied
    signal gf_mul_in1        : std_logic_vector(8*PARAM_DELTA-1 downto 0);
    signal gf_mul_in2        : std_logic_vector(8*PARAM_DELTA-1 downto 0);
    signal gf_mul_out        : std_logic_vector(8*PARAM_DELTA-1 downto 0);
    signal cnt               : unsigned(5 downto 0);
    signal mu                : std_logic_vector(5 downto 0);
    signal cnt_en_buf        : std_logic_vector(2 downto 0);
    signal busy              : std_logic;
    signal dout_valid        : std_logic;
    signal last_cnt          : std_logic;
    
    -- Component declaration
    component gf_mul is
        generic (
            REG_IN  : integer := 0;
            REG_OUT : integer := 0
        );
        port (
            clk    : in  std_logic;
            start  : in  std_logic;
            in_1   : in  std_logic_vector(7 downto 0);
            in_2   : in  std_logic_vector(7 downto 0);
            output : out std_logic_vector(7 downto 0);
            done   : out std_logic
        );
    end component;

begin

    -- syndrome = {m[2D-1],m[2D-2],...,m[1],m[0]} with m[i] in byte
    -- Circular buffer providing syndrome values as needed
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if din_valid_i = '1' then
                syndrome_buf <= din_i;
            elsif cnt_en_buf(0) = '1' then
                syndrome_buf <= syndrome_buf(7 downto 0) & syndrome_buf(2*8*PARAM_DELTA-1 downto 8);
            end if;
        end if;
    end process;
    
    -- Swapped first DELTA syndrome for d calculation
    -- Reorders first DELTA syndromes for the discrepancy calculation. This reverses the order to align with polynomial coefficient ordering.
    gen_swap: for i in 0 to PARAM_DELTA-1 generate
        syndrome_swap(8*i+7 downto 8*i) <= syndrome_buf(2*8*PARAM_DELTA-1-8*i downto 2*8*PARAM_DELTA-8-8*i);
    end generate;
    
    -- Calculate Discrepancy d
    -- d_? = S_? + ?(?_i � S_{?-i})  for i = 1 to deg(?)
    -- This is the "error" or "mismatch" between what the current ?(x) predicts and what the syndromes actually are.
    -- Process:
    -- Multiply ? coefficients by corresponding syndromes (via GF multipliers)
    -- XOR all products together (xor_byte)
    -- XOR with current syndrome
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if din_valid_i = '1' then
                d <= din_i(7 downto 0);
            elsif cnt_en_buf(2) = '1' then
                d <= syndrome_buf(7 downto 0) xor xor_byte(gf_mul_out);
            end if;
        end if;
    end process;
    
    -- Calculate inverse dp
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if din_valid_i = '1' then
                inv_dp <= x"01";
            elsif cnt_en_buf(2) = '1' then
                inv_dp <= gf_inverse(dp);   -- 1/d_p in Galois Field
            end if;
        end if;
    end process;
    
    -- Calculate Normalized Discrepancy dd = gf_mul(d, inv_dp)
    -- Scales the correction by the inverse of the previous discrepancy. This normalization ensures the algorithm converges correctly.
    DD_MUL : gf_mul
        generic map (
            REG_IN  => 0,
            REG_OUT => 0
        )
        port map (
            clk    => clk_i,
            start  => '1',
            in_1   => d,
            in_2   => inv_dp,
            output => dd_mul_out,
            done   => open
        );
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if cnt_en_buf(0) = '1' then
                dd <= dd_mul_out;       -- dd = d � (1/d_p)
            end if;
        end if;
    end process;
    
    -- Calculate deg_X_sigma_p (degree of X * ?_p)
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if cnt_en_buf(0) = '1' then
                deg_X_sigma_p <= std_logic_vector(unsigned(mu) - unsigned(pp) + unsigned(deg_sigma_p));
            end if;
        end if;
    end process;
    
    -- Calculate pp, deg_sigma, deg_sigma_p, dp
    -- Update ?(x) only if:
    -- mask1: Discrepancy is non-zero (we need a correction)
    -- mask2: The correction would improve the degree condition
    mask1  <= '1' when d /= x"00" else '0';
    mask2  <= '1' when unsigned(deg_X_sigma_p) > unsigned(deg_sigma) else '0';
    mask12 <= mask1 and mask2;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if din_valid_i = '1' then
                pp          <= x"FF";  -- -1
                dp          <= x"01";
                deg_sigma   <= x"00";
                deg_sigma_p <= x"00";
            elsif cnt_en_buf(1) = '1' and mask12 = '1' then
                pp          <= std_logic_vector(resize(cnt,pp'length));--mu;
                dp          <= d;
                deg_sigma   <= deg_X_sigma_p;
                deg_sigma_p <= deg_sigma;
            end if;
        end if;
    end process;
    
    -- Calculate previous X_sigma
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if din_valid_i = '1' then
                --X_sigma_p <= (8 => '1', others => '0');  -- X_sigma_p[1] = 1
		X_sigma_p <= (X_sigma_p'range => '0');
		X_sigma_p(8) <= '1';
            elsif cnt_en_buf(1) = '1' then
                if mask12 = '1' then
                    X_sigma_p <= sigma(8*PARAM_DELTA-1 downto 0) & x"00";      -- X_sigma_p(x) = sigma(x) * x (shift current ? left by 1)
                else
                    X_sigma_p <= X_sigma_p(8*PARAM_DELTA-1 downto 0) & x"00";  -- X_sigma_p(x) = X_sigma_p(x) * x (shift previous ? left by 1)
                end if;
            end if;
        end if;
    end process;
  
--/*## Timing and Pipeline

--### **3-Stage Pipeline** (via `cnt_en_buf`):
--Allows one full BM iteration every 3 clock cycles
--```
--cnt_en_buf = "001" ? "010" ? "100" ? "001" ? ...
--             Stage 0  Stage 1  Stage 2
--```

--**Stage 0** (`cnt_en_buf(0)`):
--- Rotate syndrome buffer
--- Calculate dd => dd = d � inv_dp
--- Calculate deg_X_sigma_p

--**Stage 1** (`cnt_en_buf(1)`):
--- Decide whether to update sigma: if mask12 = '1' (d ? 0 AND deg(X�?_p) > current deg_sigma)
--- Update sigma(x) => ?(x) ? ?(x) + dd � X�?_p(x), X_sigma_p based on mask12  
--- Update degree and tracking variables

--**Stage 2** (`cnt_en_buf(2)`):
--- Calculate new discrepancy d = current syndrome ? (sum of sigma_i � previous syndromes) ? using parallel GF multipliers + XOR reduction (xor_byte)
--- Calculate inv_dp
--- Increment counter

--### **Per-Iteration Timeline**:
--```
--Cycle 0: cnt_en_buf = "001"
--  - Syndrome rotates
--  - dd computed
  
--Cycle 1: cnt_en_buf = "010"  
--  - sigma updated (maybe)
--  - X_sigma_p updated
  
--Cycle 2: cnt_en_buf = "100"
--  - New d calculated
--  - inv_dp calculated
--  - mu increments
  
--Repeat for 2�DELTA iterations
--*/

    -- Calculate sigma
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if din_valid_i = '1' then
                --sigma <= (0 => '1', others => '0');
		sigma <= (sigma'range => '0');
		sigma(0) <= '1';
            elsif cnt_en_buf(1) = '1' then
                sigma <= gf_mul_out & x"01";    -- sigma(x) = sigma(x) + dd * X_sigma_p(x)
            end if;
        end if;
    end process;
    
    deg_sigma_o <= deg_sigma;   -- Degree (= number of errors)
    dout_o      <= sigma;       -- Error locator polynomial coefficients
    
    -- DELTA gf_mul instances
    -- Dual Purpose (multiplexed via cnt_en_buf):
    -- During Stage 1: Compute dd � X_sigma_p for sigma update ? build dd � X�?_p(x)
    -- During Stage 2: Compute sigma � syndromes ? compute the predicted syndrome for discrepancy
    gen_gf_mul: for i in 0 to PARAM_DELTA-1 generate
        GFMUL_INST : gf_mul
            generic map (
                REG_IN  => 0,
                REG_OUT => 0
            )
            port map (
                clk    => clk_i,
                start  => '1',
                in_1   => gf_mul_in1(8*i+7 downto 8*i),
                in_2   => gf_mul_in2(8*i+7 downto 8*i),
                output => gf_mul_out(8*i+7 downto 8*i),
                done   => open
            );
    end generate;
    
    process(cnt_en_buf, dd, sigma)                              -- initial Verilog: assign gf_mul_in1 = cnt_en_buf[1]? {PARAM_DELTA{dd}} : sigma[8*PARAM_DELTA+8-1:8];
    begin
    if cnt_en_buf(1) = '1' then
        for i in 0 to PARAM_DELTA-1 loop
            gf_mul_in1(8*i+7 downto 8*i) <= dd;
        end loop;
    else
        gf_mul_in1 <= sigma(8*PARAM_DELTA+8-1 downto 8);
    end if;
    end process;
    
    gf_mul_in2 <= X_sigma_p(8*PARAM_DELTA+8-1 downto 8) when cnt_en_buf(1) = '1' else 
                  syndrome_swap;
    
    ------------------------------------------------------------------------------
    -- Controller
    ------------------------------------------------------------------------------
    
    -- Busy flag
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or (last_cnt = '1' and cnt_en_buf(1) = '1') then
                busy <= '0';
            elsif din_valid_i = '1' then
                busy <= '1';
            end if;
        end if;
    end process;
    
    busy_o <= busy;
    
    -- Counter
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or din_valid_i = '1' or (last_cnt = '1' and cnt_en_buf(1) = '1') then
                cnt <= (others => '0');
            elsif cnt_en_buf(2) = '1' then
                cnt <= cnt + 1;
            end if;
        end if;
    end process;
    
    mu       <= std_logic_vector(cnt);
    last_cnt <= '1' when cnt = (2*PARAM_DELTA-1) else '0';
    
    -- Counter enable buffer (shift register)
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or (last_cnt = '1' and cnt_en_buf(1) = '1') then
                cnt_en_buf <= "000";
            elsif din_valid_i = '1' then
                cnt_en_buf <= "001";
            elsif busy = '1' then
                cnt_en_buf <= cnt_en_buf(1 downto 0) & cnt_en_buf(2);
            end if;
        end if;
    end process;
    
    -- Output valid
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            dout_valid <= last_cnt and cnt_en_buf(1);
        end if;
    end process;
    
    dout_valid_o <= dout_valid;

end rtl;