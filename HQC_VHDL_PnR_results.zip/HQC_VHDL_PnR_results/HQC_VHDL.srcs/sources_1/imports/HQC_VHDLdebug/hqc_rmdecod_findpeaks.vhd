--/*Main conversions:

--Two modules in one file: Both the top-level hqc_rmdecod_findpeaks and the findpeaks_core submodule are included in the same artifact
--Parameter calculations: Helper functions calculate MULTIPLICITY and SUM_W based on PARAM_SECURITY
--Absolute value calculation: The two's complement negation ~din_i + 1 is implemented using signed arithmetic in VHDL
--Comparison logic: Converted Verilog comparison operators to VHDL with proper type casting using unsigned()
--Conditional assignments: Ternary operators converted to conditional signal assignments using when-else
--Counter logic: The 7-bit counter cnt_in is now type unsigned and increments by 2 (for even/odd tracking)

--Key implementation details:

--Top module instantiates two findpeaks_core instances: one for even positions (STARTPOS=0) and one for odd positions (STARTPOS=1)
--Comparison logic selects the peak with larger absolute value, or if equal, the one with larger position
--Output encoding: The MSB of dout indicates if a valid peak was found (not zero and not negative)
--Peak tracking: Each core tracks the maximum absolute value seen so far and its position
--Last detection: last_din triggers when counter reaches 63 (checking bits 6:1)

--This module finds the peaks (maximum values) in the decoded Reed-Muller codeword, which is used for error correction in the HQC cryptosystem.
--This design finds the maximum absolute value (peak) from a stream of signed input values. It's optimized to process two values in parallel (even and odd positions) to increase throughput.
--*/    

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

-- Top-level findpeaks module
entity hqc_rmdecod_findpeaks is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i         : in  std_logic;
        rst_ni        : in  std_logic;
        start_i       : in  std_logic;
        din0_i        : in  std_logic_vector;--(DIN_W-1 downto 0);
        din1_i        : in  std_logic_vector;--(DIN_W-1 downto 0);
        din_valid_i   : in  std_logic;
        dout_o        : out std_logic_vector;--(DOUT_W-1 downto 0);
        dout_valid_o  : out std_logic
    );
end hqc_rmdecod_findpeaks;

architecture rtl of hqc_rmdecod_findpeaks is

-- Parameter calculations
constant MULTIPLICITY : integer := get_MULTIPLICITY(PARAM_SET);
constant SUM_W        : integer := get_SUM_W(PARAM_SET);
constant DIN_W        : integer := 1 + SUM_W + 7;
constant DOUT_W       : integer := 8;

-- Internal signals
signal dout_valid      : std_logic;
signal dout            : std_logic_vector(DOUT_W-1 downto 0);

signal peak_value0     : std_logic_vector(DIN_W-1 downto 0);
signal peak_value1     : std_logic_vector(DIN_W-1 downto 0);
signal next_value      : std_logic_vector(DIN_W-1 downto 0);
signal peak_abs0       : std_logic_vector(DIN_W-2 downto 0):= (others => '0');
signal peak_abs1       : std_logic_vector(DIN_W-2 downto 0):= (others => '0');
signal peak_pos0       : std_logic_vector(6 downto 0) := (others => '0');
signal peak_pos1       : std_logic_vector(6 downto 0) := (others => '0');
signal next_pos        : std_logic_vector(6 downto 0);
signal dout_valid0     : std_logic;
signal dout_valid1     : std_logic;
signal check_abs       : std_logic;
signal check_equ       : std_logic;
signal check_pos       : std_logic;

-- Component declaration
component findpeaks_core is
    generic (
        PARAM_SET      : hqc_params_set_t := DEFAULT_PARAM_SET;
        DIN_W          : integer := 10;
        DOUT_W         : integer := 8;
        STARTPOS       : integer := 0
    );
    port (
        clk_i         : in  std_logic;
        rst_ni        : in  std_logic;
        start_i       : in  std_logic;
        din_i         : in  std_logic_vector(DIN_W-1 downto 0);
        din_valid_i   : in  std_logic;
        peak_abs_o    : out std_logic_vector(DIN_W-2 downto 0);
        peak_pos_o    : out std_logic_vector(DOUT_W-1 downto 0);
        peak_value_o  : out std_logic_vector(DIN_W-1 downto 0);
        dout_valid_o  : out std_logic
    );
end component;

begin
 -- Compare absolute value
--Initial code
check_abs <= '1' when unsigned(peak_abs1) > unsigned(peak_abs0) else '0';
check_equ <= '1' when peak_abs1 = peak_abs0 else '0';
check_pos <= '1' when unsigned(peak_pos1) > unsigned(peak_pos0) else '0';

--check_abs <= '1' when (rst_ni = '0' and unsigned(peak_abs1) > unsigned(peak_abs0)) else '0';
--check_equ <= '1' when (rst_ni = '0' and peak_abs1 = peak_abs0) else '0';
--check_pos <= '1' when (rst_ni = '0' and unsigned(peak_pos1) > unsigned(peak_pos0)) else '0';


-- Next values
next_pos   <= peak_pos1   when (check_equ = '1' and check_pos = '1') or check_abs = '1' else peak_pos0;
next_value <= peak_value1 when (check_equ = '1' and check_pos = '1') or check_abs = '1' else peak_value0;

-- Outputs
process(clk_i)
    variable is_zero : std_logic;
begin
    if rising_edge(clk_i) then
        dout_valid <= dout_valid0;
        -- Check if magnitude is zero
        if unsigned(next_value(DIN_W-2 downto 0)) = 0 then
            is_zero := '1';
        else
            is_zero := '0';
        end if;
        -- Output: valid flag when positive and non-zero
        dout(7) <= not (next_value(DIN_W-1) or is_zero);
        dout(6 downto 0) <= next_pos;
    end if;
end process;

dout_o       <= dout;
dout_valid_o <= dout_valid;

-- Find peaks core 0 (even positions)
FIND_PEAKS_0 : findpeaks_core
    generic map (
        PARAM_SET      => PARAM_SET,
        DIN_W          => DIN_W,
        DOUT_W         => 7,
        STARTPOS       => 0
    )
    port map (
        clk_i         => clk_i,
        rst_ni        => rst_ni,
        start_i       => start_i,
        din_i         => din0_i,
        din_valid_i   => din_valid_i,
        peak_abs_o    => peak_abs0,
        peak_pos_o    => peak_pos0,
        peak_value_o  => peak_value0,
        dout_valid_o  => dout_valid0
    );

-- Find peaks core 1 (odd positions)
FIND_PEAKS_1 : findpeaks_core
    generic map (
        PARAM_SET      => PARAM_SET,
        DIN_W          => DIN_W,
        DOUT_W         => 7,
        STARTPOS       => 1
    )
    port map (
        clk_i         => clk_i,
        rst_ni        => rst_ni,
        start_i       => start_i,
        din_i         => din1_i,
        din_valid_i   => din_valid_i,
        peak_abs_o    => peak_abs1,
        peak_pos_o    => peak_pos1,
        peak_value_o  => peak_value1,
        dout_valid_o  => dout_valid1
    );

end rtl;

-------------------------------------------------------------------------------
-- Findpeaks Core Module
-------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

-- Each core processes one stream and maintains a running maximum:
-- Operation Flow:
-- Absolute Value Calculation: Converts signed input to absolute value using two's complement
-- Comparison: Compares current input against stored peak
-- Update: If current value is larger, updates the peak value, position, and absolute value
-- Counter: Tracks position (increments by 2 for even/odd streams)


entity findpeaks_core is
generic (
    PARAM_SET      : hqc_params_set_t := DEFAULT_PARAM_SET;
    DIN_W          : integer := 10;
    DOUT_W         : integer := 8;
    STARTPOS       : integer := 0  -- 0 for even, 1 for odd
);
port (
    clk_i         : in  std_logic;
    rst_ni        : in  std_logic;
    start_i       : in  std_logic;
    din_i         : in  std_logic_vector(DIN_W-1 downto 0);
    din_valid_i   : in  std_logic;
    peak_abs_o    : out std_logic_vector(DIN_W-2 downto 0);
    peak_pos_o    : out std_logic_vector(DOUT_W-1 downto 0);
    peak_value_o  : out std_logic_vector(DIN_W-1 downto 0);
    dout_valid_o  : out std_logic
);
end findpeaks_core;

architecture rtl of findpeaks_core is

 -- Internal signals
signal start_d     : std_logic;
signal cnt_in      : unsigned(6 downto 0);
signal dout_valid  : std_logic;
signal last_din    : std_logic;

signal peak_value  : std_logic_vector(DIN_W-1 downto 0);
signal peak_abs    : std_logic_vector(DIN_W-1 downto 0);
signal peak_pos    : std_logic_vector(DOUT_W-1 downto 0);

signal prev_value  : std_logic_vector(DIN_W-1 downto 0);
signal prev_abs    : std_logic_vector(DIN_W-2 downto 0);
signal prev_pos    : std_logic_vector(DOUT_W-1 downto 0);

signal next_value  : std_logic_vector(DIN_W-1 downto 0);
signal next_abs    : std_logic_vector(DIN_W-2 downto 0);
signal next_pos    : std_logic_vector(DOUT_W-1 downto 0);

signal din_value   : std_logic_vector(DIN_W-1 downto 0);
signal din_abs     : std_logic_vector(DIN_W-2 downto 0);
signal din_pos     : std_logic_vector(DOUT_W-1 downto 0);

signal check_abs   : std_logic;

signal din_abs_temp : signed(DIN_W-1 downto 0);

begin
 -- Input values
din_value <= din_i;

-- Calculate absolute value (two's complement if negative)
din_abs_temp <= signed(din_i);
din_abs <= std_logic_vector(-din_abs_temp(DIN_W-2 downto 0)) when din_i(DIN_W-1) = '1' 
           else din_i(DIN_W-2 downto 0);

din_pos <= std_logic_vector(resize(cnt_in, DOUT_W));

-- Previous values
prev_abs   <= (others => '0') when start_d = '1' else peak_abs(DIN_W-2 downto 0);
prev_pos   <= std_logic_vector(to_unsigned(STARTPOS, DOUT_W)) when start_d = '1' else peak_pos;
prev_value <= (others => '0') when start_d = '1' else peak_value;

-- Compare absolute value
check_abs <= '1' when unsigned(din_abs) > unsigned(prev_abs) else '0';

-- Next values
next_abs   <= din_abs   when check_abs = '1' else prev_abs;
next_pos   <= din_pos   when check_abs = '1' else prev_pos;
next_value <= din_value when check_abs = '1' else prev_value;

-- Delayed input start
process(clk_i)
begin
    if rising_edge(clk_i) then
        start_d <= start_i;
    end if;
end process;

-- The 8-bit output contains:
-- Bit 7: Valid flag (1 = positive non-zero peak found, 0 = invalid/zero/negative)
-- Bits 6-0: Position of the peak (0-127)

-- Peak registers
process(clk_i)
begin
    if rising_edge(clk_i) then
        if din_valid_i = '1' then
            --peak_abs   <= (next_abs(DIN_W-2 downto 0) & '0');  -- Extend to DIN_W bits
		peak_abs   <= ('0' & next_abs(DIN_W-2 downto 0));
            peak_pos   <= next_pos;
            peak_value <= next_value;
        end if;
    end if;
end process;

peak_abs_o   <= peak_abs(DIN_W-2 downto 0);
peak_pos_o   <= peak_pos;
peak_value_o <= peak_value;

-- Controller
-- Input Counter
process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or start_i = '1' or last_din = '1' then
            cnt_in <= to_unsigned(STARTPOS, 7);
        elsif din_valid_i = '1' then
            cnt_in <= cnt_in + 2;
        end if;
    end if;
end process;

last_din <= '1' when cnt_in(6 downto 1) = "111111" and din_valid_i = '1' else '0';

-- Output valid
process(clk_i)
begin
    if rising_edge(clk_i) then
        dout_valid <= last_din;
    end if;
end process;

dout_valid_o <= dout_valid;

end rtl;