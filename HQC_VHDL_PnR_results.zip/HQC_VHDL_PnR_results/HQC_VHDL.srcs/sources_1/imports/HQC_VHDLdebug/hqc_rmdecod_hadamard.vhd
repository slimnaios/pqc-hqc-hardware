--/*Main conversions:

--Array types: Created custom types for the layer interconnect arrays (start_array_t, data_array_t, valid_array_t)
--Generate statement: Converted the Verilog generate loop to VHDL's for generate to create 7 Hadamard layers
--Signed arithmetic: Used signed() type casting for additions and subtractions with sign extension
--FIFO instantiation: Four FIFOs per layer store even/odd samples for first/second halves of the transform
--Counter logic: Input counter tracks 64 samples (0-63), output counter starts at input count 32

--Key implementation details:

--Top module: Chains 7 Hadamard layers together, each increasing bit width by 1
--Hadamard correction: Subtracts 64*MULTIPLICITY from first output to get half-Hadamard transform
--Layer operation: Each layer performs butterfly operations (add/subtract) and stores results in FIFOs
--FIFO organization: Separates even/odd inputs and first/second halves for proper Hadamard transform ordering
--Pipelining: Output starts when 32 inputs received, allowing overlapped computation

--This implements the Fast Hadamard Transform (FHT) used in Reed-Muller decoding for the HQC post-quantum cryptosystem. 
--The transform converts time-domain samples to frequency domain for efficient decoding.

--OverviewPurpose: Converts 64 pairs of soft-decision values (from the Expand & Sum module) into frequency domain 
--using a 7-stage Hadamard transform pipeline.
--Key Concept: The Hadamard transform helps identify which Reed-Muller codeword was most likely transmitted by 
--computing correlations in the frequency domain.

--## Complete Data Flow Example

--### **Input to Layer 0:**
--```
--64 pairs: (d0[0],d1[0]), (d0[1],d1[1]), ..., (d0[63],d1[63])
--```

--### **Layer 0 Processing:**

--**Even indices (0,2,4,...,62):**
--```
--sum  = d0[0] + d1[0] ? FIFO_F0
--diff = d0[0] - d1[0] ? FIFO_S0
--```

--**Odd indices (1,3,5,...,63):**
--```
--sum  = d0[1] + d1[1] ? FIFO_F1
--diff = d0[1] - d1[1] ? FIFO_S1
--```

--### **Layer 0 Output (reordered):**
--```
--Outputs 0-31:  F0[0], F1[0], F0[1], F1[1], ..., F0[15], F1[15]  (all sums)
--Outputs 32-63: S0[0], S1[0], S0[1], S1[1], ..., S0[15], S1[15]  (all diffs)
--```

--This reordering is **critical** for the Hadamard transform to work correctly!

-----

--## Why This Design?

--### **1. Efficient Hadamard Transform**

--The naive approach would be O(N�) operations for N=128.

--This **Fast Hadamard Transform** uses:
--- 7 stages (log?(128))
--- 64 butterflies per stage
--- Total: 7�64 = 448 operations instead of 128�=16,384!

--### **2. Pipelined Architecture**

--Each layer can process different data simultaneously:
--```
--Cycle 100: Layer 0 processes set A
--           Layer 1 processes set from 64 cycles ago
--           Layer 6 outputs transformed set from 384 cycles ago
--```

--### **3. Memory-Efficient**

--FIFOs store intermediate results without needing full RAM arrays.

--### **4. Bit-Reversed Addressing**

--The even/odd separation + FIFO ordering automatically handles the bit-reversal needed for FFT-style algorithms.

-----

--## Mathematical View

--The 128-point Hadamard transform computes:
--```
--H[k] = ?(i=0 to 127) [ x[i] � (-1)^(popcount(i AND k)) ]

--Where:
--x[i] = input values
--H[k] = correlation with k-th basis codeword
--popcount(i AND k) = number of 1s in bitwise AND

--The largest H[k] indicates which codeword was transmitted

--Summary
--This Hadamard transform implementation:
--? 7-stage pipeline for Fast Hadamard Transform
--? Butterfly operations (add/subtract) at each stage
--? 4 FIFOs per layer for data reordering
--? Overlapped I/O for 2� throughput
--? Growing bit-width to prevent overflow
--? Half-Hadamard correction for RM decoding
--The output represents correlations between the received signal and all 256 possible Reed-Muller 
--codewords, enabling maximum-likelihood decoding in the HQC post-quantum cryptosystem!
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

-- Top-level Hadamard Transform module
entity hqc_rmdecod_hadamard is
    generic (
        PARAM_SET : hqc_params_set_t := DEFAULT_PARAM_SET
    );
    port (
        clk_i         : in  std_logic;
        rst_ni        : in  std_logic;
        start_i       : in  std_logic;
        din0_i        : in  std_logic_vector;--(DIN_W-1 downto 0);
        din1_i        : in  std_logic_vector;--(DIN_W-1 downto 0);
        din_valid_i   : in  std_logic;
        dout_start_o  : out std_logic;
        dout0_o       : out std_logic_vector;--(DOUT_W-1 downto 0);
        dout1_o       : out std_logic_vector;--(DOUT_W-1 downto 0);
        dout_valid_o  : out std_logic
    );
end hqc_rmdecod_hadamard;

architecture rtl of hqc_rmdecod_hadamard is

-- Parameter calculations
constant MULTIPLICITY : integer := get_MULTIPLICITY(PARAM_SET);
constant DIN_W        : integer := get_DIN_W(PARAM_SET);
constant DOUT_W       : integer := 1 + DIN_W + 7;

-- Array types for layer connections
type start_array_t is array (0 to 7) of std_logic;
type data_array_t is array (0 to 7) of std_logic_vector(DOUT_W-1 downto 0);
type valid_array_t is array (0 to 7) of std_logic;

signal start_sig      : start_array_t;
signal data0_sig      : data_array_t;
signal data1_sig      : data_array_t;
signal data_valid_sig : valid_array_t;

signal dout_start_d  : std_logic;
signal dout0_d       : std_logic_vector(DOUT_W-1 downto 0);
signal dout1_d       : std_logic_vector(DOUT_W-1 downto 0);
signal dout_valid_d  : std_logic;
signal dout0_t       : std_logic_vector(DOUT_W-1 downto 0);
signal dout1_t       : std_logic_vector(DOUT_W-1 downto 0);
signal dout_valid_t  : std_logic;

-- Component declaration
component hadamard_layer is
    generic (
        NN : integer := 3;
        MM : integer := 4
    );
    port (
        clk_i         : in  std_logic;
        rst_ni        : in  std_logic;
        start_i       : in  std_logic;
        din0_i        : in  std_logic_vector(NN-1 downto 0);
        din1_i        : in  std_logic_vector(NN-1 downto 0);
        din_valid_i   : in  std_logic;
        dout_start_o  : out std_logic;
        dout0_o       : out std_logic_vector(MM-1 downto 0);
        dout1_o       : out std_logic_vector(MM-1 downto 0);
        dout_valid_o  : out std_logic
    );
end component;
begin
 -- Input assignment
data0_sig(0)(DOUT_W-1 downto DIN_W) <= (others => '0');
data0_sig(0)(DIN_W-1 downto 0) <= din0_i;
data1_sig(0)(DOUT_W-1 downto DIN_W) <= (others => '0');
data1_sig(0)(DIN_W-1 downto 0) <= din1_i;
start_sig(0) <= start_i;
data_valid_sig(0) <= din_valid_i;

-- Delayed output start
process(clk_i)
begin
    if rising_edge(clk_i) then
        dout_start_d <= start_sig(7);
    end if;
end process;

process(clk_i)
begin
    if rising_edge(clk_i) then
        dout0_d      <= dout0_t;
        dout1_d      <= dout1_t;
        dout_valid_d <= dout_valid_t;
    end if;
end process;

-- Outputs assignment
dout_start_o <= dout_start_d;

-- Fix the first entry to get the half Hadamard transform
-- transform[0] -= 64 * MULTIPLICITY;
-- Only for the first hadamard output
dout0_t <= std_logic_vector(signed(data0_sig(7)) - to_signed(64*MULTIPLICITY, DOUT_W)) when dout_start_d = '1' else data0_sig(7);
--dout0_t <= std_logic_vector(unsigned(data0_sig(7)) - to_unsigned(64*MULTIPLICITY, data0_sig(7)'length));
dout1_t      <= data1_sig(7);
dout_valid_t <= data_valid_sig(7);

dout0_o      <= dout0_d;
dout1_o      <= dout1_d;
dout_valid_o <= dout_valid_d;

-- Layer connections (generate 7 Hadamard layers)
gen_hadamard_layers: for ii in 0 to 6 generate
    HL : hadamard_layer
        generic map (
            NN => DIN_W + 1 + ii,
            MM => DIN_W + 1 + ii + 1
        )
        port map (
            clk_i         => clk_i,
            rst_ni        => rst_ni,
            start_i       => start_sig(ii),
            din0_i        => data0_sig(ii)(DIN_W+ii downto 0),
            din1_i        => data1_sig(ii)(DIN_W+ii downto 0),
            din_valid_i   => data_valid_sig(ii),
            dout_start_o  => start_sig(ii+1),
            dout0_o       => data0_sig(ii+1)(DIN_W+ii+1 downto 0),
            dout1_o       => data1_sig(ii+1)(DIN_W+ii+1 downto 0),
            dout_valid_o  => data_valid_sig(ii+1)
        );
end generate;
end rtl;
-------------------------------------------------------------------------------
-- Hadamard Layer Module
-------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity hadamard_layer is
    generic (
        NN : integer := 3;
        MM : integer := 4
    );
    port (
        clk_i         : in  std_logic;
        rst_ni        : in  std_logic;
        start_i       : in  std_logic;
        din0_i        : in  std_logic_vector(NN-1 downto 0);
        din1_i        : in  std_logic_vector(NN-1 downto 0);
        din_valid_i   : in  std_logic;
        dout_start_o  : out std_logic;
        dout0_o       : out std_logic_vector(MM-1 downto 0);
        dout1_o       : out std_logic_vector(MM-1 downto 0);
        dout_valid_o  : out std_logic
    );
end hadamard_layer;

architecture rtl of hadamard_layer is

-- Internal signals
signal dout_valid      : std_logic;
signal add_out0        : std_logic_vector(MM-1 downto 0);
signal add_out1        : std_logic_vector(MM-1 downto 0);

-- FIFO signals
signal fifo_f0_wr      : std_logic;
signal fifo_f0_rd      : std_logic;
signal fifo_f0_din     : std_logic_vector(MM-1 downto 0);
signal fifo_f0_empty   : std_logic;
signal fifo_f0_full    : std_logic;
signal fifo_f0_dout    : std_logic_vector(MM-1 downto 0);

signal fifo_f1_wr      : std_logic;
signal fifo_f1_rd      : std_logic;
signal fifo_f1_din     : std_logic_vector(MM-1 downto 0);
signal fifo_f1_empty   : std_logic;
signal fifo_f1_full    : std_logic;
signal fifo_f1_dout    : std_logic_vector(MM-1 downto 0);

signal fifo_s0_wr      : std_logic;
signal fifo_s0_rd      : std_logic;
signal fifo_s0_din     : std_logic_vector(MM-1 downto 0);
signal fifo_s0_empty   : std_logic;
signal fifo_s0_full    : std_logic;
signal fifo_s0_dout    : std_logic_vector(MM-1 downto 0);

signal fifo_s1_wr      : std_logic;
signal fifo_s1_rd      : std_logic;
signal fifo_s1_din     : std_logic_vector(MM-1 downto 0);
signal fifo_s1_empty   : std_logic;
signal fifo_s1_full    : std_logic;
signal fifo_s1_dout    : std_logic_vector(MM-1 downto 0);

signal cnt_in          : unsigned(5 downto 0);
signal cnt_out         : unsigned(5 downto 0);
signal last_din        : std_logic;
signal even_in_d       : std_logic;
signal odd_in_d        : std_logic;
signal cnt_out_start   : std_logic;
signal cnt_out_en      : std_logic;
signal dout_start      : std_logic;
signal second_half_out : std_logic;

-- Component declaration
component syncfifo is
    generic (
        DW : integer := 8;
        AW : integer := 5
    );
    port (
        clk_i   : in  std_logic;
        rst_ni  : in  std_logic;
        wr_i    : in  std_logic;
        rd_i    : in  std_logic;
        din_i   : in  std_logic_vector(DW-1 downto 0);
        empty_o : out std_logic;
        full_o  : out std_logic;
        dout_o  : out std_logic_vector(DW-1 downto 0)
    );
end component;
begin
 -- Calculation (addition and subtraction with sign extension)
 -- Each layer implements one stage of the butterfly operation used in FFT-like algorithms.
 -- `add_out0 = din0 + din1` (sum)
 -- `add_out1 = din0 - din1` (difference)
 -- Sign extension prevents overflow

process(clk_i)
begin
    if rising_edge(clk_i) then
        if din_valid_i = '1' then
            add_out0 <= std_logic_vector(signed(din0_i(NN-1) & din0_i) + 
                                        signed(din1_i(NN-1) & din1_i));
            add_out1 <= std_logic_vector(signed(din0_i(NN-1) & din0_i) - 
                                        signed(din1_i(NN-1) & din1_i));
        end if;
    end if;
end process;

-- Each layer has 4 FIFOs:
-- FIFO_F0: First half, even positions (sum values)
-- FIFO_F1: First half, odd positions (sum values)
-- FIFO_S0: Second half, even positions (difference values)
-- FIFO_S1: Second half, odd positions (difference values)
-- The Hadamard transform processes data in a bit-reversed order. 
-- The FIFOs handle the reordering needed between stages.

-- FIFO first half, even (0,2,...,62; 32 addresses)
FIFO_F0 : syncfifo
    generic map (
        DW => MM,
        AW => 5
    )
    port map (
        clk_i   => clk_i,
        rst_ni  => rst_ni,
        wr_i    => fifo_f0_wr,
        rd_i    => fifo_f0_rd,
        din_i   => fifo_f0_din,
        empty_o => fifo_f0_empty,
        full_o  => fifo_f0_full,
        dout_o  => fifo_f0_dout
    );

fifo_f0_wr  <= even_in_d;
fifo_f0_rd  <= (not cnt_out(5)) and cnt_out_en;
fifo_f0_din <= add_out0;

-- FIFO first half, odd (1,3,...,63; 32 addresses)
FIFO_F1 : syncfifo
    generic map (
        DW => MM,
        AW => 5
    )
    port map (
        clk_i   => clk_i,
        rst_ni  => rst_ni,
        wr_i    => fifo_f1_wr,
        rd_i    => fifo_f1_rd,
        din_i   => fifo_f1_din,
        empty_o => fifo_f1_empty,
        full_o  => fifo_f1_full,
        dout_o  => fifo_f1_dout
    );

fifo_f1_wr  <= odd_in_d;
fifo_f1_rd  <= (not cnt_out(5)) and cnt_out_en;
fifo_f1_din <= add_out0;

-- FIFO second half, even (0,2,...,62; 32 addresses)
FIFO_S0 : syncfifo
    generic map (
        DW => MM,
        AW => 5
    )
    port map (
        clk_i   => clk_i,
        rst_ni  => rst_ni,
        wr_i    => fifo_s0_wr,
        rd_i    => fifo_s0_rd,
        din_i   => fifo_s0_din,
        empty_o => fifo_s0_empty,
        full_o  => fifo_s0_full,
        dout_o  => fifo_s0_dout
    );

fifo_s0_wr  <= even_in_d;
fifo_s0_rd  <= cnt_out(5) and cnt_out_en;
fifo_s0_din <= add_out1;

-- FIFO second half, odd (1,3,...,63; 32 addresses)
FIFO_S1 : syncfifo
    generic map (
        DW => MM,
        AW => 5
    )
    port map (
        clk_i   => clk_i,
        rst_ni  => rst_ni,
        wr_i    => fifo_s1_wr,
        rd_i    => fifo_s1_rd,
        din_i   => fifo_s1_din,
        empty_o => fifo_s1_empty,
        full_o  => fifo_s1_full,
        dout_o  => fifo_s1_dout
    );

fifo_s1_wr  <= odd_in_d;
fifo_s1_rd  <= cnt_out(5) and cnt_out_en;
fifo_s1_din <= add_out1;

-- Controller
-- Input Counter
process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or start_i = '1' or last_din = '1' then
            cnt_in <= (others => '0');
        elsif din_valid_i = '1' then
            cnt_in <= cnt_in + 1;
        end if;
    end if;
end process;

process(clk_i)
begin
    if rising_edge(clk_i) then
        even_in_d <= (not cnt_in(0)) and din_valid_i;
        odd_in_d  <= cnt_in(0) and din_valid_i;
    end if;
end process;

last_din <= '1' when cnt_in = 63 and din_valid_i = '1' else '0';

-- Output Counter
process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or cnt_out_start = '1' or cnt_out = 63 then
            cnt_out <= (others => '0');
        elsif cnt_out_en = '1' then
            cnt_out <= cnt_out + 1;
        end if;
    end if;
end process;

-- Output starts when **32 inputs received**, not 64!
-- This enables **50% overlap** between input and output phases for throughput.
-- Cycles 0-31:  Read from F0/F1 (first half, sums)
-- Cycles 32-63: Read from S0/S1 (second half, differences)

cnt_out_start <= '1' when cnt_in = 32 and din_valid_i = '1' else '0';

process(clk_i)
begin
    if rising_edge(clk_i) then
        if rst_ni = '0' or (cnt_out = 63 and cnt_out_start = '0') then
            cnt_out_en <= '0';
        elsif cnt_out_start = '1' then
            cnt_out_en <= '1';
        end if;
    end if;
end process;

process(clk_i)
begin
    if rising_edge(clk_i) then
        second_half_out <= cnt_out_en and cnt_out(5);
    end if;
end process;

process(clk_i)
begin
    if rising_edge(clk_i) then
        dout_start <= cnt_out_start;
        dout_valid <= cnt_out_en;
    end if;
end process;

-- Outputs assignment
dout0_o <= fifo_s0_dout when second_half_out = '1' else fifo_f0_dout;
dout1_o <= fifo_s1_dout when second_half_out = '1' else fifo_f1_dout;

dout_start_o <= dout_start;
dout_valid_o <= dout_valid;

end rtl;