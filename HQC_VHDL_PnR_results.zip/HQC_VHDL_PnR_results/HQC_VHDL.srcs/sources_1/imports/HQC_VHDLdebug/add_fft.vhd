--/*Main conversions:

--Input data swapping: Used a generate loop to reverse the byte order from the input
--Input: {din31, ..., din1, din0}
--After swap: {din0, din1, ..., din31}

--Component instantiations: Three main components:
--fft_part1: First stage of additive FFT
--fft_leaves_butterfly: Butterfly operation on leaf nodes
--fft_part2: Second stage of additive FFT

--Control counters:
--cnt: Controls FFT1 output reading
--fft2_cnt: Tracks FFT2 input data
--cnt_out: Generates output RAM addresses

--Data flow pipeline:
--FFT1 produces 4-byte outputs (bf_a0, bf_a1, bf_a2, bf_a3)
--Butterfly processes a0 and a1
--a2 is buffered separately
--FFT2 receives butterfly output first, then buffered a2

--Key implementation details:

--Byte extraction: Split 32-bit fft1_dout into four 8-bit signals
--Timing control: cnt(4:0) used for precise timing (checks at values 0, 15, 23)
--Buffering: a2_buf stores bf_a2 at specific counter value for later use
--Multiplexing: fft2_din selects between butterfly output and buffered a2 based on fft2_cnt(4)

--Algorithm purpose:
--This implements an Additive FFT (also called Radix-2 FFT over GF(2^m)), which is used in error correction codes and cryptographic applications. 
--Unlike traditional FFT over complex numbers, this operates in Galois Fields with XOR-based arithmetic.
--Input: 32-byte polynomial ?(x) = ?? + ??x + ... + ???x��
--Output: 256 evaluations [?(??), ?(?�), ?(?�), ..., ?(?�??)]

--Input (32 bytes) ? [Byte Swap] ? [FFT Part 1] ? [Butterfly] ? [FFT Part 2] ? Output (256 bytes)
--                                      ?              ?              ?
--                                   4-byte         2-byte       a2 buffered
--                                   groups         pairs

--The two-part FFT structure with a butterfly in between suggests this is implementing a split-radix or decimation-in-frequency algorithm 
--optimized for hardware implementation in the HQC cryptosystem.
--*/

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;
--library WORK;
use WORK.system_constants.all;
use WORK.HQC_parameters.all;

entity add_fft is
    generic (
        DIN_W : integer := 32*8;
        AW    : integer := 8;
        DW    : integer := 8
    );
    port (
        clk_i      : in  std_logic;
        rst_ni     : in  std_logic;
        start_i    : in  std_logic;
        start_o    : out std_logic;
        done_o     : out std_logic;
        -- Input/output data
        din_i      : in  std_logic_vector(DIN_W-1 downto 0);
        ram_din_o  : out std_logic_vector(DW-1 downto 0);
        ram_addr_o : out std_logic_vector(AW-1 downto 0);
        ram_wr     : out std_logic
    );
end add_fft;

architecture rtl of add_fft is

    -- Internal signals
    signal fft1_din       : std_logic_vector(DIN_W-1 downto 0);
    signal fft1_busy      : std_logic;
    signal fft1_done      : std_logic;
    signal fft1_dout      : std_logic_vector(31 downto 0);      --initial Verilog code: (7 downto 0)
    signal fft1_dout_temp : std_logic_vector(31 downto 0);
    signal fft1_dout_rd   : std_logic;
    signal cnt            : unsigned(7 downto 0) := (others => '0');
    signal cnt_en         : std_logic;
    signal bf_a0          : std_logic_vector(7 downto 0);
    signal bf_a1          : std_logic_vector(7 downto 0);
    signal bf_a2          : std_logic_vector(7 downto 0);
    signal bf_a3          : std_logic_vector(7 downto 0);
    signal a2_buf         : std_logic_vector(7 downto 0);
    signal bf_din_vld     : std_logic;
    signal bf_dout        : std_logic_vector(7 downto 0);
    signal bf_dout_vld    : std_logic;
    signal fft2_start_in  : std_logic;
    signal fft2_start_out : std_logic;
    signal fft2_busy      : std_logic;
    signal fft2_done      : std_logic;
    signal fft2_din       : std_logic_vector(7 downto 0);
    signal fft2_din_vld   : std_logic;
    signal fft2_dout      : std_logic_vector(7 downto 0);
    signal fft2_dout_vld  : std_logic;
    signal fft2_cnt       : unsigned(7 downto 0) := (others => '0');
    signal cnt_out        : unsigned(7 downto 0) := (others => '0');
    
    -- Component declarations
    component fft_part1 is
        generic (
            DIN_W  : integer := 256;
            DOUT_W : integer := 32
        );
        port (
            clk_i        : in  std_logic;
            rst_ni       : in  std_logic;
            start_i      : in  std_logic;
            busy_o       : out std_logic;
            done_o       : out std_logic;
            din_i        : in  std_logic_vector(DIN_W-1 downto 0);
            dout_read_i  : in  std_logic;
            dout_o       : out std_logic_vector(DOUT_W-1 downto 0);
            dout_valid_o : out std_logic
        );
    end component;
    
    component fft_leaves_butterfly is
        port (
            clk_i        : in  std_logic;
            rst_ni       : in  std_logic;
            start_i      : in  std_logic;
            busy_o       : out std_logic;
            a0_i         : in  std_logic_vector(7 downto 0);
            a1_i         : in  std_logic_vector(7 downto 0);
            dout_o       : out std_logic_vector(7 downto 0);
            dout_valid_o : out std_logic
        );
    end component;
    
    component fft_part2 is
        port (
            clk_i        : in  std_logic;
            rst_ni       : in  std_logic;
            start_i      : in  std_logic;
            start_o      : out std_logic;
            busy_o       : out std_logic;
            done_o       : out std_logic;
            din_i        : in  std_logic_vector(7 downto 0);
            din_valid_i  : in  std_logic;
            dout_o       : out std_logic_vector(7 downto 0);
            dout_valid_o : out std_logic
        );
    end component;

begin

    -- Swap input data
    -- din = {din31, ..., din1, din0}
    -- fft_din = {din0, din1, ..., din31}
    gen_swap: for ii in 0 to (DIN_W/8)-1 generate
        fft1_din(ii*8+7 downto ii*8) <= din_i((DIN_W/8-ii-1)*8+7 downto (DIN_W/8-ii-1)*8);
    end generate;
    
    -- FFT Part 1
    -- Processes entire 256-bit input
    -- Produces intermediate results in groups of 4 bytes
    FFT_PART1_INST : fft_part1
        generic map (
            DIN_W  => DIN_W,
            DOUT_W => 4*8
        )
        port map (
            clk_i        => clk_i,
            rst_ni       => rst_ni,
            start_i      => start_i,
            busy_o       => fft1_busy,
            done_o       => fft1_done,
            din_i        => fft1_din,
            dout_read_i  => fft1_dout_rd,
            dout_o       => fft1_dout_temp,
            dout_valid_o => open
        );
    
    fft1_dout_rd <= '1' when cnt(4 downto 0) = 23 and cnt_en = '1' else '0';
    
    -- Split 32-bit output into 4 bytes
    -- initial Verilog code: assign {bf_a0, bf_a1, bf_a2, bf_a3} = fft1_dout;
    fft1_dout <= x"000000" & fft1_dout_temp(7 downto 0);                
    bf_a0 <= fft1_dout(31 downto 24);
    bf_a1 <= fft1_dout(23 downto 16);
    bf_a2 <= fft1_dout(15 downto 8);
    bf_a3 <= fft1_dout(7 downto 0); 
    
    bf_din_vld <= '1' when cnt(4 downto 0) = 0 and cnt_en = '1' else '0';
    
    -- FFT1 output counter
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or fft1_done = '1' or cnt = 255 then
                cnt <= (others => '0');
            elsif cnt_en = '1' then
                cnt <= cnt + 1;
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or cnt = 255 then
                cnt_en <= '0';
            elsif fft1_done = '1' then
                cnt_en <= '1';
            end if;
        end if;
    end process;
    
    -- Buffer a2 value
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if cnt(4 downto 0) = 15 and cnt_en = '1' then
                a2_buf <= bf_a2;
            end if;
        end if;
    end process;
    
    -- Butterfly
    BUTTERFLY_INST : fft_leaves_butterfly
        port map (
            clk_i        => clk_i,
            rst_ni       => rst_ni,
            start_i      => bf_din_vld,
            busy_o       => open,
            a0_i         => bf_a0,
            a1_i         => bf_a1,
            dout_o       => bf_dout,
            dout_valid_o => bf_dout_vld
        );
    
    -- FFT2 input control
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or fft2_start_in = '1' or fft2_cnt = 255 then
                fft2_cnt <= (others => '0');
            elsif fft2_din_vld = '1' then
                fft2_cnt <= fft2_cnt + 1;
            end if;
        end if;
    end process;
    
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or fft2_cnt = 255 then
                fft2_din_vld <= '0';
            elsif fft2_start_in = '1' then
                fft2_din_vld <= '1';
            end if;
        end if;
    end process;
    
    fft2_start_in <= '1' when cnt = 4 else '0';
    fft2_din <= a2_buf when fft2_cnt(4) = '1' else bf_dout;  -- toggles every 16 values

    -- Cycles 0-15:   fft2_cnt(4)='0' ? Use bf_dout (butterfly output)
    -- Cycles 16-31:  fft2_cnt(4)='1' ? Use a2_buf (buffered value)
    -- Cycles 32-47:  fft2_cnt(4)='0' ? Use bf_dout
    -- Cycles 48-63:  fft2_cnt(4)='1' ? Use a2_buf
    -- ...repeats...
    
    -- FFT Part 2
    -- Second stage of FFT processing, completes the FFT computation
    -- Input: 256 bytes (one at a time) from butterfly/buffer
    -- Output: 256 final evaluation results, one output byte per cycle (when valid)
    --Each output is ?(?^i) for some i
    FFT_PART2_INST : fft_part2
        port map (
            clk_i        => clk_i,
            rst_ni       => rst_ni,
            start_i      => fft2_start_in,
            start_o      => fft2_start_out,
            busy_o       => fft2_busy,
            done_o       => fft2_done,
            din_i        => fft2_din,
            din_valid_i  => fft2_din_vld,
            dout_o       => fft2_dout,
            dout_valid_o => fft2_dout_vld
        );
    
    -- Output counter
    process(clk_i)
    begin
        if rising_edge(clk_i) then
            if rst_ni = '0' or start_i = '1' or fft2_start_out = '1' or cnt_out = 255 then
                cnt_out <= (others => '0');
            elsif fft2_dout_vld = '1' then
                cnt_out <= cnt_out + 1;
            end if;
        end if;
    end process;
    
    -- Output assignments
    ram_addr_o <= std_logic_vector(cnt_out);
    ram_din_o  <= fft2_dout;
    ram_wr     <= fft2_dout_vld;
    done_o     <= fft2_done;
    start_o    <= fft2_start_out;

--/*
--## Data Flow Timeline
--```
--Cycle 0: start_i='1'
--  ?? fft1_din loaded (byte-swapped input)
--  ?? FFT Part 1 begins processing

--Cycles 1-N: FFT Part 1 Processing
--  ?? Computes first-stage FFT
--  ?? Produces 4-byte outputs

--Cycle N: fft1_done='1'
--  ?? cnt_en='1', counter starts

--Cycle N+4: cnt=4
--  ?? fft2_start_in='1', FFT Part 2 starts

--Cycles N+4 onwards: Interleaved Processing
--  ?? cnt cycles through 0-255
--  ?? Every 32 cycles:
--  ?  ?? cnt(4:0)=0:  New a?,a? to butterfly
--  ?  ?? cnt(4:0)=15: Buffer a?
--  ?  ?? cnt(4:0)=23: Read next FFT1 output
--  ?
--  ?? Butterfly processes a?,a? pairs
--  ?? fft2_din alternates:
--  ?  ?? 16 cycles: butterfly outputs
--  ?  ?? 16 cycles: buffered a? values
--  ?
--  ?? FFT Part 2 produces final results

--Cycles M onwards: Output Phase
--  ?? fft2_dout_vld='1'
--  ?? cnt_out increments (0-255)
--  ?? Results written to RAM
--  ?? ram_wr pulses for each valid output

--Cycle End: fft2_done='1'
--  ?? All 256 evaluations complete    
--*/

end rtl;

